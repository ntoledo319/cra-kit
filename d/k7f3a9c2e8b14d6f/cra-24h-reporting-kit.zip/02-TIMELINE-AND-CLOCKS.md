# Timeline and Clocks

This pack is engineering and process tooling, not legal advice. Verify against Regulation (EU) 2024/2847 and guidance from your coordinating national CSIRT before filing.

---

## The three-stage cascade

Article 14 does not ask for one report. It asks for a cascade of three, each proportionate to what you can reasonably know at that point. The design intent is that you report early and thinly, then thicken the record as the investigation advances. The Commission's guidance of 27 July 2026, Section 9.1, paragraph 215, states this directly: manufacturers are required to **update their notifications progressively** as their internal investigations advance.

| Stage | Actively exploited vulnerability (Art. 14(1),(2)) | Severe incident (Art. 14(3),(4)) |
| --- | --- | --- |
| **1. Early warning** | Without undue delay, and in any event **within 24 hours of becoming aware**. Indicate, where applicable, the Member States where you are aware the product has been made available. | Same 24-hour deadline. Must include at least **whether the incident is suspected of being caused by unlawful or malicious acts**, and, where applicable, the Member States concerned. |
| **2. Fuller notification** | **Vulnerability notification** within **72 hours of becoming aware**. General information, as available, about the product; the general nature of the exploit and of the vulnerability; corrective or mitigating measures taken and measures users can take; and an indication of how sensitive you consider the information to be. | **Incident notification** within **72 hours of becoming aware**. General information about the nature of the incident; an initial assessment; corrective or mitigating measures taken and measures users can take; sensitivity indication. |
| **3. Final report** | **No later than 14 days after a corrective or mitigating measure is available.** Must include at least: a description of the vulnerability including severity and impact; where available, information on any malicious actor that has exploited or is exploiting it; and details of the security update or other corrective measures made available. | **Within one month after the submission of the 72-hour incident notification.** Must include at least: a detailed description of the incident including severity and impact; the type of threat or root cause likely to have triggered it; and applied and ongoing mitigation measures. |

Three structural points that catch people out:

**The two final-report clocks are anchored differently.** For a vulnerability, the 14 days run from the moment a corrective or mitigating measure becomes **available** — not from awareness, and not from the 72-hour notification. That deadline therefore does not exist until you have a fix or a mitigation. For a severe incident, the one month runs from **submission of the 72-hour notification** — a date entirely within your control and knowable the moment you file stage 2.

**A mitigating measure counts, not only a patch.** If you publish a workaround, a configuration change, a firewall rule or a feature toggle that mitigates the risk, the 14-day clock starts then. Shipping a documented workaround on day 2 and the permanent patch on day 40 means the final report was due on day 16, not day 54. Record the exact UTC time the mitigation became available to users.

**Everything is "without undue delay" first, and the fixed period second.** The 24- and 72-hour figures are backstops, not targets. If you have the information at hour 6, file at hour 6.

## Interim reports

Under Article 14(6), where necessary the coordinating CSIRT that initially received your notification may **request an intermediate report** on relevant status updates. Treat such a request as a hard deadline with the same seriousness as the statutory ones, and log it.

## Worked example — actively exploited vulnerability

All times UTC. Use UTC in every internal record; local time and daylight-saving changes are a proven source of one-hour errors that turn a compliant filing into a late one.

**Facts.** A mid-sized manufacturer ships an edge gateway appliance, firmware 4.0 through 4.2.1, made available in Belgium, Greece and Italy. Main establishment in the Union: Belgium. Coordinating CSIRT: `[VERIFY: your coordinating CSIRT — see ENISA's published list of CSIRTs designated as coordinators]`.

| UTC timestamp | Event | Clock status |
| --- | --- | --- |
| Thu 2026-10-15 14:20 | A customer's SOC emails the product security inbox: "we think your appliance was the entry point, seeing odd outbound traffic from the management interface." No detail attached. | **Not awareness.** Signal logged. Duty to assess promptly begins. |
| Thu 2026-10-15 14:35 | Technical verifier paged. Customer asked for logs; internal telemetry review opened. | Assessment under way. Logged. |
| Thu 2026-10-15 17:10 | Customer supplies management-interface logs showing authentication being bypassed on an unpatched 4.2.1 unit, followed by privileged API calls from an external address. | Strong, not yet confirmed against own build. |
| Thu 2026-10-15 18:40 | Verifier reproduces the bypass against a stock 4.2.1 build and confirms the log pattern is exploitation, not misconfiguration. Accountable reporter declares awareness. | **T0 = 2026-10-15 18:40 UTC.** All clocks start. |
| Thu 2026-10-15 19:05 | Deadlines posted: EW due Fri 2026-10-16 18:40; 72h due Sun 2026-10-18 18:40. Final report date unknown — depends on mitigation availability. | Posted on the wall and in the channel. |
| Fri 2026-10-16 09:50 | **Early warning submitted.** ~9 hours early, ~15h10m after T0. Member States indicated: Belgium, Greece, Italy. | Stage 1 complete. |
| Fri 2026-10-16 16:30 | Workaround published to customers: restrict management-interface access to trusted networks. | This is a **mitigating measure**, but it is not yet "available" as a corrective measure in the product; record the time and flag the ambiguity — see the note below. |
| Sun 2026-10-18 11:00 | **72-hour notification submitted**, 7h40m before the deadline. Includes affected versions, general nature of the exploit, the published workaround, and sensitivity assessment. | Stage 2 complete. |
| Thu 2026-10-22 09:15 | Firmware 4.2.2 released and downloadable by all customers. **Corrective measure available.** | **14-day clock starts here.** |
| Thu 2026-11-05 09:15 | **Final report due.** | Filed Tue 2026-11-03 — two days early. |

**Arithmetic, shown explicitly.**

- T0 = 2026-10-15 18:40 UTC (Thursday).
- Early warning deadline = T0 + 24h = **2026-10-16 18:40 UTC (Friday)**.
- Notification deadline = T0 + 72h = **2026-10-18 18:40 UTC (Sunday)**. Note that this falls on a Sunday. Article 14 contains no working-day adjustment; the deadline is Sunday evening and you must staff for it.
- Corrective measure available = 2026-10-22 09:15 UTC (Thursday).
- Final report deadline = available + 14 days = **2026-11-05 09:15 UTC (Thursday)**.

**The mitigation-timing ambiguity, handled properly.** The Friday workaround is arguably a "mitigating measure available", which would have started the 14-day clock on 2026-10-16 16:30 and made the final report due 2026-10-30 16:30. The manufacturer above resolved this the safe way: it recorded both candidate dates in the evidence log, adopted the **earlier** one as its working deadline, and filed well inside it. Where the trigger date is genuinely arguable, take the earliest defensible date. Filing early is free; filing late is in the EUR 15 000 000 / 2.5 % tier.

## Worked example — severe incident, same arithmetic style

**Facts.** An attacker gains write access to the update distribution bucket used to ship signed firmware. No malicious artefact is confirmed to have reached a user, but the capability existed for an unknown period.

| UTC timestamp | Event | Clock status |
| --- | --- | --- |
| Sat 2026-11-07 02:15 | Automated integrity check flags an unexpected object write in the update bucket. | Signal logged. Not awareness. |
| Sat 2026-11-07 04:50 | Investigation confirms an unauthorised credential was used to write to the bucket. Gate 5(b) is met: the incident is capable of leading to the introduction of malicious code in the product. Awareness declared. | **T0 = 2026-11-07 04:50 UTC.** |
| Sat 2026-11-07 13:20 | **Early warning submitted.** Field "incident suspected of being caused by unlawful or malicious acts" = Yes. | Due Sun 2026-11-08 04:50. |
| Mon 2026-11-09 15:00 | **72-hour incident notification submitted.** Due Tue 2026-11-10 04:50. | Stage 2 complete. **The one-month clock starts from this submission.** |
| Wed 2026-12-09 15:00 | **Final report due** — one month after the 72-hour notification was submitted, not one month after T0. | |

Note the practical consequence: because the severe-incident final-report clock runs from your own submission of stage 2, filing stage 2 earlier pulls the final report earlier too. That is not a reason to delay stage 2 — the 72-hour deadline is absolute — but it is a reason to know the date the moment you press submit, and to write it on the wall.

## When the 24-hour mark arrives and you still know almost nothing

**You file anyway.** This is the single most important operational rule in the pack.

The early warning is deliberately thin. Article 14(2)(a) asks, for a vulnerability, for notification of the actively exploited vulnerability and, where applicable, an indication of the Member States where you are aware the product has been made available. Article 14(4)(a) asks, for a severe incident, for at least whether the incident is suspected of being caused by unlawful or malicious acts, plus the same Member State indication. The Commission's guidance describes the early warning as **containing limited information**. It exists to trigger coordination, not to demonstrate that you have solved the problem.

What to do at T0+20h when the picture is still fragmentary:

1. **File with what you have.** Incomplete is compliant. Absent is not.
2. **Say plainly what is unknown.** "Root cause not yet established." "Affected version range under confirmation; 4.2.1 confirmed affected." "Scope of impacted customers under assessment." Unknowns stated as unknowns are accurate reporting.
3. **Never speculate to fill a field.** Do not guess at an actor, a scope, a customer count, or a root cause. An early warning that later proves wrong because you guessed is worse than one that said "under investigation".
4. **Do not withhold the early warning to co-ordinate a PR statement.** The notification to the CSIRT and ENISA is not a public disclosure. Article 16 provides for confidentiality, and Article 16(2) provides for delayed dissemination on justified cybersecurity-related grounds, including where a coordinated vulnerability disclosure process is ongoing. Use the mechanism the regulation gives you rather than missing the deadline.
5. **Use the sensitivity field.** At the 72-hour stage you may indicate how sensitive you consider the notified information to be. Where you are reporting an unpatched exploitation path, say so and explain why restricted handling is warranted rather than attaching a generic confidentiality boilerplate.
6. **Keep the record moving.** Every field left blank at stage 1 becomes an action item with an owner and a target time for stage 2.
7. **Re-check the Member State list.** This is the one field people leave empty because it feels like sales data. Your distributor and importer records answer it; pull them before the incident, not during it.

## Weekend, holiday and handover arithmetic

The clock does not pause. A T0 on Friday at 17:00 UTC puts the early warning at Saturday 17:00 UTC and the 72-hour notification at Monday 17:00 UTC. A T0 on 23 December puts the notification inside the holiday shutdown.

Concrete mitigations, all of which are pre-incident work:

- Name a **deputy reporter** with equal authority to file, and make sure their platform access is provisioned and tested, not theoretical.
- Ensure at least two people hold a working **EU Login account with MFA enabled** and are registered on the reporting platform. One Primary Assigned Representative plus at least one Secondary is the minimum resilient configuration. Test a login quarterly — a stale MFA enrolment discovered at hour 22 is a compliance failure with a trivial cause.
- Put **absolute UTC deadlines** in a shared calendar with alarms at T0+12h, T0+20h, T0+60h and T0+68h. Relative countdowns in a chat channel are not sufficient.
- Agree in advance that the reporter may file **without further sign-off**. Approval chains that require an executive who is on a flight are how 24-hour deadlines are missed.

## Deadline computation worksheet

Copy this block into the incident record and fill it in the moment awareness is declared.

```
T0 (awareness, UTC)                 : ____-__-__ __:__
  declared by                       : ______________________
  fact that established certainty   : ______________________

Early warning due  (T0 + 24h)       : ____-__-__ __:__   filed: ____-__-__ __:__
72h notification due (T0 + 72h)     : ____-__-__ __:__   filed: ____-__-__ __:__

TRACK A - actively exploited vulnerability
  Mitigating measure available (UTC): ____-__-__ __:__
  Corrective measure available (UTC): ____-__-__ __:__
  Earliest defensible trigger date  : ____-__-__ __:__
  Final report due (trigger + 14d)  : ____-__-__ __:__   filed: ____-__-__ __:__

TRACK B - severe incident
  72h notification SUBMITTED at     : ____-__-__ __:__
  Final report due (+ 1 month)      : ____-__-__ __:__   filed: ____-__-__ __:__

Interim report requested by CSIRT?  : Yes / No   due: ____-__-__ __:__
Users informed under Art. 14(8)?    : Yes / No   at:  ____-__-__ __:__   how: ________
```

## Platform counters are not your deadline

The reporting platform displays its own counters and sends reminder emails. They are convenience features and, at the initial release, they do not all match the statutory clock — the 72-hour counter has been documented as computing from submission of the early warning rather than from the moment of awareness, which can display a notification as overdue before 72 hours have actually elapsed. Likewise, no counter can know when your corrective measure became available.

Compute your own deadlines from T0 and from the mitigation-availability timestamp, keep them in your own calendar, and treat any platform counter as a secondary reminder only. `[VERIFY: current counter behaviour in the platform's published guidance before relying on any on-screen due date]`
