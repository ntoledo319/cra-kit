# CRA 24-Hour Reporting Kit — START HERE

This pack is engineering and process tooling, not legal advice. Verify against Regulation (EU) 2024/2847 and guidance from your coordinating national CSIRT before filing.

---

## What this pack is for

Since **11 September 2026**, Article 14 of Regulation (EU) 2024/2847 (the Cyber Resilience Act, "CRA") requires manufacturers of products with digital elements to notify two categories of event to a coordinating national CSIRT and to ENISA:

1. any **actively exploited vulnerability** contained in the product, and
2. any **severe incident** having an impact on the security of the product.

The first notification — the early warning — is due **within 24 hours of becoming aware**. That deadline runs through nights, weekends and public holidays. Most organisations that miss it do not miss it because they lacked the technical skill to assess the event. They miss it because nobody knew who was allowed to press "submit", or because the 24-hour clock had already been running for eleven hours by the time anyone realised it had started.

This pack exists to remove both failure modes. It is the process layer around the legal obligation: who decides, on what evidence, by when, and what artefact you retain afterwards.

## Scope note: which obligations are live today

| Obligation | Applies from | Legal basis |
| --- | --- | --- |
| Article 14 reporting (actively exploited vulnerabilities, severe incidents) | 11 September 2026 | Article 71(2), second sentence |
| Notification of conformity assessment bodies (Chapter IV) | 11 June 2026 | Article 71(2), second sentence |
| Main CRA obligations (essential requirements, CE marking, vulnerability handling, CVD policy, SBOM, support periods) | 11 December 2027 | Article 71(2) |
| Reporting obligations for open-source software stewards (Article 24(3)) | 11 December 2027 | Article 71(2) |

Two consequences people routinely get wrong:

- **Products already on the EU market are in scope now.** Article 69(3) disapplies the usual transitional carve-out for Article 14. Reporting applies to all in-scope products with digital elements placed on the market before 11 December 2027. A product you shipped in 2019 and no longer actively develop still generates a reporting duty if you become aware that a vulnerability in it is being actively exploited.
- **Reporting outlives the support period.** The Commission's guidance of 27 July 2026 (Section 9.1) states that, unlike vulnerability handling obligations, the reporting obligations continue to apply after a product is no longer supported. You may be required to notify a vulnerability you are not required to fix.

Non-compliance with Article 14 sits in the CRA's highest penalty tier: administrative fines of up to **EUR 15 000 000 or 2.5 % of total worldwide annual turnover for the preceding financial year, whichever is higher** (Article 64(2)). One narrow relief exists: under Article 64(10)(a), the administrative fines do not apply to manufacturers qualifying as microenterprises or small enterprises specifically for a failure to meet the 24-hour early-warning deadline. That relief covers the deadline only — not the obligation to report, and not the 72-hour or final-report stages.

## What is in the pack

| File | What it answers | When you open it |
| --- | --- | --- |
| `00-START-HERE.md` | Orientation, quick-start, how the pack fits together | Now, before an incident |
| `01-DECISION-TREE.md` | "Does this trigger an Article 14 report?" | First 60 minutes, every time |
| `02-TIMELINE-AND-CLOCKS.md` | When each deadline falls and how to compute it | As soon as awareness is declared |
| `03-REPORT-TEMPLATES.md` | Fill-in-the-blank text for all three stages | Before you open the reporting platform |
| `04-EVIDENCE-LOG.md` | The record that proves when you knew and why you decided | Continuously, from the first signal |
| `05-ROLES-AND-DRY-RUN.md` | Who does what; a 30-minute tabletop script | Before an incident, and at handover |

The pack is deliberately paper-first. Everything in it works on a phone, at 03:00, from a hotel, with no access to internal tooling.

## Where reports go

Notifications under Article 14(1) and (3) are submitted through the **single reporting platform** established by ENISA under Article 16. You submit once. The submission goes to the **CSIRT designated as coordinator** that you select, and is simultaneously made available to **ENISA** (subject to the narrow exception in Article 16(2)). That CSIRT then disseminates to other Member States' CSIRTs where you have indicated the product is available.

- Platform entry point: `https://portal.cra-srp.enisa.europa.eu` — `[VERIFY: confirm the current entry point on ENISA's Single Reporting Platform page before relying on this URL]`
- Access requires an **EU Login account with multi-factor authentication enabled**, held personally by each Assigned Representative who will submit.
- Your coordinating CSIRT is determined by Article 14(7): normally the Member State of your main establishment in the Union — the place where decisions about the cybersecurity of your products are predominantly taken. If you have no main establishment in the Union, the fallback order is authorised representative, then importer, then distributor, then user concentration.
- `[VERIFY: your coordinating CSIRT and its contact details — see ENISA's published list of CSIRTs designated as coordinators, and your national CSIRT's own website]`

Selecting the wrong coordinating CSIRT can cause a notification to be invalidated and require resubmission. Determine yours **before** you need it and record it in the wall-chart in `05-ROLES-AND-DRY-RUN.md`.

## How to use this pack in the first hour

Assume a signal has just arrived: a customer report, a threat-intel advisory, a honeypot hit, an anomalous telemetry cluster, a message from a national agency.

**Minutes 0–10 — Open the log, do not start the clock.**
Open `04-EVIDENCE-LOG.md` and record the signal: what arrived, from whom, at what UTC timestamp, and the raw text. Receiving an unverified tip is **not** awareness. Recording it is how you later prove the difference.

**Minutes 10–40 — Run the decision tree.**
Work `01-DECISION-TREE.md` top to bottom with the technical verifier. The tree has six gates: product in scope; made available on the EU market; real-world exploitation evidence (not CVSS, not a public proof-of-concept); reachability in *your* product if the flaw came from a third-party component; the severe-incident test; and the awareness test. Write the answer and the reason for each gate into the log as you go.

**Minute 40 — Declare or defer, explicitly.**
Either the initial assessment yields a **reasonable degree of certainty** that a vulnerability in your product is being actively exploited or that a severe incident has occurred and compromised your product's security — in which case you declare awareness, stamp T0 in UTC, and the 24-hour clock starts — or it does not, in which case you record precisely what is still missing and set a named re-assessment time. Silence is the one outcome that is not available. The Commission's guidance emphasises **prompt action** to carry out the initial assessment; you cannot defer awareness by declining to investigate.

**Minutes 40–60 — Start the reporting track in parallel with the technical track.**
The accountable reporter takes `02-TIMELINE-AND-CLOCKS.md`, writes the three deadlines on the wall in UTC, and begins drafting the early warning from the template in `03-REPORT-TEMPLATES.md`. Meanwhile engineering continues the investigation. These two tracks must not be serialised — waiting for engineering to "finish" is how the 24 hours are lost.

## Ten-line quick-start

1. Signal arrives. Log it verbatim with a UTC timestamp. Do not yet call it awareness.
2. Page the accountable reporter and the technical verifier. One name each, no committees.
3. Run `01-DECISION-TREE.md`. Record an answer and a reason at every gate.
4. Exploitation evidence means observed real-world abuse, not a high CVSS score and not a public PoC.
5. Third-party component? Ask whether the flaw is reachable and actually exploited **in your product**.
6. If yes at every gate: declare awareness. Stamp **T0 in UTC** in the evidence log. Say it out loud.
7. Compute and post the three deadlines: T0+24h, T0+72h, and the final-report date (`02-TIMELINE-AND-CLOCKS.md`).
8. File the early warning by T0+24h even if you still know very little. It is designed to be thin.
9. Inform impacted users as required by Article 14(8), proportionately — this is a separate duty from notifying the CSIRT.
10. If you decide **not** to report, write the reason, the evidence relied on, and the decision-maker's name in `04-EVIDENCE-LOG.md`. That entry is your defence.

## Companion tooling

The free, MIT-licensed CLI **`cra-watch`** scans a project's dependencies and flags components carrying CVEs listed in the CISA Known Exploited Vulnerabilities (KEV) catalog. The KEV catalog is a free JSON feed at `https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json`; as of 11 September 2026 it carried 1,709 entries.

Use it correctly. A KEV listing is strong practical evidence that a vulnerability is being exploited *somewhere in the world* — it is an excellent trigger for an initial assessment, and it is the input this pack expects. It is **not** a legal determination that the vulnerability is being exploited **in your product**, and CISA's catalog is a US federal instrument with no status under the CRA. The step from "KEV-listed component in my SBOM" to "actively exploited vulnerability contained in my product with digital elements" is exactly the reachability question at gate 4 of the decision tree, and it is yours to answer and document.

## Maintenance

Review this pack whenever any of the following changes: your main establishment in the Union; your authorised representative, importers or distributors; the identity of the accountable reporter or deputy; the product inventory made available on the EU market; or the published guidance from the Commission, ENISA or your coordinating CSIRT. Run the tabletop in `05-ROLES-AND-DRY-RUN.md` at least twice a year and after every change of accountable reporter.
