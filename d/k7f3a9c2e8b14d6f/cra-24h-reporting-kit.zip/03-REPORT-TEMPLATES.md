# Report Templates

This pack is engineering and process tooling, not legal advice. Verify against Regulation (EU) 2024/2847 and guidance from your coordinating national CSIRT before filing.

---

## How to use these templates

These are **drafting templates**, not a replica of any submission form. You draft here — offline, in a document you control — and then transcribe into the reporting platform. Three reasons this order matters:

1. The platform is a web form. Drafting in it risks losing work, and it gives you no version history of what you said and when.
2. You need your own copy of every word submitted. The platform is not your evidence archive; `04-EVIDENCE-LOG.md` is.
3. Drafting offline forces the reporter to write complete sentences rather than fragments, which is what makes the record defensible six months later.

The field names below follow the structure of Article 14 and the categories the platform's published guidance describes. Exact on-screen labels, character limits and which fields are mandatory at each stage can change between platform releases. `[VERIFY: the current field list, character limits and mandatory/optional status against the platform's published glossary and user guidance before submitting]`

**Writing standard for every field.** Factual, neutral, dated, attributed. Write what you observed and what you concluded, and mark the difference between them. No hedging adverbs, no marketing language, no blame, no speculation about actors you have not evidenced, no promises about future timelines you do not control. If a fact is estimated, say it is estimated. If something is unknown, write "not established as at <UTC timestamp>" rather than leaving a blank.

---

## Template 1 — EARLY WARNING (within 24 hours of becoming aware)

```
=== CRA ARTICLE 14 EARLY WARNING - DRAFT ===
Internal reference          : ________________________________
Drafted by                  : ________________________________
Reviewed by                 : ________________________________
Draft completed (UTC)       : ____-__-__ __:__
Submitted (UTC)             : ____-__-__ __:__
Platform submission ref     : ________________________________

--- ROUTING ---
Notification type           : [ ] Actively exploited vulnerability
                              [ ] Severe incident
Manufacturer (legal name)   : ________________________________
CSIRT designated as
  coordinator selected      : ________________________________
Basis for that selection    : [ ] main establishment in the Union
                              [ ] authorised representative
                              [ ] importer  [ ] distributor  [ ] users
Member States where the
  product has been made
  available (as known)      : ________________________________

--- SUBJECT ---
Title (short, specific)     : ________________________________
Summary (factual overview:
  what is affected, what is
  happening, current
  mitigation status)        : ________________________________
                              ________________________________
Product name                : ________________________________
Product version / build /
  model / firmware range    : ________________________________
Affected component (if
  attributable)             : ________________________________
CVE ID (if assigned)        : ________________________________
EUVD ID (if assigned)       : ________________________________

--- TIMING ---
Date/time became aware
  (T0, UTC)                 : ____-__-__ __:__   [ ] exact [ ] estimated
Basis of the awareness
  determination             : ________________________________

--- VULNERABILITY TRACK ONLY ---
Nature of exploitation
  observed (one or two
  factual sentences)        : ________________________________

--- INCIDENT TRACK ONLY ---
Suspected to be caused by
  unlawful or malicious
  acts?                     : [ ] Yes  [ ] No  [ ] Unknown
Date/time incident occurred
  or began (UTC, if known)  : ____-__-__ __:__   [ ] exact [ ] estimated

--- STATUS ---
Mitigating measure expected
  shortly?                  : [ ] Yes  [ ] No  [ ] Unknown
User action currently able
  to reduce impact          : ________________________________
Known unknowns at this
  stage (state explicitly)  : ________________________________
=== END ===
```

### What good looks like — early warning

> **Title:** Active exploitation of authentication bypass in GW-500 gateway firmware 4.2.1
>
> **Summary:** On 2026-10-15 a customer reported anomalous outbound traffic from the management interface of a GW-500 appliance running firmware 4.2.1. Customer-supplied logs show authentication being bypassed on the management interface, followed by privileged API calls from an external address. Our security team reproduced the bypass against a stock 4.2.1 build on 2026-10-15 and assesses the customer logs as showing exploitation rather than misconfiguration. Affected version range is under confirmation; 4.2.1 is confirmed affected. No corrective measure is available yet. Interim user guidance is being prepared.
>
> **Product:** GW-500 edge gateway. **Versions:** 4.2.1 confirmed affected; 4.0 to 4.2.0 under assessment.
>
> **Member States where made available:** Belgium, Greece, Italy.
>
> **Became aware (UTC):** 2026-10-15 18:40, exact. **Basis:** internal reproduction of the reported bypass against a stock build, combined with customer logs showing post-bypass privileged API activity from an external address.
>
> **Nature of exploitation observed:** unauthenticated requests to a management-interface endpoint were accepted and executed with administrative privilege on a customer-operated unit.
>
> **Mitigating measure expected shortly:** Yes.
>
> **Known unknowns:** full affected version range; whether other customers are affected; root cause within the authentication path; actor identity.

Why this is good: every sentence is either an observation with a source or a stated conclusion with its basis. The affected range is honest about what is confirmed versus under assessment. The awareness basis is a specific event, not "we decided". The unknowns are listed rather than hidden, and they map directly onto the work that will fill the 72-hour notification. It took about twenty minutes to write.

Contrast with a bad early warning: *"We are investigating a potential security issue in one of our products and will provide more information when available."* That names no product, no version, no Member State, no awareness basis and no observed behaviour. It is functionally unactionable for a CSIRT, and it creates no record that helps you later.

---

## Template 2 — 72-HOUR NOTIFICATION (within 72 hours of becoming aware)

This is the vulnerability notification under Article 14(2)(b) or the incident notification under Article 14(4)(b). Carry forward everything from the early warning, update anything that has changed, and add the substance below. Where information has already been provided and remains accurate, it does not need to be repeated — but do not leave a materially changed fact uncorrected.

```
=== CRA ARTICLE 14 - 72-HOUR NOTIFICATION - DRAFT ===
Internal reference          : ________________________________
Links to early warning ref  : ________________________________
Drafted / reviewed by       : ________________________________
Submitted (UTC)             : ____-__-__ __:__
T0 (awareness, UTC)         : ____-__-__ __:__
Deadline (T0 + 72h, UTC)    : ____-__-__ __:__

--- CARRIED FORWARD / UPDATED ---
Notification type           : ________________________________
Product name                : ________________________________
Product version range
  (updated)                 : ________________________________
Member States where made
  available (updated)       : ________________________________
Component name and version  : ________________________________
CVE ID / EUVD ID            : ________________________________
Product regulatory type     : [ ] default [ ] important [ ] critical
Product class / category
  (if applicable)           : ________________________________
End of support period
  reached?                  : [ ] Yes  [ ] No

--- VULNERABILITY TRACK ---
General information about
  the vulnerability and how
  the known exploit operates: ________________________________
Affected function / required
  access / observed
  exploitation behaviour    : ________________________________
Attack vector               : ________________________________
Assessed severity, with the
  rationale for the rating  : ________________________________

--- INCIDENT TRACK ---
General information about
  the nature of the incident: ________________________________
Initial assessment (severity,
  scope, affected security
  properties, likely impact;
  separate confirmed from
  under investigation)      : ________________________________
Suspected unlawful or
  malicious acts?           : [ ] Yes  [ ] No  [ ] Unknown

--- MEASURES ---
Corrective or mitigating
  measures TAKEN by us,
  with dates (UTC)          : ________________________________
Corrective or mitigating
  measures USERS can take   : ________________________________
Date/time any mitigating
  measure became available
  to users (UTC)            : ____-__-__ __:__
Users informed under
  Art. 14(8)?               : [ ] Yes  [ ] No  [ ] In progress
  - how, and to whom        : ________________________________

--- HANDLING ---
Sensitivity of the notified
  information - what is
  sensitive and what the
  consequence of premature
  or wider disclosure would
  be (specific, not generic) : ________________________________
Grounds for restricted or
  delayed dissemination
  considered?               : [ ] Yes  [ ] No
  - if yes, which and why   : ________________________________

--- STILL OPEN ---
Outstanding investigation
  items, with owners and
  target dates              : ________________________________
=== END ===
```

### What good looks like — 72-hour notification

> **General information about the vulnerability:** A missing authentication check on the `/api/v1/admin` endpoint of the GW-500 management interface allows a remote actor with network access to the management interface to invoke privileged operations without credentials. The observed exploitation consists of a direct unauthenticated POST to that endpoint, followed by creation of a persistent administrative account. Exploitation requires network reachability of the management interface; units with the management interface bound to a trusted network segment only are not reachable from the internet.
>
> **Affected versions:** firmware 4.0 through 4.2.1 inclusive. Versions prior to 4.0 do not contain the affected endpoint.
>
> **Attack vector:** remote, over the network, via the exposed HTTPS management interface. No authentication and no user interaction required.
>
> **Assessed severity:** High. Rationale: unauthenticated remote access to administrative functions, confirmed exploitation in the wild on at least one customer-operated unit, no authentication or user interaction required. Mitigating factor: exploitation requires network reachability of the management interface, which our documented deployment guidance instructs users to restrict.
>
> **Corrective or mitigating measures taken:** 2026-10-16 16:30 UTC — advisory published to all customers with instructions to restrict management-interface access to trusted networks. 2026-10-16 08:00 UTC — detection signature shared with our support organisation to identify the exploitation pattern in customer logs. Firmware 4.2.2 in test; release targeted for the week commencing 2026-10-19.
>
> **Measures users can take:** Restrict access to the management interface to trusted network segments. Review management-interface logs for unauthenticated requests to `/api/v1/admin` since 2026-09-01. Review the administrative account list for accounts not created by your administrators. Install firmware 4.2.2 when available.
>
> **Users informed:** Yes — advisory published on the customer portal and emailed to all registered GW-500 administrators on 2026-10-16 16:30 UTC.
>
> **Sensitivity:** The endpoint path and request structure describe an exploitation path for which no security update is yet available. Wider publication before 4.2.2 ships would enable exploitation of units that have not yet applied the network restriction.

Why this is good: the severity rating carries its reasoning, so a reader can disagree with the rating without having to re-derive the facts. Measures taken carry UTC timestamps, which is what lets anyone reconstruct the 14-day final-report clock. User actions are ordered by effectiveness and are specific enough to execute. The sensitivity statement identifies the specific sensitive element and the specific consequence of disclosure, rather than asserting general confidentiality.

---

## Template 3 — FINAL REPORT

Two different deadlines apply — see `02-TIMELINE-AND-CLOCKS.md`:

- **Actively exploited vulnerability:** no later than **14 days after a corrective or mitigating measure is available**.
- **Severe incident:** within **one month after submission of the 72-hour notification**.

```
=== CRA ARTICLE 14 FINAL REPORT - DRAFT ===
Internal reference          : ________________________________
Links to EW / 72h refs      : ________________________________
Drafted / reviewed by       : ________________________________
Submitted (UTC)             : ____-__-__ __:__

--- DEADLINE BASIS ---
Track                       : [ ] Vulnerability  [ ] Severe incident
Vulnerability: date/time the
  corrective or mitigating
  measure became available  : ____-__-__ __:__
  -> due 14 days later      : ____-__-__ __:__
Incident: date/time the 72h
  notification was submitted: ____-__-__ __:__
  -> due one month later    : ____-__-__ __:__

--- VULNERABILITY TRACK (Art. 14(2)(c)) ---
(i) Full description of the
    vulnerability, including
    its SEVERITY            : ________________________________
(i) Full description of the
    vulnerability, including
    its IMPACT (systems,
    components, data, users,
    services affected)      : ________________________________
(ii) Information on any
    malicious actor that has
    exploited or is
    exploiting it, where
    available (observed
    indicators; state
    plainly if attribution
    is unknown)             : ________________________________
(iii) Details of the security
    update or other
    corrective measures made
    available to remedy it  : ________________________________
    - version / build       : ________________________________
    - release date (UTC)    : ____-__-__ __:__
    - distribution method   : ________________________________
    - user action required  : ________________________________

--- INCIDENT TRACK (Art. 14(4)(c)) ---
(i) Detailed description of
    the incident, including
    its SEVERITY            : ________________________________
(i) Detailed description of
    the incident, including
    its IMPACT              : ________________________________
(ii) Type of threat or root
    cause likely to have
    triggered the incident  : ________________________________
(iii) Applied and ongoing
    mitigation measures     : ________________________________

--- CLOSE-OUT ---
Uptake / remediation status
  as known (e.g. proportion
  of fleet updated)         : ________________________________
Users informed under
  Art. 14(8) - final status : ________________________________
Reported upstream to the
  component maintainer
  (Art. 13(6)), if
  applicable                : [ ] Yes [ ] No [ ] N/A   date: ____-__-__
Changes made to prevent
  recurrence                : ________________________________
Residual risk and any
  remaining exposure        : ________________________________
=== END ===
```

### What good looks like — final report

> **Full description including severity:** The GW-500 management interface exposed `/api/v1/admin` without an authentication check, as a result of an authorisation middleware registration that was not applied to routes added in release 4.0. Any party able to reach the management interface over the network could invoke administrative operations, including creation of persistent administrative accounts. Assessed severity: High — unauthenticated remote administrative access, confirmed exploited in the wild, no user interaction required. Affected versions 4.0 through 4.2.1 inclusive.
>
> **Impact:** Exploitation grants full administrative control of the affected appliance, including configuration change, traffic interception on interfaces terminating at the device, and persistence through account creation. Confirmed exploitation was observed on two customer-operated units. Log review across the supported fleet identified the exploitation pattern on no further units. No evidence was found of exploitation of our own infrastructure or of the firmware build or distribution systems.
>
> **Malicious actor:** Attribution is unknown. Observed activity originated from two IP addresses in commercial hosting ranges; indicators were shared with affected customers and with `[VERIFY: recipient — e.g. your coordinating CSIRT, where they have requested indicators]` on 2026-10-20. The tooling observed is consistent with opportunistic mass scanning rather than targeted activity; this is an assessment, not a confirmed finding.
>
> **Corrective measures made available:** Firmware 4.2.2, released 2026-10-22 09:15 UTC, applies the authorisation middleware to all management-interface routes and adds a startup check that fails closed if any route is registered without an authorisation policy. Distributed via the standard update channel and as a signed image on the customer portal. Users must apply the update; no automatic update is performed on this product line. The network-restriction workaround published on 2026-10-16 remains effective for units that cannot be updated immediately.
>
> **Remediation status as at 2026-11-03:** 71 % of units reporting telemetry are on 4.2.2. Direct follow-up is under way with customers whose units have not updated.
>
> **Changes to prevent recurrence:** the startup fail-closed check described above; a CI test asserting that every registered route carries an authorisation policy; extension of the pre-release test suite to cover unauthenticated access to all management endpoints.
>
> **Residual risk:** units not yet updated and not applying the network restriction remain exploitable. Ongoing customer outreach is tracked internally as `[internal reference]`.

Why this is good: the root cause is a specific, checkable engineering fact rather than a category ("human error"). The impact section states both what was found and the extent of the search that found it, which is what distinguishes "we looked and found nothing further" from "we did not look". Attribution is explicitly marked unknown and the assessment is labelled as an assessment. Recurrence prevention is concrete and testable. Residual risk is stated rather than implied.

---

## Pre-submission checklist

Run this before every submission, at every stage.

- [ ] Correct notification type selected — vulnerability or incident.
- [ ] Correct coordinating CSIRT selected, with the Article 14(7) basis recorded. Selecting the wrong one can invalidate the notification and require resubmission.
- [ ] Product name and version range match the technical documentation, not marketing naming.
- [ ] Member State list reflects distributor, importer and authorised-representative records, not just direct sales.
- [ ] Every timestamp is UTC and labelled as exact or estimated.
- [ ] Every factual claim has a source you could produce.
- [ ] Every conclusion is marked as a conclusion, with its basis.
- [ ] No speculation about actors, scope or root cause presented as fact.
- [ ] Unknowns stated as unknowns, not omitted.
- [ ] Sensitivity statement, where used, is specific about what is sensitive and why.
- [ ] The full submitted text is saved to the evidence log with its UTC submission time and the platform reference.
- [ ] The next deadline is computed, written down, and in a calendar with an alarm.
- [ ] Article 14(8) user-information duty considered and its status recorded — this is a separate obligation from notifying the CSIRT, and it is risk-based and proportionate: informing impacted users does not necessarily mean publishing details to the world.
