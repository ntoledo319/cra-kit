# Roles and Dry Run

This pack is engineering and process tooling, not legal advice. Verify against Regulation (EU) 2024/2847 and guidance from your coordinating national CSIRT before filing.

---

## The staffing principle

Article 14 compresses a regulatory filing into 24 hours. The organisations that fail it rarely lack technical capability; they lack **availability and authority** at the moment the clock starts. Two failure patterns account for most misses:

- **No single owner.** Everybody assumed somebody was watching the deadline. The technical investigation absorbed all attention and the filing was nobody's specific job.
- **Authority sitting above availability.** The only person authorised to submit was unreachable, and nobody else believed they were allowed to press the button.

So the model here is deliberately small and deliberately explicit: **one accountable reporter, one deputy with identical authority, one technical verifier, one communications lead.** Four named humans. Not four teams, not four job titles.

---

## Roles in the first 24 hours

### 1. Accountable reporter (single, named)

**Owns:** the decision that awareness has occurred, the T0 stamp, every deadline, and every submission.

- Declares awareness and stamps T0 in UTC in the evidence log. This is a decision, not a consensus.
- Computes the three deadlines and posts them, in UTC, where everyone working the event can see them.
- Drafts and submits the early warning, the 72-hour notification and the final report.
- Decides which coordinating CSIRT applies under Article 14(7) and records the basis.
- Owns the evidence log's integrity — entries get made, nothing gets overwritten.
- Has **standing authority to file without further approval.** Write this down and have it signed by whoever needs to sign it, once, in advance. An approval chain that requires an executive who is on a flight is a defect, not a control.

**Must have, in advance:** a personal EU Login account with MFA enabled; registration on the reporting platform as Primary Assigned Representative; a tested login within the last quarter; the coordinating CSIRT determination already made and written down; the product inventory with Member State availability.

**Does not do:** the technical investigation. The reporter who disappears into a debugger stops watching the clock.

### 2. Deputy reporter (single, named)

**Owns:** everything the accountable reporter owns, whenever the accountable reporter is unreachable.

- Identical authority. Not "can escalate to" — can file.
- Registered on the platform as a Secondary Assigned Representative, with their own EU Login and MFA, tested.
- Takes the file on a defined handover, with a verbal statement of T0 and the three deadlines, echoed back.
- Covers the rota so that at no hour is there zero people with filing authority. Handover happens at a stated UTC time, recorded in the log.

The deputy is not a backup in the sense of "we'll find someone". Deputy is a duty with a name on it and a tested platform login.

### 3. Technical verifier (single, named, may rotate)

**Owns:** the factual answers the decision tree needs.

- Runs gates 1 to 5 of `01-DECISION-TREE.md`: product identification, version range, exploitation evidence, third-party component reachability, severe-incident test.
- Performs and records the reachability analysis when a third-party component is involved — the most contestable judgement in the process.
- Runs the negative searches (fleet telemetry, support tickets, build-system logs) and records their scope and period, not just their result.
- States findings as observations, and states conclusions as conclusions with their basis.
- Tells the reporter the moment a mitigating or corrective measure becomes available to users, with the UTC timestamp, because that starts the 14-day final-report clock.

**Explicitly not owned by the verifier:** the awareness decision. The verifier supplies facts and a technical opinion; the reporter makes the call and carries it.

### 4. Communications lead (single, named)

**Owns:** Article 14(8) — informing impacted users, and where appropriate all users — plus all outward messaging.

- Prepares user-facing advisories: what is affected, what users should do, in what order.
- Applies the risk-based, proportionate standard from the Commission's guidance of 27 July 2026, Section 9.1: informing users does not automatically mean publishing full technical detail to the world, particularly where the product is used in sensitive environments and public detail could increase risk. Broader disclosure becomes appropriate once the issue is adequately addressed or mitigated.
- Keeps the customer-facing message consistent with what was filed. Divergence between a public statement and a regulatory notification is a self-inflicted problem.
- Handles press, customer escalations and account-team traffic so the reporter and verifier are not interrupted.
- **Never** holds up the early warning to align a press cycle. The notification to the CSIRT is confidential and is not a public disclosure; Article 16(2) exists for genuine coordination needs.

### Supporting, not on the critical path

- **Legal counsel** — advises on interpretation and on interaction with other regimes (NIS2, DORA, GDPR — the same event may trigger separate duties on separate clocks). Advises; does not gate the filing.
- **Executive sponsor** — informed, resources the response, does not approve individual filings.
- **Records owner** — ensures evidence artefacts are stored with hashes and survive laptop reimaging and staff departures.

---

## The first 24 hours, by the clock

| Window | Accountable reporter | Technical verifier | Comms lead |
| --- | --- | --- | --- |
| T-minus (signal received) | Open the evidence log. Record the signal verbatim with UTC timestamp and source. Do **not** declare awareness. | Begin the initial assessment immediately. Promptness here is itself part of the legal standard. | Standby. Hold all outward statements. |
| Assessment | Run the decision tree with the verifier. Record an answer and a reason at every gate. | Answer gates 1–5. Reproduce, verify, search, record negatives. | Prepare a holding position for inbound customer questions. |
| T0 | Declare awareness. Stamp T0 in UTC. Say it aloud on the call. Post the three deadlines. | Continue investigation; feed facts to the reporter as they land. | Begin drafting the user advisory. |
| T0 + 0–4h | Draft the early warning from the template. Confirm the coordinating CSIRT and the Member State list. | Confirm affected version range as far as possible. Assess whether a severe-incident track also arises. | Circulate the advisory draft for technical accuracy. |
| T0 + 4–12h | Submit the early warning as soon as it is accurate. Do not wait for the deadline. | Root-cause work; scope of affected fleet. | Publish user guidance once a workaround exists. Record UTC time. |
| T0 + 12–24h | Confirm submission recorded in the log with platform reference. Set alarms for the 72-hour deadline. Brief the deputy; hand over if needed. | Continue. Report the exact UTC time any mitigating measure becomes available to users. | Track customer questions; feed recurring ones into the 72-hour notification's user-actions field. |

---

## 30-minute tabletop dry run

Run this twice a year, and after every change of accountable reporter. Thirty minutes, four people, one facilitator, no laptops except the one holding the evidence log. The facilitator holds the injects and does not participate.

**Objective:** prove that awareness can be declared, deadlines computed, and an early warning drafted, by the people who will actually have to do it, without looking anything up that should already be written down.

### Setup (2 minutes)

Facilitator states: "This is an exercise. Nothing filed today is real. We are testing the process, not the people. All times are UTC and today is a Friday — the exercise clock starts at 16:10 UTC." Confirm the four roles are present and who is playing each.

### Inject 1 — the signal (minute 2)

> **16:10 UTC.** An email arrives at the product security inbox from a customer's security operations centre: *"We had an intrusion. Our forensics people think the entry point was your appliance. We're still working on it — will send logs when we can. Someone should probably look at this."*
>
> Separately, a support engineer mentions in a channel that a security researcher posted on a public forum two days ago about "auth weirdness" in your product line. Nobody followed it up.

**Questions to the team (5 minutes):**

1. Has the clock started? (Correct answer: **no.** This is a signal. It starts the duty to assess promptly, not the 24 hours.)
2. What goes in the evidence log right now, and who writes it?
3. Who is paged, and how — by name and by what mechanism? Does that mechanism work at 16:10 on a Friday?
4. What is asked of the customer, and by whom?
5. What is done about the two-day-old forum post? (Log it as a signal; assess it; note that it was not connected to anything at the time.)

**Failure to watch for:** the team starts debugging and nobody opens the log.

### Inject 2 — evidence firms up (minute 7)

> **18:05 UTC.** The customer sends management-interface logs. They show unauthenticated requests to an administrative endpoint being accepted, followed by creation of an administrative account the customer says they did not create. Your engineer reproduces the same behaviour against a stock build of the current release in the lab at 18:40.
>
> The affected code path came from a third-party library you bundle.

**Questions to the team (8 minutes):**

1. Is this now awareness? If yes, what exactly is T0 and who declares it? (Expected: **yes**, T0 = 18:40 UTC, declared by the accountable reporter — reasonable certainty after initial assessment.)
2. The flaw came from a third-party component. Does that change anything? (Expected: you must still assess reachability — but here it **is** reachable and **has been** exploited in your product, so you report. The component's own manufacturer may also owe a report; that does not discharge yours.)
3. Compute the deadlines out loud, in UTC. (Early warning: Saturday 18:40. 72-hour notification: Monday 18:40. Final report: 14 days after a corrective or mitigating measure is available — not yet computable.)
4. Who is working Saturday? Name them.
5. Does the accountable reporter have platform access **right now**? Have them state their EU Login status from memory. If the answer involves "I'd have to check", that is a finding.

**Failure to watch for:** the team waits for root cause before declaring awareness. Reasonable certainty is not certainty.

### Inject 3 — the complication (minute 15)

> **21:30 UTC.** The accountable reporter's phone goes to voicemail; they are on a long-haul flight and unreachable for nine hours. Separately, a journalist emails the press address asking about "a breach at one of your customers".
>
> Engineering reports they will not have a fix or a workaround before Monday.

**Questions to the team (8 minutes):**

1. Who files the early warning? Does the deputy have platform access and standing authority, in writing? (If anyone says "we'd wait for them to land" — that is the finding of the day.)
2. Exactly how does the handover happen, and what is written in the log?
3. What does the comms lead say to the journalist? What does the comms lead **not** say?
4. Does the absence of a fix delay the early warning? (No. The early warning is deliberately thin. File with what you have and state the unknowns.)
5. Draft the early warning summary field out loud, in three sentences. Facilitator judges it against the standard in `03-REPORT-TEMPLATES.md`: factual, neutral, dated, unknowns stated.

**Failure to watch for:** any suggestion of holding the notification to coordinate a public statement.

### Debrief (minute 23 to 30)

Score four things. Write each finding with an owner and a due date, and put them in the same tracker as engineering work.

| # | Check | Pass criterion |
| --- | --- | --- |
| 1 | Awareness | The team distinguished signal from awareness, and declared T0 at the right moment with a stated basis. |
| 2 | Authority | Someone could have filed at every hour of the scenario, with tested platform access. |
| 3 | Arithmetic | All three deadlines computed correctly in UTC, out loud, without a calculator argument. |
| 4 | Artefact | The evidence log contains contemporaneous entries a stranger could follow. |

Common findings, in rough order of frequency: only one person has platform access; nobody can state the coordinating CSIRT from memory or find it in under a minute; the Member State availability list does not exist; the deputy's authority is assumed rather than written; the log was not opened until after T0.

---

## One-page wall chart

Print this. Put it where the on-call engineer can see it. Fill in the bracketed fields before you need them.

```
+==========================================================================+
|              CRA ARTICLE 14 - FIRST 24 HOURS - WALL CHART                |
|  Not legal advice. Verify against Regulation (EU) 2024/2847 and your     |
|  coordinating national CSIRT's guidance before filing.                   |
+==========================================================================+
|                                                                          |
|  WHO                                                                     |
|   Accountable reporter : [name] .................. [phone] ............   |
|   Deputy reporter      : [name] .................. [phone] ............   |
|   Technical verifier   : [name] .................. [phone] ............   |
|   Comms lead           : [name] .................. [phone] ............   |
|   Both reporters have EU Login + MFA and platform access. Tested: [date]  |
|                                                                          |
|  WHERE REPORTS GO                                                        |
|   Single reporting platform (ENISA, Art. 16)                             |
|   Coordinating CSIRT  : [VERIFY: your CSIRT designated as coordinator]    |
|   Basis (Art. 14(7))  : [main establishment / AR / importer / dist / users]|
|   Member States where our products are made available:                   |
|     [.....................................................]              |
|                                                                          |
+--------------------------------------------------------------------------+
|  STEP 1  SIGNAL           Log it. UTC timestamp + source.                |
|                           THIS IS NOT AWARENESS. Assess it NOW.          |
|                                                                          |
|  STEP 2  ASSESS           Run 01-DECISION-TREE.md. Six gates:            |
|                            1 product with digital elements?              |
|                            2 made available on the EU market?            |
|                            3 reliable evidence of real-world             |
|                              exploitation? (NOT CVSS. NOT a PoC.)        |
|                            4 third-party component - reachable AND       |
|                              exploited IN OUR product?                   |
|                            5 or: severe incident, Art. 14(5)?            |
|                            6 reasonable certainty after assessment?      |
|                                                                          |
|  STEP 3  DECLARE          Reasonable degree of certainty = AWARENESS.    |
|                           STAMP T0 IN UTC. SAY IT ALOUD. LOG IT.         |
|                                                                          |
|  STEP 4  CLOCKS           T0 + 24h  -> EARLY WARNING                     |
|                           T0 + 72h  -> FULLER NOTIFICATION               |
|                           Vulnerability: FINAL REPORT 14 DAYS after a    |
|                             corrective or mitigating measure is          |
|                             AVAILABLE                                    |
|                           Severe incident: FINAL REPORT 1 MONTH after    |
|                             the 72-hour notification is SUBMITTED        |
|                           No weekend or holiday extension. Ever.         |
|                                                                          |
|  STEP 5  FILE             At 24h, file even if you know little.          |
|                           The early warning is MEANT to be thin.         |
|                           State unknowns as unknowns. Never guess.       |
|                                                                          |
|  STEP 6  USERS            Art. 14(8): inform impacted users, and where   |
|                           appropriate all users. Risk-based and          |
|                           proportionate - not automatically public.      |
|                                                                          |
|  STEP 7  RECORD           Evidence log: every signal, action, decision.   |
|                           If you decide NOT to report, WRITE WHY.        |
|                                                                          |
+--------------------------------------------------------------------------+
|  NEVER                                                                   |
|   - Wait for root cause before declaring awareness                       |
|   - Wait for a fix before filing the early warning                       |
|   - Hold the notification to align a press statement                     |
|   - Treat a high CVSS or a public PoC as proof of exploitation           |
|   - Assume a KEV listing means it is exploited IN OUR product            |
|   - Leave a "not reportable" decision undocumented                       |
|                                                                          |
|  SCOPE REMINDERS                                                         |
|   - Products already on the EU market before 11 Dec 2027 ARE in scope    |
|     for Article 14 (Art. 69(3)).                                         |
|   - Reporting duties continue after the support period ends.             |
|   - Penalties for Art. 14 failures: up to EUR 15 000 000 or 2.5 % of     |
|     total worldwide annual turnover, whichever is higher (Art. 64(2)).   |
+==========================================================================+
```

## Pre-incident readiness checklist

Everything below must be true **before** an incident. Each item that is false is a deadline you will miss.

- [ ] Accountable reporter and deputy named in writing, with standing authority to file without further approval.
- [ ] Both hold personal EU Login accounts with MFA enabled, and are registered on the reporting platform (one Primary Assigned Representative, at least one Secondary).
- [ ] A login has been tested within the last 90 days. Record the date.
- [ ] Coordinating CSIRT determined under Article 14(7), with the basis written down, and contact details recorded. `[VERIFY: against ENISA's published list of CSIRTs designated as coordinators and your national CSIRT's website]`
- [ ] Product inventory maintained: every product with digital elements made available on the EU market, including products placed on the market before 11 December 2027 and products past end of support.
- [ ] Member State availability list maintained from importer, distributor and authorised-representative records.
- [ ] A staffed intake channel exists that a customer, researcher or agency can reach, and someone actually watches it outside business hours.
- [ ] On-call rota covers every hour, with named substitutes, and at every hour at least one person holds filing authority.
- [ ] Evidence log location known to all four roles and writable from a phone.
- [ ] Wall chart printed and posted; bracketed fields filled in.
- [ ] Tabletop run within the last six months, with findings closed.
- [ ] Dependency scanning in place so that a KEV-listed CVE in a shipped component surfaces as a trigger to assess, not as a surprise. `cra-watch` produces exactly this input.
