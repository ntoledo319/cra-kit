# Decision Tree — Does this trigger an Article 14 report?

This pack is engineering and process tooling, not legal advice. Verify against Regulation (EU) 2024/2847 and guidance from your coordinating national CSIRT before filing.

---

## How to use this file

Run every gate in order. At each gate write the answer **and the reason** into `04-EVIDENCE-LOG.md` before moving on. The tree is not a formality — the written reasons are what defend either decision later, including the decision not to report.

Two people run it: the **technical verifier** answers the factual questions; the **accountable reporter** owns the conclusion and the timestamp. Do not run it alone, and do not run it in a group larger than three.

## The six gates in one line each

1. **Product** — is it a product with digital elements within CRA scope?
2. **Market** — is it made available on the EU market, by any route?
3. **Exploitation** — is there reliable evidence of real-world exploitation by a malicious actor?
4. **Reachability** — if the flaw came from a third-party component, is it exploitable and exploited *in your product*?
5. **Incident** — alternatively, does this meet the Article 14(5) severe-incident test?
6. **Awareness** — has an initial assessment produced a reasonable degree of certainty? That is when T0 starts.

---

## ASCII decision tree

```
                        SIGNAL RECEIVED
        (customer report, threat intel, telemetry, honeypot,
         agency notification, researcher, media, dark-web find)
                               |
                               v
                 +-------------------------------+
                 | LOG IT. UTC timestamp + source |
                 | This is NOT yet awareness.     |
                 +-------------------------------+
                               |
                               v
            G1. Is it a PRODUCT WITH DIGITAL ELEMENTS?
      (software or hardware product + its remote data processing
       solutions, incl. components placed on the market separately;
       with a direct or indirect logical or physical data connection
       to a device or network - Art. 2(1), Art. 3(1))
                    |                        |
                   NO                       YES
                    |                        |
                    v                        v
        +------------------------+   G2. MADE AVAILABLE ON THE EU MARKET?
        | Out of CRA scope.      |   (supplied for distribution or use on
        | Check sectoral carve-  |    the Union market in the course of a
        | outs actually apply    |    commercial activity, paid or free -
        | (Art. 2(2)-(7)).       |    Art. 3(22); ANY route counts:
        | Log and close.         |    direct, importer, distributor,
        +------------------------+    authorised representative, OEM,
                                      white-label, app store)
                                        |                  |
                                       NO                 YES
                                        |                  |
                                        v                  v
                        +-------------------------+   +-------------------+
                        | Not an EU-market product|   | Continue.         |
                        | -> no Art. 14 duty for  |   | Note: products    |
                        | this product. Other     |   | placed on the     |
                        | duties may still apply. |   | market BEFORE     |
                        | Log and close.          |   | 11 Dec 2027 are   |
                        +-------------------------+   | IN SCOPE for      |
                                                      | Art. 14 (69(3)).  |
                                                      +-------------------+
                                                                |
                    +-------------------------------------------+
                    |                                           |
                    v                                           v
      TRACK A: VULNERABILITY                        TRACK B: INCIDENT
                    |                                           |
                    v                                           v
   G3. ACTIVELY EXPLOITED?                     G5. SEVERE INCIDENT?
   Reliable evidence that a                    Does the incident affect the
   MALICIOUS ACTOR has exploited               SECURITY of the product, and:
   it in a system WITHOUT the                   (a) negatively affect, or be
   system owner's permission                        capable of negatively
   (Art. 3(42)).                                    affecting, the product's
                                                    ability to protect the
   YES-ish evidence:                                availability, authenticity,
     - exploitation observed in                      integrity or confidentiality
       your telemetry / logs                         of SENSITIVE or IMPORTANT
     - customer confirms breach                      data or functions;  OR
       traced to this flaw                     (b) has led, or is capable of
     - credible IR/threat-intel                      leading, to the introduction
       report of in-the-wild use                     or execution of MALICIOUS
     - national agency states it                     CODE in the product or in a
       is being exploited                            user's network and
     - exploit sold/traded with                      information systems?
       evidence of real use                          (Art. 14(5))
                                                      |             |
   NOT sufficient on its own:                        NO            YES
     - high CVSS / EPSS score                         |             |
     - "critical" severity label                      v             |
     - public proof-of-concept                +--------------+      |
     - exploit code on GitHub                 | Not a severe |      |
     - bug-bounty or pentest find             | incident.    |      |
     - researcher disclosure with             | Handle       |      |
       no malicious use                       | internally.  |      |
     - vendor advisory that says              | Log reason.  |      |
       "could be exploited"                   | Art. 15      |      |
                    |                         | voluntary    |      |
          +---------+---------+               | notification |      |
          |                   |               | stays open.  |      |
         NO                  YES              +--------------+      |
          |                   |                                     |
          v                   v                                     |
 +-----------------+   G4. THIRD-PARTY COMPONENT ORIGIN?            |
 | Not an actively |   Did the flaw arrive in a component           |
 | exploited vuln. |   you integrated rather than code you wrote?   |
 | NO mandatory    |             |                    |             |
 | Art. 14 report. |            NO                   YES            |
 | Still required: |             |                    |             |
 |  - vuln         |             |                    v             |
 |    handling     |             |        Is the vulnerable code    |
 |    (from Dec    |             |        REACHABLE and ACTUALLY    |
 |    2027)        |             |        EXPLOITED in YOUR         |
 |  - upstream     |             |        product?                  |
 |    report,      |             |          |              |        |
 |    Art. 13(6)   |             |         NO             YES       |
 | Art. 15         |             |          |              |        |
 | voluntary       |             |          v              |        |
 | notification    |             |  +----------------+     |        |
 | stays open.     |             |  | NOT an AEV     |     |        |
 | LOG THE REASON. |             |  | "contained in  |     |        |
 +-----------------+             |  | your product". |     |        |
                                 |  | No mandatory   |     |        |
                                 |  | report for you.|     |        |
                                 |  | Component      |     |        |
                                 |  | maker may still|     |        |
                                 |  | owe one.       |     |        |
                                 |  | Report upstream|     |        |
                                 |  | (Art. 13(6)).  |     |        |
                                 |  | LOG THE REASON.|     |        |
                                 |  +----------------+     |        |
                                 |                         |        |
                                 +-----------+-------------+        |
                                             |                      |
                                             v                      v
                            G6. AWARENESS TEST — has an initial assessment
                            given you a REASONABLE DEGREE OF CERTAINTY that
                            (i) a vulnerability in your product is being
                            actively exploited, or (ii) a severe incident
                            has occurred and has compromised the security
                            of your product?
                                             |
                             +---------------+---------------+
                             |                               |
                            NO                              YES
                             |                               |
                             v                               v
              +---------------------------+   +-------------------------------+
              | NOT YET AWARE.            |   | AWARENESS DECLARED.           |
              | Keep investigating        |   | STAMP T0 IN UTC. SAY IT ALOUD.|
              | PROMPTLY. Set a named     |   | Deadlines now run:            |
              | re-assessment time.       |   |   EARLY WARNING  T0 + 24h     |
              | Record exactly what is    |   |   NOTIFICATION   T0 + 72h     |
              | missing and who is        |   |   FINAL REPORT   see file 02  |
              | getting it. You CANNOT    |   | Also: inform impacted users   |
              | defer awareness by        |   | (Art. 14(8)), proportionately.|
              | declining to investigate. |   | Go to 03-REPORT-TEMPLATES.md. |
              +---------------------------+   +-------------------------------+
```

---

## Numbered checklist

Complete every line. "Unknown" is a permitted answer only with a named owner and a time by which it will be resolved.

### Gate 1 — Product with digital elements

- [ ] **1.1** Identify the exact product, including version, release, build, model or firmware revision.
- [ ] **1.2** Confirm it is a software or hardware product, or its remote data processing solution, or a component placed on the market separately (Article 3(1)).
- [ ] **1.3** Confirm its intended purpose or reasonably foreseeable use includes a direct or indirect logical or physical data connection to a device or network (Article 2(1)). Fully air-gapped products with no such connection fall outside.
- [ ] **1.4** Confirm none of the exclusions in Article 2(2) to (7) applies — notably medical devices under Regulation (EU) 2017/745 and (EU) 2017/746, motor vehicles under Regulation (EU) 2019/2144, civil aviation products certified under Regulation (EU) 2018/1139, marine equipment under Directive 2014/90/EU, identical spare parts, and products developed exclusively for national security or defence. Confirm the exclusion actually applies to *this* product rather than to your sector generally.
- [ ] **1.5** Confirm you are the **manufacturer** for this product: you develop or manufacture it, or have it designed, developed or manufactured, and market it under your own name or trademark (Article 3(13)). White-labelling someone else's product under your brand makes you a manufacturer.

### Gate 2 — Made available on the EU market

- [ ] **2.1** Is the product supplied for distribution or use on the Union market in the course of a commercial activity — whether for payment or free of charge (Article 3(22))? Free-of-charge distribution counts.
- [ ] **2.2** Check **every** route, not just direct sales: your own sales; an importer established in the Union; a distributor; an authorised representative acting under written mandate; an OEM or white-label partner; a cloud or app-store distribution channel; bundling inside another manufacturer's product.
- [ ] **2.3** List the Member States where, to your knowledge, the product has been made available. You will be asked for this in the early warning.
- [ ] **2.4** Do not exclude the product because it was placed on the market before the CRA applied. **Article 69(3)** makes Article 14 apply to all in-scope products placed on the market before 11 December 2027.
- [ ] **2.5** Do not exclude the product because its support period has ended. Per the Commission guidance of 27 July 2026, Section 9.1, reporting continues to apply after a product is no longer supported.

### Gate 3 — Actively exploited (Track A)

The CRA definition, Article 3(42): *a vulnerability for which there is reliable evidence that a malicious actor has exploited it in a system without permission of the system owner.*

- [ ] **3.1** State the specific evidence of real-world exploitation, with source and UTC timestamp.
- [ ] **3.2** Confirm the evidence shows a **malicious actor** acting **without the system owner's permission**. Recital 68 excludes vulnerabilities discovered with no malicious intent for good-faith testing, investigation, correction or disclosure.
- [ ] **3.3** Explicitly confirm you are **not** relying on any of the following alone: a high CVSS or EPSS score; a "critical" label; a public proof-of-concept; exploit code published on a repository; an advisory saying the flaw "could be" or "is likely to be" exploited; a bug-bounty submission; a penetration-test finding; a coordinated-disclosure report with no evidence of malicious use.
- [ ] **3.4** A KEV listing (CISA Known Exploited Vulnerabilities catalog) or an equivalent government exploitation advisory is strong practical evidence that exploitation is occurring somewhere. Treat it as a trigger to assess, and record it as evidence — but it does not by itself establish exploitation **in your product**. Go to Gate 4.
- [ ] **3.5** Zero-day status is irrelevant to the trigger. A vulnerability with no patch available is reportable when there is reliable evidence of malicious exploitation, and not reportable merely because it is unpatched.
- [ ] **3.6** If the evidence is a rumour, an unattributed social-media post, a vague customer suspicion, or a third-hand claim: this is **not** yet reliable evidence. Record it, assess it promptly, and move to Gate 6 with "not yet aware" — do not close the file.

### Gate 4 — Third-party component reachability (Track A)

Per the Commission guidance of 27 July 2026, Section 9.1, paragraph 218:

- [ ] **4.1** Where your product contains an actively exploited vulnerability **originating from a third-party component**, you as the manufacturer of the finished product are required to notify it. The manufacturer of the component is also required to notify it, if that component was itself placed on the market. Both duties can exist simultaneously; theirs does not discharge yours.
- [ ] **4.2** However, if the vulnerability **cannot be exploited in your product** — for example because the vulnerable code is not reachable in your build, the affected feature is not compiled in, the vulnerable code path is unreachable given your configuration, or a compensating control makes exploitation impossible — then it is not an actively exploited vulnerability *contained in your product* and there is no mandatory report for you.
- [ ] **4.3** Equally, if the vulnerability is reachable in principle but **has not been exploited in your product**, it does not qualify as an actively exploited vulnerability contained in your product, and there is no mandatory report for you.
- [ ] **4.4** Write down the reachability analysis: which version of the component you ship, which code path is affected, whether that path is callable in your product, what configuration or control blocks it, and who verified it. This is the single most contestable judgement in the whole tree and the most likely to be examined later.
- [ ] **4.5** If you conclude "not reportable" at this gate, two obligations remain live: report the vulnerability upstream to the person or entity manufacturing or maintaining the component (Article 13(6)), and handle the vulnerability under Part II of Annex I once those obligations apply. Voluntary notification under Article 15 also remains available.
- [ ] **4.6** Re-run this gate whenever new evidence arrives. A "not reachable" conclusion is valid as of the facts known at the time; it is not permanent.

### Gate 5 — Severe incident (Track B)

The Article 14(5) test. An incident having an impact on the security of the product is **severe** where **either**:

- [ ] **5.1** (a) it negatively affects, or is capable of negatively affecting, the ability of the product to protect the **availability, authenticity, integrity or confidentiality of sensitive or important data or functions**; **or**
- [ ] **5.2** (b) it has led, or is capable of leading, to the **introduction or execution of malicious code** in the product, or in the network and information systems of a user of the product.
- [ ] **5.3** Note the orientation of Track B. Recital 68 describes severe incidents as situations where a cybersecurity incident affects the manufacturer's **development, production or maintenance processes** in a way that could result in increased cybersecurity risk for users — the canonical example being an attacker successfully introducing malicious code into the release channel through which you ship security updates.
- [ ] **5.4** "Capable of" is a forward-looking test. You do not need to wait for harm to materialise. A compromised build server with signing access satisfies (b) before a single malicious artefact reaches a user.
- [ ] **5.5** A general corporate IT breach is not automatically a severe incident under Article 14. Ask specifically whether it affects the security of a **product with digital elements** you make available. A compromise of your CRM is not in Track B; a compromise of your code-signing key is.
- [ ] **5.6** Record whether the incident is **suspected of being caused by unlawful or malicious acts** — the early warning asks for this.
- [ ] **5.7** The same event can be both an actively exploited vulnerability and a severe incident. If so, assess both tracks; they carry different final-report deadlines (see `02-TIMELINE-AND-CLOCKS.md`).

### Gate 6 — Awareness: when the clock starts

The Commission's guidance of 27 July 2026, Section 9.1, paragraphs 211 to 214, is the operative standard, and it is aligned with recital 31 of Commission Implementing Regulation (EU) 2024/2690 and Section II(A) of the EDPB Guidelines 9/2022 on personal data breach notification.

- [ ] **6.1** Where you detect a suspicious event, or a third party — an individual, customer, entity, authority, media organisation or other source — brings a potential incident or vulnerability to your attention, you must **assess the suspicious event immediately**.
- [ ] **6.2** You are regarded as having become aware when, **after that initial assessment**, you have a **reasonable degree of certainty** that (i) a vulnerability contained in your product is being actively exploited, or (ii) a severe incident has occurred and has led to the security of your product being compromised.
- [ ] **6.3** Therefore: a rumour, an unverified tip, an unconfirmed report, or a media claim you have not yet assessed does **not** start the clock. The receipt of that signal starts your **duty to assess promptly**, not the 24-hour deadline.
- [ ] **6.4** Equally: you cannot suppress the clock by not investigating. The guidance places the emphasis on **prompt action** to carry out the initial assessment, particularly where the vulnerability may pose a significant risk. Slow-walking the assessment is not a defence; it is an aggravating fact.
- [ ] **6.5** Certainty is "reasonable", not absolute. You do not need root cause, a patch, an actor attribution, a full scope, or a complete list of affected customers. If you are waiting for any of those before declaring awareness, you have set the bar too high.
- [ ] **6.6** Stamp **T0** as a specific UTC date and time in `04-EVIDENCE-LOG.md`, name the person who declared it, and state the fact that tipped the assessment over into reasonable certainty.
- [ ] **6.7** Vulnerabilities whose **active exploitation you already knew about before 11 September 2026** are not retroactively reportable. But if you knew of the vulnerability before that date and only became aware of its active exploitation after it, the duty applies.
- [ ] **6.8** If the answer is "not yet aware": record what specific fact is missing, who owns getting it, and the UTC time of the next re-assessment. Put that re-assessment in a calendar with an alarm.

---

## Three common wrong answers

**"The CVSS is 9.8, so we must report."** No. Severity is not exploitation. Article 3(42) requires reliable evidence that a malicious actor has exploited the flaw in a system without the owner's permission. A 9.8 with no evidence of real-world abuse is not reportable under Article 14 — though it is very likely worth a voluntary notification under Article 15 and certainly worth a patch.

**"There's a working PoC on GitHub, so it's actively exploited."** No. A public proof-of-concept demonstrates exploitability, not exploitation. It sharply raises the probability that exploitation will follow, which is a reason to raise monitoring and accelerate the fix, and a reason to re-assess frequently — but on its own it is not the reliable evidence the definition requires.

**"The CVE is in our SBOM and it's in KEV, so we have 24 hours."** Not yet. KEV tells you the flaw is being exploited somewhere. Gate 4 asks whether it is reachable and exploited **in your product**. Answer that question, in writing, before the clock is declared — and answer it fast, because if the answer is yes, the clock started when your assessment reached reasonable certainty, not when you finished writing it up.
