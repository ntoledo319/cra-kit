CRA 24-HOUR REPORTING KIT
EU Cyber Resilience Act, Regulation (EU) 2024/2847, Article 14

Reporting obligations have applied since 11 September 2026.

READ IN THIS ORDER

  00-START-HERE.md          The first hour. Start here, always.
  01-DECISION-TREE.md       Do I have to report? Report / don't report.
  02-TIMELINE-AND-CLOCKS.md The 24h / 72h / 14d cascade, worked in UTC.
  03-REPORT-TEMPLATES.md    Fill-in templates for all three filings.
  04-EVIDENCE-LOG.md        The record that defends your decision.
  05-ROLES-AND-DRY-RUN.md   Who does what + a 30-minute tabletop.

IF SOMETHING IS HAPPENING RIGHT NOW
  Go to 01-DECISION-TREE.md, then 03-REPORT-TEMPLATES.md.
  The early warning is deliberately short. File it.

IF NOTHING IS HAPPENING RIGHT NOW
  Run the tabletop in 05-ROLES-AND-DRY-RUN.md this week. Thirty minutes.
  The first time you run this process should not be live.

THE FREE SCANNER
  https://github.com/ntoledo319/cra-watch
  Finds components in your dependency graph that appear on the CISA
  Known Exploited Vulnerabilities catalogue. Run it on a schedule.

Engineering and process tooling, not legal advice. See LICENCE.txt.
© 2026 Toledo Technologies LLC · dev@toledotechnologies.com
