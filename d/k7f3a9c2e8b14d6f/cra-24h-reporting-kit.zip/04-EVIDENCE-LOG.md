# Evidence and Decision Log

This pack is engineering and process tooling, not legal advice. Verify against Regulation (EU) 2024/2847 and guidance from your coordinating national CSIRT before filing.

---

## Why this log is the most important file in the pack

Article 14 hangs two consequences on a single moment in time: **when you became aware**. Every deadline is measured from it, and the maximum penalty tier — up to EUR 15 000 000 or 2.5 % of total worldwide annual turnover, whichever is higher (Article 64(2)) — attaches to failures under Article 14.

That moment is not self-evidencing. It is a judgement you make, in your own building, on partial information. The Commission's guidance of 27 July 2026, Section 9.1, defines it as the point at which, **after an initial assessment**, you have a **reasonable degree of certainty** that a vulnerability in your product is being actively exploited or that a severe incident has occurred and compromised your product's security. That formulation places the burden of demonstrating reasonableness on the party who made the assessment: you.

There are two distinct scenarios in which this log earns its keep.

**You reported.** A market surveillance authority, a customer, or a litigant asks why the early warning arrived on Friday when a security researcher had been discussing the issue publicly since Tuesday. The log shows: Tuesday's chatter was logged as a signal and assessed; the assessment could not connect the chatter to your build; Thursday's customer logs and your reproduction were what produced reasonable certainty; T0 was stamped Thursday 18:40 UTC; the early warning was filed 15 hours later. That is a reasoned, contemporaneous, timestamped chain. Without the log, you have a recollection.

**You did not report.** This is the harder case and the one the log exists for. You concluded that a KEV-listed CVE in a bundled library was not reachable in your product, and you filed nothing. Two years later, someone asks why. If the answer is a Slack thread that has aged out of retention and an engineer who has left the company, you have nothing. If the answer is a log entry naming the component and version you ship, the specific code path, the reason it is unreachable in your build, who verified it, how they verified it, and when — you have a defensible decision. **It is the artefact that defends a decision not to report.** A defensible decision that turns out to be wrong is a very different position from an undocumented decision that turns out to be wrong.

A third, quieter benefit: the log is what makes the 72-hour notification and the final report cheap to write. Everything those reports need was already captured, with timestamps, as it happened.

## Rules for keeping it

1. **Contemporaneous.** Write entries as events happen, not in a reconstruction session afterwards. Reconstructed logs are worth materially less and are usually obvious as reconstructions.
2. **UTC, always.** Every timestamp in UTC, with the format `YYYY-MM-DD HH:MM`. Note whether each is exact or estimated.
3. **Append-only.** Never overwrite an entry. If an earlier entry was wrong, add a new entry correcting it and cross-reference both. A log with visible corrections is more credible than a log with none.
4. **Separate observation from conclusion.** "Customer reports outbound traffic from management interface" is an observation. "This is exploitation of the auth bypass" is a conclusion. Label which is which in the Basis column.
5. **Name people.** Roles are not accountable; people are. Every decision entry carries a named decision-maker.
6. **Log the negatives.** "Checked internal telemetry for the exploitation pattern across the fleet; no matches" is an entry. Searches that found nothing are evidence that you searched.
7. **Attach the artefacts.** Reference the file, ticket, email, log excerpt or advisory by an identifier that will still resolve in five years. Store copies with the log; do not rely on a link to a third-party site or a chat message.
8. **Retain it.** Set a retention period that outlives any plausible enquiry. `[VERIFY: your retention period with your own legal and records-management policy]`
9. **One log per event.** A single event with both a vulnerability track and an incident track shares one log, with the track marked on each entry.
10. **Access control it, but do not make it hard to write.** A log nobody can add to at 03:00 will not be kept. A shared append-only document with named authors beats a formal system nobody can reach.

## Entry types

Use a short type code in every row so the log can be read quickly under pressure.

| Code | Meaning |
| --- | --- |
| `SIG` | Signal received. Something arrived. Not yet assessed. |
| `ACT` | Action taken — investigation step, search, test, contact. |
| `OBS` | Observation — a fact established, with its source. |
| `DEC` | Decision — including the awareness decision, and any decision not to report. |
| `T0` | The awareness stamp itself. There is exactly one per track. |
| `FIL` | A filing made, with platform reference and UTC submission time. |
| `USR` | User information activity under Article 14(8). |
| `REV` | Review or re-assessment of an earlier decision. |

## Log table template

Copy this into the incident record and append rows. Keep the columns; they are the questions someone will ask.

```
| # | UTC timestamp | Type | Track | Event / action | Source or evidence ref | Basis (observation vs conclusion) | Person | Reportability position |
```

| Column | What goes in it |
| --- | --- |
| `#` | Sequential, never reused. |
| `UTC timestamp` | `YYYY-MM-DD HH:MM`, marked `(est.)` if estimated. |
| `Type` | Code from the table above. |
| `Track` | `VULN`, `INC`, or `BOTH`. |
| `Event / action` | One or two factual sentences. What happened or what was done. |
| `Source or evidence ref` | Who or what it came from; the stored artefact identifier. |
| `Basis` | Whether this is observed fact or drawn conclusion, and on what. |
| `Person` | Named individual. |
| `Reportability position` | The running answer: `not assessed` / `assessing` / `not reportable — reason` / `REPORTABLE`. |

---

## Filled example — Event `EVT-2026-0141`, actively exploited vulnerability

Product: GW-500 edge gateway, firmware 4.0–4.2.1. Made available in Belgium, Greece, Italy. Coordinating CSIRT: `[VERIFY: your coordinating CSIRT]`.

| # | UTC timestamp | Type | Track | Event / action | Source or evidence ref | Basis | Person | Reportability position |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2026-10-15 14:20 | SIG | VULN | Email to product security inbox: customer SOC reports anomalous outbound traffic from the management interface of a GW-500 and suspects the appliance was the entry point. No logs attached. | `EVT-0141/a01-customer-email.eml` | Observation: message received. No technical evidence yet. | A. Reporter (accountable reporter) | not assessed |
| 2 | 2026-10-15 14:28 | ACT | VULN | Technical verifier paged. Investigation opened. Customer asked for management-interface logs and appliance serial/firmware version. | `EVT-0141/a02-page-record.txt` | Action. | A. Reporter | assessing |
| 3 | 2026-10-15 14:55 | ACT | VULN | Searched internal fleet telemetry for anomalous management-interface authentication patterns over the preceding 30 days. No matches found at this time. | `EVT-0141/a03-telemetry-query.txt` | Observation: negative search result. Absence of evidence in our telemetry, which covers only units that report telemetry. | B. Verifier (technical verifier) | assessing |
| 4 | 2026-10-15 15:40 | OBS | VULN | Customer confirms affected unit is on firmware 4.2.1, management interface reachable from a non-trusted network segment contrary to our deployment guidance. | `EVT-0141/a04-customer-call-notes.md` | Observation, reported by customer, not independently verified at this point. | B. Verifier | assessing |
| 5 | 2026-10-15 17:10 | OBS | VULN | Customer supplies management-interface logs. Logs show unauthenticated POST requests to `/api/v1/admin` accepted with HTTP 200, followed by creation of an administrative account not created by the customer's administrators, from external IP `[redacted in this example]`. | `EVT-0141/a05-customer-logs.tar.gz` (SHA-256 recorded) | Observation from customer-supplied artefact. | B. Verifier | assessing — exploitation probable, not yet confirmed against our build |
| 6 | 2026-10-15 18:12 | ACT | VULN | Reproduced the request sequence against a stock 4.2.1 build in the lab. Unauthenticated request to `/api/v1/admin` accepted and executed with administrative privilege. | `EVT-0141/a06-lab-repro.md`, video `a06-repro.mp4` | Observation: reproduced in controlled environment. | B. Verifier | assessing |
| 7 | 2026-10-15 18:35 | OBS | VULN | Considered and excluded misconfiguration as an explanation: the customer's logs show the bypass on a default-configuration unit, and the lab reproduction used an unmodified stock build. | `EVT-0141/a07-alt-explanations.md` | Conclusion, from entries 5 and 6. | B. Verifier | assessing |
| 8 | 2026-10-15 18:40 | **T0** | VULN | **AWARENESS DECLARED.** Reasonable degree of certainty that a vulnerability contained in the GW-500 is being actively exploited. Decisive facts: customer logs showing a successful unauthenticated privileged action and unauthorised account creation (entry 5), plus lab reproduction against a stock build (entry 6). | entries 5, 6, 7 | Decision. Awareness determination under Art. 14; standard applied: reasonable degree of certainty after initial assessment, per Commission guidance of 27 July 2026, Section 9.1. | A. Reporter | **REPORTABLE — vulnerability track** |
| 9 | 2026-10-15 18:44 | DEC | VULN | Deadlines computed and posted: early warning due 2026-10-16 18:40 UTC; 72-hour notification due 2026-10-18 18:40 UTC; final report 14 days after a corrective or mitigating measure is available. Calendar alarms set at T0+12h and T0+20h. | `EVT-0141/a09-deadlines.md` | Action. | A. Reporter | REPORTABLE |
| 10 | 2026-10-15 19:30 | ACT | INC | Assessed whether our own build, signing or distribution systems were affected, i.e. whether a severe incident under Art. 14(5) also arises. Reviewed build system access logs and signing key usage for the preceding 60 days. No unauthorised access found. | `EVT-0141/a10-build-review.md` | Observation: negative search result over a defined scope and period. | C. Deputy (deputy reporter) | Incident track: not reportable — no evidence of impact on the security of our development, production or distribution processes |
| 11 | 2026-10-16 08:00 | ACT | VULN | Detection signature for the exploitation pattern distributed to the support organisation for customer log review. | `EVT-0141/a11-signature.md` | Action. | B. Verifier | REPORTABLE |
| 12 | 2026-10-16 09:50 | FIL | VULN | **Early warning submitted** via the single reporting platform. Coordinating CSIRT selected on the basis of main establishment in the Union. Member States indicated: Belgium, Greece, Italy. Full submitted text stored. | `EVT-0141/a12-early-warning-submitted.md`, platform ref `[VERIFY: record the reference the platform returns]` | Action. Filed 15h10m after T0, 8h50m before the deadline. | A. Reporter | REPORTABLE — stage 1 complete |
| 13 | 2026-10-16 16:30 | USR | VULN | Advisory published to customer portal and emailed to all registered GW-500 administrators: restrict management-interface access to trusted networks; review logs for the pattern; review administrative account list. | `EVT-0141/a13-customer-advisory.pdf` | Action under Art. 14(8). | D. Comms (communications lead) | REPORTABLE |
| 14 | 2026-10-16 16:35 | DEC | VULN | Noted that the published workaround may constitute a "mitigating measure available" starting the 14-day final-report clock. Two candidate trigger dates recorded: 2026-10-16 16:30 (workaround) and the future firmware release. Working deadline adopted on the **earlier** date, i.e. final report due 2026-10-30 16:30 UTC, to be revised only downwards. | `EVT-0141/a14-clock-basis.md` | Decision, conservative interpretation. | A. Reporter | REPORTABLE |
| 15 | 2026-10-17 11:20 | OBS | VULN | Version bisection completes: the affected endpoint was introduced in 4.0; versions before 4.0 are unaffected. Affected range confirmed 4.0 to 4.2.1 inclusive. | `EVT-0141/a15-version-bisect.md` | Observation from code review and testing. | B. Verifier | REPORTABLE |
| 16 | 2026-10-18 11:00 | FIL | VULN | **72-hour notification submitted**, 7h40m before deadline. Includes confirmed version range, general nature of the exploit, published workaround, user actions, and a specific sensitivity statement. Full submitted text stored. | `EVT-0141/a16-72h-submitted.md`, platform ref `[VERIFY]` | Action. | A. Reporter | REPORTABLE — stage 2 complete |
| 17 | 2026-10-22 09:15 | OBS | VULN | Firmware 4.2.2 released and downloadable by all customers. Corrective measure available. | `EVT-0141/a17-release-note.md` | Observation. | B. Verifier | REPORTABLE |
| 18 | 2026-11-03 10:05 | FIL | VULN | **Final report submitted**, ahead of both the conservative deadline (2026-10-30, already met by an interim filing) and the release-anchored deadline (2026-11-05 09:15). Includes root cause, severity, impact, actor information (attribution unknown, indicators supplied), corrective measure details, and recurrence prevention. | `EVT-0141/a18-final-report.md`, platform ref `[VERIFY]` | Action. | A. Reporter | REPORTABLE — closed |

---

## Filled example — a decision NOT to report

This is the entry set that most organisations fail to keep, and the one that matters most. Event `EVT-2026-0158`.

| # | UTC timestamp | Type | Track | Event / action | Source or evidence ref | Basis | Person | Reportability position |
| --- | --- | --- | --- | --- | --- | --- | --- | --- |
| 1 | 2026-11-02 07:05 | SIG | VULN | Automated dependency scan (`cra-watch`) flags that our product bundles `libexample` 2.4.1, which carries CVE-2026-XXXXX, added to the CISA KEV catalog on 2026-11-01. | `EVT-0158/b01-crawatch-report.json` | Observation: a component we ship carries a CVE listed as known-exploited **in the wild generally**. This is a trigger to assess, not a finding about our product. | B. Verifier | assessing |
| 2 | 2026-11-02 07:40 | ACT | VULN | Read the upstream advisory and the KEV entry. Vulnerability is in `libexample`'s optional XML-RPC request handler, exploitable only when the handler is registered and reachable over the network. | `EVT-0158/b02-upstream-advisory.pdf`, `b03-kev-entry.json` | Observation from vendor advisory. | B. Verifier | assessing |
| 3 | 2026-11-02 08:55 | ACT | VULN | Reachability analysis. Our build compiles `libexample` with `--without-xmlrpc`; the affected object file is absent from the shipped binary. Confirmed by symbol inspection of the release artefact for 3.7.0 (`nm` output stored) and by grep of the build configuration in the release pipeline definition. | `EVT-0158/b04-symbol-inspection.txt`, `b05-build-config.md` | Observation from direct inspection of the shipped artefact, not from documentation. | B. Verifier | assessing |
| 4 | 2026-11-02 09:20 | ACT | VULN | Searched product telemetry and support tickets for any indication of exploitation attempts against our product matching the advisory's indicators, covering 2026-08-01 to date. No matches. | `EVT-0158/b06-telemetry-search.md` | Observation: negative search result over a defined scope and period. | B. Verifier | assessing |
| 5 | 2026-11-02 10:00 | **DEC** | VULN | **DECISION: NOT REPORTABLE under Article 14.** The vulnerability originates in a third-party component we integrate. The vulnerable code is **not reachable** in our product because the affected handler is not compiled into our shipped binary (entry 3), and there is **no evidence of exploitation in our product** (entry 4). Per Commission guidance of 27 July 2026, Section 9.1, paragraph 218, a vulnerability in an integrated component that cannot be exploited in, or has not been exploited in, the manufacturer's product does not qualify as an actively exploited vulnerability contained in that product and is not subject to mandatory reporting. Decision made by the accountable reporter on the verifier's analysis. | entries 2, 3, 4 | Decision, with the legal basis and the factual basis both stated. | A. Reporter | **not reportable — vulnerable code not reachable in our build; no exploitation observed in our product** |
| 6 | 2026-11-02 10:15 | ACT | VULN | Reported the vulnerability upstream to the `libexample` maintainers under Article 13(6). Checked first that the maintainers were already aware — advisory is theirs — so the report was limited to confirming the version we integrate and offering test results. | `EVT-0158/b07-upstream-report.eml` | Action under Art. 13(6). | B. Verifier | not reportable |
| 7 | 2026-11-02 10:30 | DEC | VULN | Scheduled upgrade of `libexample` to 2.4.3 in the next maintenance release (target 2026-11-24) notwithstanding non-reachability, to eliminate the exposure if build options ever change. Tracked as `[internal ticket ref]`. | `EVT-0158/b08-remediation-ticket.md` | Decision, risk reduction beyond the legal minimum. | B. Verifier | not reportable |
| 8 | 2026-11-02 10:35 | DEC | VULN | Considered voluntary notification under Article 15 and decided against it on the basis that the upstream advisory is already public and adds nothing for the CSIRT in this instance. Recorded so the decision is visible. | `EVT-0158/b09-art15-consideration.md` | Decision. | A. Reporter | not reportable |
| 9 | 2026-11-24 14:00 | REV | VULN | Re-assessment on release of 3.7.1: confirmed `--without-xmlrpc` remains set and `libexample` upgraded to 2.4.3. Non-reachability conclusion re-verified against the new artefact. | `EVT-0158/b10-reverify.txt` | Observation. Conclusion re-verified, not assumed to persist. | B. Verifier | not reportable — re-verified |

Read entry 5 again. It names the legal test, applies it to two specific facts, cites the evidence for each fact, and names the decision-maker. Entry 9 shows the conclusion was re-checked rather than treated as permanent. That combination is what makes a non-report defensible.

## Common failures this log prevents

| Failure | What it looks like later | The entry that prevents it |
| --- | --- | --- |
| Awareness drift | Nobody can say when the clock started; the earliest email in the thread becomes the assumed T0 by default. | A single `T0` entry naming the decisive facts. |
| Reconstruction | The log is written after the final report, in one sitting, from memory. | Contemporaneous entries with tight timestamps. |
| Undocumented non-report | "We looked at it and decided it didn't apply." | A `DEC` entry with the legal test, the facts, and the evidence refs. |
| Missing negatives | "Did you check whether other customers were affected?" "Yes, I think so." | `ACT` entries recording searches that found nothing, with their scope and period. |
| Silent re-scoping | The affected version range in the final report differs from the early warning with no explanation. | An `OBS` entry recording the bisection result and when it landed. |
| Clock-basis ambiguity | Two plausible dates for "measure available"; the later one was used. | A `DEC` entry recording both candidates and the choice of the earlier. |
| Vanished artefacts | The customer log tarball is on a laptop that was reimaged. | Stored copies with hashes, referenced by stable identifiers. |
