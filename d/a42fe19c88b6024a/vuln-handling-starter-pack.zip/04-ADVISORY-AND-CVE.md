# 04 - Advisory and CVE

**NOT LEGAL ADVICE.** This describes public processes run by the CVE Program and by GitHub. Not legal advice, not a certification, not a compliance determination. Requesting a CVE is not a regulatory filing and satisfies no reporting obligation.

---

## When a CVE is appropriate

Request one when all three hold: the vulnerability is in software **other people run or depend on**; there is a **version boundary that matters**, so a user needs to know which side they are on; and the affected code is **publicly available or commercially distributed**.

Skip it when the flaw is only in **your own hosted service** and you fixed it in production - nobody has a version to upgrade, so tell affected customers directly. Skip it for **unreleased code**, for **hardening with no exploit path** (calling that a vulnerability devalues the ones that are), and for bugs in **someone else's dependency** where you are not the maintainer.

A CVE id is a coordination mechanism: a stable name so a scanner, a customer's compliance team, and a distro packager can discuss the same thing. If nobody needs to coordinate, it adds nothing. Note the asymmetry - an advisory without a CVE is fine and common; a CVE without an advisory is close to useless.

---

## Two routes to an id

### Route A - GitHub, if your code is there

For a small team with a public repo this is the path, and it is free.

1. Repo > **Security > Advisories > New draft security advisory**.
2. Fill in affected versions, patched versions, severity, description, CWE, credit.
3. Optionally open a **temporary private fork** to develop the fix out of sight.
4. Click **Request CVE**. GitHub is a CNA and can assign an id for code it hosts.
5. Ship the fix, then click **Publish advisory**.

Docs: <https://docs.github.com/en/code-security>

Three things to know first. **Add the fixed version before publishing** - GitHub warns about this and it is right, because publishing without one makes Dependabot alert your users to a problem while offering nowhere to go. **Publishing deletes the temporary private fork**, so merge your work back first. And **request the CVE before publishing**, which is the order the flow expects.

Advisories for an ecosystem the dependency graph supports propagate into the GitHub Advisory Database, which is where many scanners actually read from. For most projects that propagation is worth more than the CVE id itself.

### Route B - the CNA route, for everything else

CVE ids are assigned by CVE Numbering Authorities, each with a defined scope. The rule: **find the CNA whose scope covers the affected product.**

1. Search the partner list at <https://www.cve.org>. If a CVE exists for this product already, its "Assigning CNA" field names who to ask.
2. Read that CNA's disclosure policy, then contact them by their published method.
3. If no CNA covers it, use a **CNA of Last Resort**: MITRE for general and open-source product vulnerabilities not covered by a listed CNA, or CISA ICS for industrial control systems and medical devices.

Official walkthrough for non-CNAs: <https://www.cve.org/ReportRequest/ReportRequestForNonCNAs>

For a vulnerability in your own product where no CNA covers you, MITRE as CNA-LR is the normal path. It is a web form. Expect days rather than hours, and expect to be asked for a public reference - so have the advisory URL ready.

**Should you become a CNA?** Almost certainly not yet. It means operating the assignment process yourself, indefinitely, under the Program's rules. That suits a vendor publishing many advisories a year; for one or two, GitHub or MITRE costs nothing.

---

## What a good advisory contains

It answers one question for a stressed reader: **am I affected, and what do I do in the next ten minutes?**

1. **A title stating the impact**, not the bug class. "Authentication bypass in the admin API" beats "Improper access control."
2. **Identifiers** - yours, plus CVE and GHSA if they exist.
3. **Affected and fixed versions**, at the top.
4. **Impact in two or three sentences**: what an attacker can do and what they need to start.
5. **How to tell if you are affected** - a version check, a config value, a log pattern. Hugely appreciated and usually missing.
6. **Mitigation** for people who cannot upgrade today.
7. **Credit**, in the form the reporter asked for.
8. **A timeline** with dates.
9. **A severity score with the full vector string**, not a bare number.

Leave out working exploit code, internal ticket numbers, blame, and hedging. "We take security seriously" reads as filler to exactly this audience.

---

## Getting the affected-versions range right

More advisories are wrong here than anywhere else, and this field is machine-read by the scanners your users depend on. Wrong means someone stays vulnerable while believing they are fine.

**State both ends.** "Versions before 2.5.1" is ambiguous - does it include 1.x? Does it include 2.5.0-rc1? Write `>= 2.0.0, < 2.5.1`.

**Handle every maintained branch separately.** If you backported to 1.9 and 2.4 as well as fixing 2.5:

```
Affected:   >= 1.0.0, < 1.9.7
            >= 2.0.0, < 2.4.12
            >= 2.5.0, < 2.5.1
Fixed in:   1.9.7, 2.4.12, 2.5.1
```

A user on 2.4.9 who reads only "fixed in 2.5.1" concludes they need a major upgrade they cannot schedule, and does nothing.

**Say where it was introduced, if you know.** If the bug arrived in 2.3.0 then 2.0-2.2 are unaffected, which saves many people a lot of work. If you do not know, say "all versions before X" rather than guessing a lower bound.

**Do not forget pre-releases.** Under semver `2.5.0-rc1` sorts before `2.5.0`, and ranges that ignore this drop release-candidate users through the gap.

**The CVE record format mirrors this.** Its `affected` structure uses `defaultStatus` plus a `versions` list, each entry carrying `version` (lower bound), `status`, `versionType`, and usually `lessThan`:

```json
{
  "vendor": "Larkfield Systems",
  "product": "Larkfield Stock",
  "defaultStatus": "unaffected",
  "versions": [
    {
      "version": "2.0.0",
      "lessThan": "2.5.1",
      "versionType": "semver",
      "status": "affected"
    }
  ]
}
```

`defaultStatus: "unaffected"` means "anything unlisted is fine" - right when you know your version history. If you genuinely do not know the status of old releases, `"unknown"` is honest, and is what the schema defaults to when `defaultStatus` is omitted. Reference: <https://cveproject.github.io/cve-schema/schema/docs>

**Sanity check before publishing.** Take three real versions - one affected, one not, and the boundary release - and evaluate them against your own range by hand. That catches the off-by-one, which is the error that actually happens.

---

## Coordinating timing with the reporter

The reporter started a clock the moment they emailed you, whether or not they said so. Your job is to make it a shared clock.

**Agree a date in writing, early.** "Targeting a fix by 14 November and publication on 21 November - does that work?" One message, and most friction never appears.

**Send the draft advisory before publishing.** They catch a technical error roughly a third of the time and it costs you nothing. Set a review window - 48 hours is normal - so it does not become an open-ended veto. Check the credit line explicitly: name, handle, employer, or nothing. Do not credit someone who asked to stay anonymous.

**If you need more time, ask before the deadline, not after.** Once, with a specific new date and a real reason. Researchers overwhelmingly grant a first extension asked for honestly. What they do not grant is silence followed by a request on day 89.

**If the reporter wants to publish before you are ready,** you can ask but you cannot compel. Argue on user harm - "400 installations have no patch to move to" - not on your release schedule. Sometimes you lose, and then the right response is to ship whatever mitigation you have and publish the same day.

**If it is already being exploited, the calculus inverts.** Users under attack need to know now, even if all you have is a config change and a detection rule. Publish early, mark it provisional, update later.

**Never** threaten a reporter, invoke a lawyer over publication timing, or quietly ship the fix and hope nobody notices. The last is the most common and most damaging: a silent patch means users do not know to prioritise the upgrade, leaving them exposed while attackers diff the release, and it is the fastest way to guarantee the next researcher goes straight to full public disclosure.

---

## Advisory template

```markdown
# [ADVISORY ID] - [Impact-first title]

| | |
|---|---|
| **Advisory ID** | [LARK-2026-001] |
| **CVE** | [CVE-YYYY-NNNNN or "not assigned"] |
| **GHSA** | [GHSA-xxxx-xxxx-xxxx, if applicable] |
| **Published** | [YYYY-MM-DD] |
| **Last updated** | [YYYY-MM-DD] |
| **Severity** | [Critical / High / Medium / Low] |
| **CVSS** | [score] ([full vector string]) |
| **CWE** | [CWE-NNN: name] |

## Affected versions

| Product | Affected | Fixed in |
|---|---|---|
| [PRODUCT] | >= [X.Y.Z], < [A.B.C] | [A.B.C] |
| [PRODUCT] | >= [P.Q.R], < [S.T.U] | [S.T.U] |

>> One row per maintained branch. State both ends of every range.

Versions before [X.Y.Z] are [not affected - the flaw was
introduced in [X.Y.Z] / of unknown status and no longer
supported].

## Summary

[Two or three sentences. What an attacker can do, and what they
need in order to do it. No jargon a competent generalist would
not recognise.]

## Impact

[One paragraph. Concrete consequences: which data, whose data,
what level of access. Say plainly if it crosses a tenant
boundary or reaches other users' data.]

Exploitation requires [authentication / no authentication /
admin privileges / a non-default configuration: [WHICH]].

## Am I affected?

- Check your version: `[COMMAND OR UI PATH]`
- [If configuration-dependent:] You are only affected if
  `[SETTING]` is set to `[VALUE]`. Check with `[COMMAND]`.
- [If there is a detectable signature:] Requests exploiting
  this appear in logs as `[PATTERN]`.

## What to do

**Upgrade to [A.B.C].** [Link to release / install command]

**If you cannot upgrade immediately:** [Specific mitigation -
config change, block a path at the proxy, disable a feature -
or "no mitigation is available; upgrading is the only fix."]

## Active exploitation

[We have no evidence that this vulnerability has been exploited.
/ We are aware of exploitation in the wild as of [DATE].]

>> State this either way. "No evidence" is information; an
>> absent section makes readers assume the worst.

## Technical detail

[Enough for a security engineer to understand and verify the
issue. Root cause, affected code path, why the fix works. No
weaponised exploit code.]

## Credit

Reported by [NAME / HANDLE][, of [ORGANISATION]]. Thank you.

>> Or "Reported by a researcher who wishes to remain
>> anonymous." Or omit if found internally.

## Timeline

| Date | Event |
|---|---|
| [YYYY-MM-DD] | Report received |
| [YYYY-MM-DD] | Reproduced and confirmed |
| [YYYY-MM-DD] | CVE id requested |
| [YYYY-MM-DD] | Fix released in [A.B.C] |
| [YYYY-MM-DD] | Advisory published |

## References

- [Release notes / tag]
- [Commit, if the repository is public]
- [CVE record]
- [Any upstream or related advisory]

## Contact

[security@yourdomain.example]
```

---

## After publication

Link it from your release notes - plenty of people read those and never see advisories. Use your announcement list; a published page is not a notification. If severity is high and you know who runs affected versions, email them. Add the reporter to the acknowledgements page your `security.txt` points at. Update the advisory if facts change, moving the "last updated" date. Record the outcome in your decision log (file 05).
