# 03 - Intake and Triage

**NOT LEGAL ADVICE.** An operational runbook. Not legal advice, not a certification, not a compliance determination. It covers how to work out what you are looking at, not who you must notify or on what clock - see the closing note.

---

## The three questions

A report arrives. Within about an hour you need to know:

1. **Is it real?** Can you reproduce it.
2. **Does it matter in *your* product?** Not in the abstract - in the code you ship and the configuration you run.
3. **Is anyone using it right now?** A different question from the first two, and the one most teams never explicitly ask. It gets the most space here because it is the one with consequences.

---

## Where reports arrive

You have more inboxes than you think. List yours honestly:

| Channel | Watched by | Realistic latency |
|---|---|---|
| `security@` alias | [NAMES] | [X] hours |
| Web report form | [NAMES] | [X] hours |
| GitHub private vulnerability reporting | repo admins | until someone looks |
| Public GitHub issue | issue triager | hours to days |
| Support ticket queue | support | hours |
| A DM to a founder | one person | unbounded |
| A conference hallway | one person | unbounded |
| A CVE in a dependency you use | usually nobody | **usually never** |

The last three are the leaks. Two rules fix most of it.

**Anything resembling a security report goes to `security@` immediately, unopened if necessary.** Support staff should route security reports, not triage them. Say so explicitly; they will not guess.

**A public issue containing a working exploit gets handled, not debated.** Decide the order now: most teams edit or delete the issue body, reply publicly that they are moving to a private channel, then email the reporter. You do not want to improvise that in a repo people are watching.

If you have a public repo, turn on GitHub's private vulnerability reporting. Free for public repositories, it gives reporters a channel that does not depend on email and puts the report where you will later draft the advisory. <https://docs.github.com/en/code-security>

---

## Who reads them

Name two people. Not a team, not a rota - two named humans, one primary this month. The failure mode is never "nobody was assigned," it is "each assumed the other had it."

```
Security intake
  Primary this month:  [NAME]  [phone]
  Backup:              [NAME]  [phone]
  Escalation:          [NAME - can authorise an unscheduled release]
  Reviewed:            [YYYY-MM-DD]
```

The escalation contact matters because triage sometimes ends in "we ship today," and whoever is triaging at 22:00 should not have to work out who can say yes.

---

## The first hour

In order. Resist the urge to start fixing.

**0-5 min. Acknowledge.** Two sentences: we have it, a human is looking, you will hear from us by [date]. Highest-return action in this file. It stops the clock in the reporter's head - the one otherwise running towards "these people are ignoring me."

**5-10 min. Open a private tracking item.** A draft GitHub security advisory, or a ticket not everyone can read. Not a public issue. Assign an internal id now (`SEC-2026-001`) and use it in every message afterwards.

**10-20 min. Read it and classify the channel.** Your code, a dependency, or a service you merely buy? Three different destinations. A flaw in third-party SaaS is not yours to fix - forward it and tell the reporter you did.

**20-40 min. Attempt to reproduce.**

**40-50 min. Ask the exploitation question**, even if reproduction is unfinished. It is fast and it can change the next twenty-four hours.

**50-60 min. Decide and record.** One of: confirmed / not reproducible / out of scope / needs more from reporter / needs specialist help. Write the decision, the reason, and the date in the tracking item. Reply to the reporter.

Do not skip the write-down because the answer feels obvious. In two years, "not exploitable because the endpoint requires an authenticated admin session" is defensible. "We must have looked at it" is not.

---

## Reproducing and confirming

Work from a clean environment, not your dev machine with its eight local overrides.

1. **Pin the version.** Exact release or commit. If the reporter did not say, ask - do not assume `main` is what users run.
2. **Match the configuration**, and note whether it was default. That distinction matters enormously in the advisory.
3. **Follow the reporter's steps exactly on the first pass.** If it fails, then vary.
4. **If it does not reproduce, say so specifically.** Not "cannot reproduce" but "tried 2.4.1 and 2.5.0, default config, PostgreSQL 16, step 3 returned 403." Reporters usually close that gap in one reply. A bare "cannot reproduce" reads as a brush-off and often ends the conversation with the bug still present.
5. **Find the root cause, not the symptom.** Before sizing the fix, find the function that is actually wrong and ask what else reaches it. Symptom fixes come back.
6. **Check older supported versions.** Almost always affected, almost always forgotten until after the release.
7. **Write down what you did** - commands, versions, outcome. You need it for the advisory and you will not remember it.

---

## Is it exploitable in your product?

A finding can be real and still not be a vulnerability in what you ship. Ask, in order:

- **Is the vulnerable code path reachable?** A flaw in a library function you never call is not exploitable through your product. Check rather than assuming either way.
- **Who can reach it?** Anonymous internet / any authenticated user / an administrator / someone already inside. Each step is roughly an order of magnitude of real risk.
- **What preconditions are required?** A non-default setting, a specific topology, a feature flag. If a precondition is rare the impact is smaller - but check telemetry rather than guessing what customers enable.
- **What does an attacker get?** Read data, write data, execute code, escalate privilege, deny service. "Execute code" and "read other tenants' data" are the two that wake people up.
- **Is there a mitigation available today?** A config change, a proxy rule, disabling a feature. If yes, you can tell customers something useful hours before you have a patch - often the most valuable output of the whole triage.

Two notes on dependency reports. **OSV.dev** (<https://api.osv.dev>) is a public, no-key API for checking whether a package version is affected, with one sharp edge: `/v1/querybatch` returns only `{id, modified}` per match, with **no aliases**, so a GHSA id from a batch query must be resolved through `/v1/vulns/{id}` before you can see its CVE alias. If you script this, that second call is not optional, and skipping it is the usual reason such scripts silently miss things. And **reachability beats version matching** - a scanner reporting that `libfoo 1.2.3` has a CVE is the start of triage, not the end.

---

## Is it being used right now?

The question small teams systematically fail to ask. Five minutes on every confirmed report.

"Actively exploited" means someone is using this against real systems now - not that it is severe, not that a proof of concept exists. A critical vulnerability nobody has touched and a medium one being used in the wild are different situations, and the second is more urgent.

Signals, cheapest first:

**1. Ask the reporter.** "Did you find this in the wild, or in the code?" People who find bugs during incident response answer very differently from people reading source. One line of email.

**2. Search your own logs** for the pattern you just reproduced, across whatever window you retain. Hits before the report date are the strongest signal you will get, and the moment to stop and get help. This only works if retention is long enough - if yours is seven days, note that gap now, while fixing it is cheap.

**3. Check the CISA Known Exploited Vulnerabilities catalogue.** Public JSON, no key:

```
https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json
```

As of catalogue version 2026.09.14 it held 1,710 entries. It skews heavily towards widely-deployed software, so a small vendor's own product rarely appears - but your **dependencies** will, and that is the useful case. A weekly job diffing KEV against your dependency manifest is about thirty lines of code and is the highest-value monitoring most small teams are not doing.

**4. Watch the softer signals.** A scanning spike against that endpoint. Several unrelated customers reporting odd behaviour in the same component. Your finding appearing in a public exploit repository. Any of these move you from "we think not" to "we do not know," a materially different answer.

**Record the conclusion either way, with the date and the basis.** "Application logs searched 2026-09-15, 90-day retention, no matches" is worth writing down. The absence of that note is indistinguishable from never having looked.

---

## Deciding severity

Use CVSS if you want a number for an advisory - v4.0 is current, v3.1 still widely understood, either is fine as long as you publish the full vector string and not a bare score. <https://www.first.org/cvss/>

But know what it is: a portable description of a vulnerability in the abstract. It is not your risk and it is not a decision. A 9.8 in a code path your product cannot reach is not a 9.8 for you. For the decision itself, a plain internal scale serves a small team better:

| Level | Meaning | Response |
|---|---|---|
| **Critical** | RCE, authentication bypass, or cross-tenant data access without unusual preconditions - **or anything you believe is actively exploited** | Drop other work. Out-of-band release. Notify customers. |
| **High** | Serious impact, but needs authentication, a non-default configuration, or user interaction | Fix in days. Expedited patch release. |
| **Medium** | Real but limited impact, or high impact behind significant preconditions | Next scheduled release. |
| **Low** | Defence in depth, or impact requiring an attacker who already has what they would be after | Backlog, with a date attached. |

Note the clause in the Critical row. Active exploitation promotes severity regardless of score. That is the most useful rule in the table, and the one that matters if a regulator is ever involved.

If you want something more structured, CISA's SSVC decision trees are free and built for "what do we do" rather than "how bad is this in general." <https://www.cisa.gov/ssvc>

---

## Triage worksheet

Copy into your private tracking item and fill in as you go. Short on purpose - a worksheet nobody completes is worse than none.

```
TRIAGE WORKSHEET

Internal ID:        SEC-[YYYY]-[NNN]
Date received:      [YYYY-MM-DD HH:MM TZ]
Received via:       [ email / form / GitHub / support / other ]
Reporter:           [ name or handle, or "anonymous" ]
Acknowledged at:    [YYYY-MM-DD HH:MM TZ]  by [NAME]
Triage owner:       [NAME]

--- 1. What was reported -------------------------------------
Summary (one sentence):
Component / product:
Versions claimed affected:

--- 2. Reproduction ------------------------------------------
Reproduced?         [ yes / no / partial / not yet ]
Environment used:   version [ ], config [ default / non-default: ]
Steps confirmed:    [ as reported / modified - how: ]
Root cause:         [ file / function / commit, or "unknown" ]
Other versions checked:
Notes:

--- 3. Exploitability in OUR product -------------------------
Vulnerable path reachable?      [ yes / no / unclear ]
Who can reach it?               [ anonymous / any user /
                                  admin / internal only ]
Preconditions required:
Attacker gains:                 [ RCE / data read / data write /
                                  privilege escalation / DoS /
                                  other: ]
Mitigation available today?     [ none / describe: ]

--- 4. Active exploitation -----------------------------------
Reporter found it in the wild?  [ yes / no / did not answer ]
Own logs checked?               [ yes / no ]
  Retention window searched:    [ e.g. 90 days ]
  Result:                       [ no matches / matches - detail: ]
CISA KEV checked (deps)?        [ yes / no / n/a ]
Other signals:                  [ scanning spike / public PoC /
                                  multiple customer reports / none ]
CONCLUSION:                     [ no evidence of exploitation /
                                  unknown / evidence found ]
Basis and date:                 [ e.g. "logs searched 2026-09-15,
                                  90-day window, no matches" ]

--- 5. Severity ----------------------------------------------
Internal level:     [ critical / high / medium / low ]
CVSS vector:        [ optional - include the full vector string ]
Reasoning:

--- 6. Decision ----------------------------------------------
Decision:           [ fix now / fix next release / backlog /
                      not a vulnerability / out of scope /
                      upstream - forwarded to: ]
Decided by:         [NAME]        Date: [YYYY-MM-DD]
Reason (2 lines, written for someone reading this in 2 years):

Advisory needed?    [ yes / no ]     CVE needed? [ yes / no ]
Reporter informed of decision?       [ yes - date: / no ]
Target fix date:    [YYYY-MM-DD]
Next review date:   [YYYY-MM-DD]
```

Section 4 and the reason line in section 6 are the two people skip, and the two with value after the immediate work is done. Fill them in even when the answer is boring.

---

## Where this stops and regulation starts

This runbook gets you to a defensible answer on one question: **do we have evidence that this vulnerability is being actively exploited?**

That is not academic. Under the EU Cyber Resilience Act - Regulation (EU) 2024/2847 - active exploitation, not severity, triggers the Article 14 reporting obligations, enforceable since 11 September 2026, running on a cascade of 24-hour, 72-hour and 14-day deadlines to a coordinating national CSIRT and to ENISA. Primary source: <https://eur-lex.europa.eu/eli/reg/2024/2847/oj>

That is deliberately all this pack says about it. **If the CRA applies to you, the deadline mechanics, who notifies whom, what goes in each report, and how you rehearse it are substantial work covered in the separate CRA kit.** What this file gives you is what has to exist first: a process that can answer the exploitation question, and a written record of when you asked and what you found. Without that, the reporting obligations have nothing to operate on.

If the CRA does not apply to you, nothing changes. The exploitation question is the right question for its own sake.
