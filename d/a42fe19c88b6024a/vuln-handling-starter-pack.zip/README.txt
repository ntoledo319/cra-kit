=============================================================
THE VULNERABILITY HANDLING STARTER PACK
Toledo Technologies LLC - Version 1.0
=============================================================

-------------------------------------------------------------
NOT LEGAL ADVICE
-------------------------------------------------------------
Written by engineers, for engineers. Not legal advice, not a
certification, not a compliance determination. Buying it makes
you compliant with nothing, and nothing here creates a
lawyer-client relationship. Two parts carry real legal weight
and should be read by a lawyer before you publish them: the
safe-harbour wording in the disclosure policy, and any promise
about response times. Both are marked. Where something depends
on where you are incorporated or where your users are, this pack
says so instead of guessing.
-------------------------------------------------------------


WHAT THIS IS

Six files covering the vulnerability-handling setup a software
team needs before any regulator, customer, auditor, or researcher
comes asking. Deliberately small. An afternoon's work, then done.

  README.txt                        this file
  01-SECURITY-TXT.md                machine-readable contact point
  02-VULNERABILITY-DISCLOSURE-POLICY.md   the public policy
  03-INTAKE-AND-TRIAGE.md           what to do when a report lands
  04-ADVISORY-AND-CVE.md            publishing a fix, getting a CVE
  05-THE-FIVE-FILES.md              the closing checklist

Every template is meant to be copied, pasted, and edited.
Placeholders are ALL CAPS in square brackets, so searching a repo
for "[" plus "]" finds everything still to fill in.


WHO IT IS FOR

A team of two to thirty people shipping software - SaaS, a mobile
app, an on-prem product, a library, firmware - with no written
answer to "where does a stranger send us a security bug?"

Regulation-agnostic on purpose. A four-person team in Kansas with
no European customers needs every file here for ordinary reasons:
enterprise questionnaires ask for a disclosure policy, researchers
who cannot find a contact address sometimes post to social media
instead, and a report sitting in a personal inbox during someone's
holiday is a report you did not receive.


WHAT THIS IS NOT

Not a bug bounty. No money changes hands anywhere here.

Not a pentest or audit. It covers what to do with findings, not
how to find them.

Not a secure development lifecycle, threat model, patch policy, or
breach response plan. A vulnerability in your product and an
intrusion into your network are different events with different
playbooks. This is the first. RFC 9116 draws the same line.

Not a compliance package. No reporting deadlines, no regulator
templates, no scope analysis.


WHEN YOU SHOULD BUY THE LARGER KITS INSTEAD

Be honest with yourself about this paragraph. If you sell, ship,
or make available a product with a digital element to anyone in
the European Union, then Regulation (EU) 2024/2847 - the Cyber
Resilience Act - is not a future problem for you: its Article 14
reporting obligations became enforceable on 11 September 2026, the
trigger is an actively exploited vulnerability rather than a severe
one, and the deadlines cascade at 24 hours, 72 hours, and 14 days
to a coordinating national CSIRT and ENISA. This pack gets you to
the point of knowing a vulnerability is being exploited. It will
not tell you who to notify, on what clock, in what format, or who
owns that clock, and that is exactly the separate CRA kit.
Likewise, if your concern is liability for defective software
rather than reporting, Directive (EU) 2024/2853 applies to products
placed on the market after 8 December 2026 and brings its own
evidence expectations; the separate PLD kit covers scope, the shift
from the 1985 regime, and the update-supportability evidence
practice, none of which are here. If either describes you, this
pack is a good first step but not the thing you need, and you
should buy the relevant kit. If neither does, this pack is the
whole job.

Primary sources, so you can check rather than trust us:
  CRA  https://eur-lex.europa.eu/eli/reg/2024/2847/oj
  PLD  http://data.europa.eu/eli/dir/2024/2853/corrigendum/2026-05-07/oj

The PLD date is worth a note. The directive as published said 9
December 2026 in Article 2(1). Corrigendum 2026/90364, linked
above, corrected it to 8 December. If you see the older date
quoted elsewhere, that is why.


ORDER OF WORK

Day one, about two hours:
  1. Create a security@ alias at least two people read.
  2. Publish security.txt          (file 01)
  3. Publish the disclosure policy (file 02)
  4. Add SECURITY.md to the repo   (file 05)

Before you need it, about one hour:
  5. Walk the team through intake and triage (file 03)
  6. Read the advisory and CVE process once, so it is not new on
     the day you need it (file 04)
  7. Start the decision log (file 05). Today. Empty is fine.

The decision log is the one people skip. File 05 explains why it
is also the one that matters most later.


LICENCE

Use this inside your own organisation and in your own products.
Copy the templates into your repos, docs, and customer-facing
pages, edit freely, ship them. Do not resell or redistribute the
pack itself as a product.

If something here is wrong, we would rather know.

Toledo Technologies LLC
