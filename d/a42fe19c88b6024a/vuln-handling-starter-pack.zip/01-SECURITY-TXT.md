# 01 - security.txt

**NOT LEGAL ADVICE.** Technical guidance about a file format. Not legal advice, not a certification, not a compliance determination.

---

## What it is

A plain text file at a fixed path telling a stranger who found a bug in your product where to send it. Format: **RFC 9116** (April 2022). <https://www.rfc-editor.org/rfc/rfc9116.html>

Without it a researcher guesses. They try `security@`, which bounces. They try the contact form, which goes to sales. They open a public GitHub issue with a working exploit in it, because that was the only channel they could find. That last outcome is what this file prevents.

RFC 9116 is explicit that this is for **vulnerability response** - flaws in your product - not **incident response**, which is what you do when your own systems are broken into.

---

## The fields, one line each

Only two are mandatory.

| Field | Required? | Meaning |
|---|---|---|
| `Contact` | **Yes, 1+** | Where to send the report. `mailto:`, `https:`, or `tel:`. Listed several times, the order indicates priority. |
| `Expires` | **Yes, exactly 1** | Date/time after which the file should not be trusted. RFC 3339 format. RFC 9116 recommends under a year out. |
| `Encryption` | No | URI where your public key lives. The key itself must **not** be pasted in - only a link, a `dns:` URI, or an `openpgp4fpr:` fingerprint. |
| `Acknowledgments` | No | Link to the page thanking reporters. Must be `https://`. |
| `Preferred-Languages` | No, max 1 | Comma-separated RFC 5646 tags. No priority ordering. Absent means English is assumed. |
| `Canonical` | No, but publish it | Where this file is meant to live. See mistakes below. |
| `Policy` | No, but publish it | Link to your disclosure policy. Saves you the most email. |
| `Hiring` | No | Security job openings. Skip if not hiring. |
| `CSAF` | No | Link to a CSAF `provider-metadata.json`. Almost no small team has one. Skip. |

Format rules people trip on: plain text, UTF-8, served as `Content-Type: text/plain; charset=utf-8`; one field per line, ending LF or CRLF; no chaining multiple values onto one field; `#` starts a comment; field names are case-insensitive; **HTTPS only**.

---

## Where it goes

```
https://yourdomain.example/.well-known/security.txt
```

Required by RFC 9116, built on the well-known URI registry in RFC 8615. You may also keep a copy at `/security.txt` or redirect from there for older tooling; if both exist, `/.well-known/` wins.

**Scope is narrower than people assume.** RFC 9116 section 3.1: the file applies only to the exact domain or IP in the URI used to fetch it - not subdomains, not the parent domain. A file at `example.com` says nothing about `app.example.com`. It may, however, cover the products and services your organisation provides, which is the case that matters for most software teams and which you should spell out in the linked policy.

---

## Worked example

Invented for this walkthrough, using the `.example` TLD that RFC 2606 reserves for documentation, so nothing here points at a real organisation.

**Larkfield Systems.** Six people, one self-hosted inventory product plus a small hosted dashboard, no security staff, and one engineer - Priya - who owns this by default.

```
# security.txt for larkfield.example
# Covers this domain and the Larkfield Stock product.
# Questions about the policy itself: hello@larkfield.example

Contact: mailto:security@larkfield.example
Contact: https://larkfield.example/security/report
Expires: 2027-06-30T23:59:00Z
Encryption: https://larkfield.example/security/pubkey.asc
Policy: https://larkfield.example/security/disclosure-policy
Acknowledgments: https://larkfield.example/security/thanks
Preferred-Languages: en
Canonical: https://larkfield.example/.well-known/security.txt
```

Note what they did. `security@` is a **distribution list with three people on it**, not a mailbox, listed first because email is what they actually want. The web form is second, for researchers who will not send email. `Expires` is nine months out with a reminder at seven. The key sits on their own domain, not a keyserver they do not control. `Canonical` matches the URL exactly, including the missing `www.`.

---

## Common mistakes

**An `Expires` date in the past.** The most common failure, and worse than having no file. RFC 9116 section 5.3 says so directly. An expired file tells a researcher nobody is minding this, so the address probably bounces, so why bother. Put renewal in a shared calendar or in CI.

**No `Canonical`.** An attacker with write access to your site can replace or redirect this file and quietly collect your vulnerability reports. `Canonical` lets a researcher check the file claims to live where they found it; if it lists canonical URIs and theirs is not among them, RFC 9116 tells them not to trust it. It is also what makes a signature meaningful, by binding signed content to a location.

**A personal email address.** `priya@` works until Priya is on a plane, or leaves. Use a role address at least two people read, and test it from outside today. A `security@` alias forwarding to an inbox nobody opens is the same failure with extra steps.

**Pointing a field into `/.well-known/`.** Non-obvious. RFC 9116 section 6: referenced resources must not point into the well-known namespace unless registered with IANA, so `Encryption: https://example.com/.well-known/pubkey.asc` is invalid. Host keys at an ordinary path. `Canonical` is the exception, because `security.txt` itself is registered.

**Pasting the PGP key into the file.** Forbidden. `Encryption` takes a URI, not key material.

**Using `http://`, or serving it as HTML.** Web URIs in `Acknowledgments`, `Canonical`, `Encryption`, and `Policy` must begin with `https://`. If your framework returns `text/html`, or a 200-with-a-404-page, parsers break.

**Signing it then letting the signature rot.** Signing is recommended, not required. An unsigned, in-date, accurate file beats a signed one you forgot to re-sign after editing.

---

## Verify it is served correctly

From a machine outside your network:

```bash
# 1. Status, content type, redirects
curl -sSIL https://larkfield.example/.well-known/security.txt
# Want: HTTP/2 200 and content-type: text/plain; charset=utf-8

# 2. The body
curl -sSL https://larkfield.example/.well-known/security.txt

# 3. Confirm Expires is still in the future (GNU date)
curl -sSL https://larkfield.example/.well-known/security.txt \
  | awk -F': ' 'tolower($1)=="expires"{print $2}' \
  | xargs -I{} date -d {} +%s \
  | awk -v now="$(date +%s)" '{print ($1 > now) ? "OK" : "EXPIRED"}'

# 4. Check the legacy path is not serving a different, older file
curl -sSIL https://larkfield.example/security.txt
```

Then the human checks no parser does for you: send a real test email to the `Contact` address from an outside account and confirm a human saw it; click the `Policy` link; fetch the `Encryption` URI and confirm someone still holds the private half.

The validator at <https://securitytxt.org/> flags format errors. Treat it as a linter, not proof - it cannot tell you whether anyone reads the inbox. **Put steps 1 and 3 in CI weekly**, and this becomes a thing that tells you when it breaks rather than a thing you forget.
