# 05 - The Five Files

**NOT LEGAL ADVICE.** A checklist and templates. Not legal advice, not a certification, not a compliance determination. The support and end-of-life statement can interact with your customer contracts - see the note there.

---

## The list

If all five exist, are current, and are where people expect them, you have the hygiene that regulators and enterprise buyers assume you already had.

| # | File | Where | Why |
|---|---|---|---|
| 1 | `SECURITY.md` | repo root or `.github/` | GitHub surfaces it automatically; first place a developer looks |
| 2 | `security.txt` | `/.well-known/security.txt` | Where a researcher's tooling looks. RFC 9116 |
| 3 | Disclosure policy | a stable public URL | The commitments behind the two files above |
| 4 | **Decision log** | private, in the repo | The only record of *why* you did what you did |
| 5 | Support / EOL statement | a stable public URL | Makes "unsupported" a published fact, not an argument |

Files 2 and 3 are covered in files 01 and 02.

```
[ ] SECURITY.md exists and names a working contact
[ ] security.txt is served, and Expires is in the future
[ ] The disclosure policy URL in security.txt actually loads
[ ] The decision log exists and has at least one dated entry
[ ] The support statement names specific versions and dates
[ ] Two named humans read the security inbox
[ ] Someone outside the company sent a test report and got a reply
```

The last line is the only one that tests the whole chain. Do it.

---

## 1. SECURITY.md

Short on purpose. It points at the real policy rather than duplicating it - two copies means one is stale and you will not know which.

```markdown
# Security Policy

## Reporting a vulnerability

Please report security issues to **[security@yourdomain.example]**.

Do not open a public issue for a security vulnerability.

[If your repo is public and you have enabled private reporting:]
You can also use GitHub's private vulnerability reporting: go to
the **Security** tab and click **Report a vulnerability**.

We will acknowledge your report within **[2] business days** and
give you an initial assessment within **[10] business days**.

Our full disclosure policy, including scope and safe harbour, is at
**[https://yourdomain.example/security/disclosure-policy]**.

## Supported versions

| Version | Supported |
|---------|-----------|
| [2.5.x] | Yes       |
| [2.4.x] | Security fixes only, until [YYYY-MM-DD] |
| [< 2.4] | No        |

Full support policy: [https://yourdomain.example/support-policy]

## Our advisories

Published security advisories: [https://yourdomain.example/security/advisories]
```

Keep these numbers identical to the ones in your disclosure policy. Two different promises in two places is worse than none.

---

## 2 and 3. security.txt and the disclosure policy

Covered in files 01 and 02. Two things to carry forward: set a calendar reminder for the `Expires` date now, or put the check in CI, because an expired file is worse than none; and publish the policy at a URL that will not move, since both other files point at it.

---

## 4. The dated decision log

### Why people skip it

It has no immediate user. Nobody asks for it. It is not in a security questionnaire or a repo template. Nothing breaks the week you do not write it.

And it is the only file here that cannot be reconstructed later. You can write a `security.txt` in ten minutes at any future point, or adopt a disclosure policy the day before a customer asks. You cannot go back to March and recover why you decided a report was not exploitable, who agreed, or what evidence you looked at. That has a half-life of about one person's memory of a busy afternoon, then it is gone.

### Why it matters later

**An enterprise security review.** A prospect asks how you handle vulnerability reports. With a log you answer in one message with real examples. Without one you write a page of process description that a reviewer correctly reads as aspirational.

**A report comes back.** Eighteen months on the same issue resurfaces, now clearly exploitable because something else changed. With a log you see immediately what your reasoning was and which assumption broke. Without one you start from zero and will probably reach the same wrong answer.

**Someone asks what you knew.** Customer, insurer, regulator, or opposing counsel - the question is identical: what did you know, when, and what did you do. A dated note written *before* you knew how the story ended is worth far more than a reconstruction written after. A reconstruction is an argument; a contemporaneous note is evidence.

Both EU regimes in the README lean on exactly this. The CRA's obligations attach to what you knew about active exploitation and when; the PLD's expectations likewise turn on what a manufacturer knew and did. The specific evidence practices each calls for are in the respective kits. The underlying habit - write the decision and the date at the moment you make it - is what both assume you already have. Three minutes per entry.

### The rule

**Write the entry when you decide, not when you remember to.** An entry written three weeks later is a reconstruction. And if you only log the interesting cases you have a highlight reel - the boring "not exploitable, here is why" entries are the ones that turn out to matter.

Keep it in the repository so it is version-controlled and timestamped by git, in a private repo or private directory (`docs/security/decision-log.md`). Markdown is enough. Not a wiki page anyone can silently edit, and not a document with no revision history. Keep it separate from triage worksheets: those are per-report working documents, the log is the durable record, and it should stay short enough that someone will read it.

```markdown
# Security Decision Log

Append-only. Add entries at the bottom. Never edit or delete a past
entry - if something was wrong, add a correcting entry that says so
and references the original.

Format: one entry per decision. Keep each under ten lines.

---

## [YYYY-MM-DD] SEC-2026-001 - [One-line description]

**Decision:** [ fix now / fix in next release / backlog /
not a vulnerability / out of scope / forwarded upstream ]

**Decided by:** [NAME]
**Present / consulted:** [NAMES]

**What we knew:** [Two or three lines. The facts as they stood
today, not as they turned out. Include what you did not know.]

**Why:** [The reasoning. If you concluded it was not exploitable,
state the specific reason - "the endpoint requires an
authenticated admin session and the vulnerable parameter is
validated at the router" - not "assessed as low risk".]

**Active exploitation:** [ no evidence - basis: e.g. "app logs
searched 2026-09-15, 90-day retention, no matches" / evidence
found - detail / not checked - why not ]

**Follow-up:** [Action, owner, date. Or "none".]

---

## [YYYY-MM-DD] [Next entry]
```

### What else belongs in it

Not only vulnerability reports. Anything where you made a judgement a future reader would want the reasoning for: a decision **not** to fix something (the most valuable entries in any log); dropping support for a version; accepting a known risk, with its compensating control and review date; a dependency CVE you assessed as not reaching your code, with the reason; a change to your response commitments; a decision about whether to notify customers, either way; the date you last tested that the security inbox works.

### A worked entry

```markdown
## 2026-03-04 SEC-2026-002 - Path traversal report in export endpoint

**Decision:** Not a vulnerability in shipped product.
**Decided by:** P. Raman
**Present / consulted:** J. Okonkwo (reviewed the fix path)

**What we knew:** Reporter demonstrated traversal against
/api/export on a local build with DEV_ALLOW_RAW_PATHS=1. That flag
is set only in docker-compose.dev.yml. Confirmed it is not set in
any released artefact; checked the 2.4 and 2.5 release images.

**Why:** The vulnerable branch is unreachable without the dev flag.
No released configuration enables it. We are, separately, removing
the flag entirely in 2.6 because it is a foot-gun.

**Active exploitation:** No evidence. Not applicable - path is not
reachable in production builds.

**Follow-up:** Remove DEV_ALLOW_RAW_PATHS in 2.6 - J. Okonkwo -
2026-04-30. Replied to reporter 2026-03-04 with this reasoning and
offered credit; they declined.
```

Note what it does: records the specific technical reason, says what was checked and when, and stays understandable to someone who was not there. That is the whole bar.

---

## 5. Support and end-of-life statement

Without it, every decision about an old version is an argument. With it, "2.3 stopped receiving security fixes on 30 June" is a fact you published in advance. It also lets your disclosure policy put old versions out of scope without that looking like an excuse invented after the report arrived.

```markdown
# Support and End-of-Life Policy

**Last updated: [YYYY-MM-DD]**

## What we support

| Version | Released | Full support until | Security fixes until |
|---------|----------|--------------------|----------------------|
| [2.5.x] | [2026-05-01] | [2027-05-01] | [2027-11-01] |
| [2.4.x] | [2025-11-01] | [2026-05-01] | [2026-11-01] |
| [2.3.x] | [2025-04-01] | ended [2025-11-01] | ended [2026-04-01] |

**Full support** means bug fixes, security fixes, and compatibility
updates.

**Security fixes only** means we will fix vulnerabilities we assess
as [high severity or above], and nothing else.

**Ended** means we will not ship fixes for that version. We may
still describe it in an advisory so you know whether you are
affected.

## How long versions are supported

[Describe your rule in one or two sentences. For example: "Each
minor release receives full support for 12 months from its release
date, and security fixes for a further 6 months." Or: "We support
the current release and the one before it."]

>> A rule people can plan against is worth more than a table you
>> update ad hoc. Publish the rule and let the table follow from it.

## Notice before end of life

We will announce the end-of-life date for a version at least
[90] days in advance, at [https://yourdomain.example/changelog]
and by email to [customers on a support plan / the announce list].

## Upgrading

[Link to upgrade guide, migration notes, or LTS options.]

## Questions

[support@yourdomain.example]
```

**Two dates per version, not one.** End of full support and end of security fixes are different events. Collapsing them means either committing to feature work longer than you want, or cutting off security fixes sooner than customers expect.

**A rule beats a table.** Publish the rule ("12 months plus 6") and derive the table from it, so nobody has to ask what happens to a version you have not announced yet.

**Check your contracts first.** If you have signed enterprise agreements, MSAs, or support addenda with specific commitments, your public EOL statement must not undercut them. This is the one place in this file where a look from whoever handles your contracts is genuinely worth it - a public page contradicting a signed agreement is a bad thing to find during a renewal.

**Machine-readable EOL data.** endoflife.date maintains a public catalogue with a free API at <https://endoflife.date/api/v1/products> (473 products, no key). It is also useful for checking the EOL status of things *you* depend on. Whether to submit your own product is your call; it is a community-maintained dataset, not an official register.

---

## Closing

You are finished when all five files exist, the dates in them are real, two people read the inbox, and someone outside the company has sent a test report and had a reply from a human.

That is the whole hygiene layer. It is not large. Most teams do not have it, and the reason is not difficulty - it is that no single week is the week it becomes urgent, right up until the week it does.

If the EU Cyber Resilience Act (Regulation (EU) 2024/2847, Article 14 reporting enforceable from 11 September 2026 - <https://eur-lex.europa.eu/eli/reg/2024/2847/oj>) or the Product Liability Directive (Directive (EU) 2024/2853, applying to products placed on the market after 8 December 2026 per Corrigendum 2026/90364 - <http://data.europa.eu/eli/dir/2024/2853/corrigendum/2026-05-07/oj>) applies to you, this pack is the floor, not the ceiling. The reporting mechanics and the liability-side evidence practices are separate, substantial bodies of work, covered in the respective kits.

If neither applies, you are done. Put a reminder in the calendar to re-read these five files in twelve months.
