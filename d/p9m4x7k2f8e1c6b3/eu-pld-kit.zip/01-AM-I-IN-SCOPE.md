# 01 — Am I in scope?

**A decision tree for software teams. Directive (EU) 2024/2853.**

---

> **Not legal advice.** This file helps you *frame* the scope question and
> assemble the facts a lawyer will ask for. It cannot answer the question.
> Scope depends on your facts and on the national law that transposes the
> directive in each Member State. Nothing here is a compliance determination.
> Where a branch is genuinely unsettled we mark it `[VERIFY: ...]` rather than
> guess.

---

## Before you start: the directive does not work like a compliance regime

There is no registration, no notification, no certification, no audit and no
regulator that declares you in or out of scope. The directive creates a
**private right to compensation** that a natural person can bring in a national
court (Article 5(1)). "Scope" therefore means: *if someone were injured and
sued, could this directive be the basis of their claim against us?*

That difference matters for how you use this file. You are not filling in a
form for an authority. You are working out your own exposure.

---

## Question 0 — The date. What does the new regime attach to?

The directive attaches to a **product**, at the moment it is **placed on the
market or put into service** — not to your company, not to a calendar year, and
not to when the damage happens.

> "This Directive shall apply to products placed on the market or put into
> service after 8 December 2026."
> — Article 2(1), **as corrected by Corrigendum 2026/90364 of 7 May 2026**

That corrigendum is easy to miss and a lot of published commentary predates it.
The original Official Journal text of Article 2(1) read "after 9 December 2026";
the corrigendum replaced it with "after 8 December 2026". The consolidated text
on EUR-Lex carries the corrected wording, flagged `▼C1`.

The other dates were **not** changed by the corrigendum and still read
9 December 2026:

| Provision | Date | Article |
|---|---|---|
| New directive applies to products placed on market / put into service **after** | 8 December 2026 | Art. 2(1) as corrected |
| Directive 85/374/EEC repealed with effect from | 9 December 2026 | Art. 21 |
| 85/374/EEC continues to apply to products placed on market **before** that date | — | Art. 21 |
| Member State transposition deadline | 9 December 2026 | Art. 22(1) |
| First Commission evaluation | 9 December 2030 | Art. 20 |

Read together, the intent is clear and the planning answer is simple:
**products you place on the EU market from 9 December 2026 onward fall under the
new directive; products placed before then stay under the 1985 regime.** The
corrigendum removes a one-day gap in the original drafting. Do not build
anything around the 8th-versus-9th distinction.

`[VERIFY: if your product ships on or within days of 8-9 December 2026 and the
exact boundary day could matter to a claim, confirm the transposed national
wording in the relevant Member State — transposition statutes may phrase the
cut-over differently. This is a lawyer question, not an engineering one.]`

**Software-specific trap.** For software, "placed on the market" is not a
one-time event you can point at for the lifetime of the product. Two mechanisms
keep resetting it:

- A **substantial modification** made after placing on the market makes it, in
  effect, a new product; where that modification is made by software update or
  upgrade, or by the continuous learning of an AI system, the modified product
  is considered made available on the market at the moment the modification is
  actually made (Recital 40; definition at Article 4(18); modifier treated as
  manufacturer at Article 8(2)).
- Each new version you ship is its own placing on the market. `[VERIFY: whether
  each ordinary release of a SaaS product constitutes a fresh "placing on the
  market" such that a long-lived pre-2026 SaaS product is progressively brought
  under the new regime. The directive does not say so expressly. This is
  genuinely unsettled and is one of the most commercially significant open
  questions for SaaS. Ask a lawyer; do not assume the pre-2026 date protects a
  continuously deployed service.]`

The practical takeaway for a SaaS team: **do not assume that because your
service launched in 2019 you are outside the new directive forever.**

---

## Question 1 — Is what you ship a "product"?

> "'product' means all movables, even if integrated into, or inter-connected
> with, another movable or an immovable; it includes electricity, digital
> manufacturing files, raw materials and **software**"
> — Article 4(1)

Software is named in the operative definition. Recital 13 removes any doubt
about delivery model:

> "software is a product for the purposes of applying no-fault liability,
> irrespective of the mode of its supply or usage, and therefore irrespective of
> whether the software is stored on a device, accessed through a communication
> network or cloud technologies, or **supplied through a software-as-a-service
> model**."

**In, as products:**

| Thing | Basis |
|---|---|
| Operating systems, firmware, applications, computer programs | Recital 13 |
| SaaS | Recital 13 |
| AI systems; AI system providers are treated as manufacturers | Recital 13 (referencing Regulation (EU) 2024/1689) |
| Digital manufacturing files (CAD/3D-print templates with the functional information to drive machinery) | Art. 4(1), Art. 4(2), Recital 16 |
| Firmware embedded in a device you make | Art. 4(1) |

**Out, or treated differently:**

| Thing | Basis | Caution |
|---|---|---|
| **Information** as such — the content of digital files, media files, e-books | Recital 13 | The boundary between "information" and "software" is not defined anywhere in the operative text |
| **The mere source code of software** | Recital 13 | Says *mere source code*. Shipping a running program is a product; publishing source is treated differently |
| **Services as such** | Recital 17 | But see "related services" below — a digital service that is part of a product is pulled in as a **component** |
| Damage from nuclear accidents covered by ratified international conventions | Art. 2(3) | Irrelevant to most readers |

`[VERIFY: where the line falls between "the mere source code of software"
(not a product, Recital 13) and software you distribute in source form that a
customer compiles and runs commercially. The recital does not resolve this and
we found no operative text that does. If you ship source-form commercial
software, this is a specific question for your lawyer.]`

### Related services — the branch teams miss

> "'related service' means a digital service that is integrated into, or
> inter-connected with, a product in such a way that its absence would prevent
> the product from performing one or more of its functions."
> — Article 4(3)

A related service is a **component** of the product it serves (Article 4(4)), so
it comes inside the regime even though services as such do not. Recital 17 gives
the examples: continuous traffic data in a navigation system; a health
monitoring service using a product's sensors; a temperature control service for
a smart fridge; a voice-assistant service controlling products.

Expressly **not** a related service: **internet access services** (Recital 17).
But note the sting in the same recital — "a product that relies on internet
access services and fails to maintain safety in the event of a loss of
connectivity could be found to be defective."

**Engineering translation:** if your API or cloud backend is the thing without
which a customer's device or product loses a function, you are probably supplying
a component of their product, not merely a service to them.

---

## Question 2 — Which role do you play?

The directive lists the liable **economic operators** in Article 8(1). Work
through these in order.

### 2a. Are you a manufacturer?

> "'manufacturer' means any natural or legal person who:
> (a) develops, manufactures or produces a product;
> (b) has a product designed or manufactured, or who, by putting their name,
> trademark or other distinguishing features on that product, presents
> themselves as its manufacturer; or
> (c) develops, manufactures or produces a product for their own use"
> — Article 4(10)

For a software team, **(a) is the usual answer and it is broad: you develop the
software, so you are its manufacturer.** Recital 13 confirms: "A developer or
producer of software, including AI system providers ... should be treated as a
manufacturer."

Two traps in that definition:

- **(b) white-labelling.** If you put your name or mark on software someone else
  built, you are a manufacturer of it. Rebadged, OEM'd and white-labelled
  products land here.
- **(c) for their own use.** A product you develop and produce for your own use
  can still make you a manufacturer. `[VERIFY: how Article 4(10)(c) interacts
  with internal-only tooling that is never supplied to anyone. Article 2(1)
  scopes the directive to products "placed on the market or put into service",
  and "putting into service" (Art. 4(9)) means first use in the Union in the
  course of a commercial activity where the product was not placed on the market
  first. Whether purely internal software is "put into service" in that sense is
  not resolved in the text. Ask a lawyer if you run internally-built software in
  a safety-relevant path.]`

### 2b. Are you a component manufacturer?

> "the manufacturer of a defective component, where that component was
> integrated into, or inter-connected with, a product within the manufacturer's
> control and caused that product to be defective"
> — Article 8(1)(b)

If you sell an SDK, a library, an API, an embedded module or a model that gets
built into someone else's product, this is you. The claimant can go after both
you and the product manufacturer, and liability is **joint and several**
(Article 12(1)) — the injured person can recover the whole amount from either.

There is one relief valve written specifically for small software vendors:

> A manufacturer that integrates software as a component shall have **no right
> of recourse** against the software component manufacturer where that software
> manufacturer was a **microenterprise or small enterprise** at the time of
> placing on the market, **and** the two contractually agreed to waive that
> right.
> — Article 12(2), size defined by reference to Commission Recommendation
> 2003/361/EC; see also Recital 54

Read that carefully, because it is narrower than it first looks:

- It removes the **integrator's recourse against you**. It does **not** remove
  your liability to the injured person. Article 15 forbids limiting or excluding
  liability towards the injured person by contract, full stop.
- It requires **an actual contract term**. It is not automatic.
- It requires you to have been micro or small **at the time of placing on the
  market**, assessed together with partner and linked enterprises.

If you are a small software vendor selling components to larger manufacturers,
**this clause is worth raising with your lawyer in your next contract cycle.**
It is one of very few places the directive gives you something to negotiate for.

### 2c. Are you an importer, authorised representative or fulfilment provider?

These matter when the manufacturer is **established outside the Union**
(Article 8(1)(c)):

- **Importer** — "any natural or legal person who places a product from a third
  country on the Union market" (Art. 4(12)). If you are a non-EU software vendor
  and an EU entity puts your product on the EU market, that entity is an
  importer and is liable alongside you.
- **Authorised representative** — a person established in the Union with a
  written mandate from the manufacturer for specified tasks (Art. 4(11)).
- **Fulfilment service provider** — liable only **where there is no importer or
  authorised representative established in the Union** (Art. 8(1)(c)(iii)).
  Defined by warehousing/packaging/addressing/dispatching (Art. 4(13)), so for
  pure software this will rarely bite.

`[VERIFY: whether a non-EU SaaS vendor selling directly to EU customers with no
EU entity has an "importer" at all, and what that means for where a claim lands.
The importer definition is framed around placing a product from a third country
on the Union market, which maps awkwardly onto a service delivered over the
network. This is a significant open question for non-EU SaaS companies and needs
a lawyer.]`

### 2d. Are you a distributor or a reseller?

> Where an economic operator from Article 8(1) **established in the Union**
> cannot be identified, each distributor is liable where the injured person asks
> them to identify such an operator (or their own supplier) and the distributor
> **fails to do so within one month**.
> — Article 8(3)

Distributor liability is a fallback, and the escape is procedural and fast: name
an EU-established operator within **one month** of the request.

**Operational consequence, and it is a cheap one:** if you resell or distribute
other people's software into the EU, keep a record that lets you answer "who
made this, and which EU-established entity is on the hook" within a month. That
is a supplier register, not a legal project. File 04 includes one.

The same fallback applies to **online platforms** that let consumers conclude
distance contracts with traders, where the Article 6(3) DSA conditions are met
(Article 8(4), Recital 38).

### 2e. Did you substantially modify someone else's product?

> "Any natural or legal person that substantially modifies a product outside the
> manufacturer's control and thereafter makes it available on the market or puts
> it into service shall be considered to be a manufacturer of that product."
> — Article 8(2)

> "'substantial modification' means a modification of a product after it has
> been placed on the market or put into service:
> (a) that is considered substantial under relevant Union or national rules on
> product safety; or
> (b) where no such threshold exists, that:
> (i) changes the product's original performance, purpose or type, without that
> change having been foreseen in the manufacturer's initial risk assessment; and
> (ii) changes the nature of the hazard, creates a new hazard or increases the
> level of risk."
> — Article 4(18)

Note limb (b) is **cumulative** — both (i) and (ii) must hold.

This is the **systems integrator and platform-engineering branch**, and it is
the one most likely to surprise a team that thinks of itself as a customer
rather than a manufacturer. If you take a vendor's product, change it beyond
what its maker foresaw, and then supply the result onward, you may have become
its manufacturer.

There is a defence available specifically to a modifier: they are not liable if
they prove the defectiveness relates to **a part of the product not affected by
the modification** (Article 11(1)(g)).

Recital 39 also confirms that economic operators carrying out **repairs or other
operations that do not involve substantial modifications** are not liable under
this directive.

`[VERIFY: whether routine fine-tuning, RAG grounding, prompt-layer wrapping or
system-prompt configuration of a third-party foundation model amounts to a
"substantial modification" under Art. 4(18)(b), making the integrator a
manufacturer of the modified AI system under Art. 8(2). Recital 40 expressly
brings "the continuous learning of an AI system" into the substantial
modification concept, but does not address deployer-side adaptation. We could
find no operative text or Commission guidance resolving this. For anyone
building on third-party models this is the single most important open question
in the whole directive, and it needs a lawyer.]`

---

## Question 3 — Do you place it on the EU market?

> "'making available on the market' means any supply of a product for
> distribution, consumption or use on the Union market **in the course of a
> commercial activity, whether in return for payment or free of charge**"
> — Article 4(7)
>
> "'placing on the market' means the first making available of a product on the
> Union market" — Article 4(8)
>
> "'putting into service' means the first use of a product in the Union in the
> course of a commercial activity, whether in return for payment or free of
> charge, in circumstances in which that product has not been placed on the
> market prior to its first use" — Article 4(9)

Three things engineering leaders repeatedly get wrong here:

1. **"Free of charge" does not take you out.** It is in both definitions.
   Recital 26 adds sponsorship-funded and publicly-funded examples. A free tier,
   a free developer edition, a free mobile app — all still supplied in the
   course of a commercial activity if your business is commercial.
2. **The test is commercial activity, not payment.** Recital 14 goes further for
   software specifically: supply "in exchange for a price, **or for personal
   data used other than exclusively for improving the security, compatibility or
   interoperability of the software**" is supply in the course of a commercial
   activity. Monetising user data instead of charging money does not help you.
3. **It is about the EU market, not your address.** A US company with EU users is
   supplying the Union market.

`[VERIFY: what counts as supplying "the Union market" for a globally-available
web application with no EU establishment, no EU targeting and incidental EU
users. The directive does not contain a targeting test comparable to the one in
consumer jurisdiction rules. This needs a lawyer if it describes you.]`

---

## Question 4 — The free and open-source software carve-out

This is the branch most often stated wrongly, including by people who should
know better. The operative text is short:

> "This Directive does not apply to free and open-source software that is
> **developed or supplied outside the course of a commercial activity**."
> — Article 2(2)

**The carve-out is about commercial activity, not about the licence.** An MIT or
GPL licence does not put you outside the directive. Supplying that software in
the course of a commercial activity does put you inside it.

Recital 14 gives the detail, and it is worth reading closely:

- FOSS developed or supplied outside the course of a commercial activity is out,
  "since products so developed or supplied are **by definition not placed on the
  market**."
- "Developing or contributing to such software should not be understood as
  making it available on the market."
- "**Providing such software on open repositories should not be considered as
  making it available on the market, unless that occurs in the course of a
  commercial activity.**"
- "In principle, the supply of free and open-source software by **non-profit
  organisations** should not be considered as taking place in a business-related
  context, unless such supply occurs in the course of a commercial activity."
- "However, where software is supplied **in exchange for a price, or for
  personal data used other than exclusively for improving the security,
  compatibility or interoperability of the software**, and is therefore supplied
  in the course of a commercial activity, this Directive should apply."

### What this means in practice

| Situation | Likely position | Caution |
|---|---|---|
| You publish a library on GitHub as an individual, unpaid, no commercial offering | Outside — Art. 2(2), Recital 14 | Applies to the FOSS supply itself |
| A non-profit foundation distributes a project, no commercial supply | "In principle" outside — Recital 14 | Recital says "in principle"; it is not absolute |
| You sell a paid support or hosted tier of your own open-source project | The commercial supply is **in the course of a commercial activity** | Open-core is the classic hard case |
| You open-source a component that is also part of your commercial product | The commercial product is in scope regardless of the licence | The licence does not shield the product |
| You are an employee contributing to FOSS as part of your paid job | `[VERIFY]` — see below | Genuinely unsettled |

`[VERIFY: whether an employee contributing to an open-source project during paid
working hours, where the employer benefits commercially from the project, is
supplying "outside the course of a commercial activity" under Art. 2(2).
Recital 14 says developing or contributing is not making available on the
market, which points one way; but "outside the course of a commercial activity"
points another. We could not resolve this from the text. If your company's
commercial position depends on an open-source project you sponsor, ask a
lawyer.]`

`[VERIFY: how Art. 2(2) applies to dual-licensed and open-core models where the
same codebase is supplied both non-commercially and commercially. The text does
not address it directly.]`

### The most important consequence for consumers of FOSS

> Where FOSS supplied outside the course of a commercial activity is
> **subsequently integrated by a manufacturer as a component into a product in
> the course of a commercial activity** and thereby placed on the market, **that
> manufacturer** can be held liable for damage caused by the defectiveness of
> such software — **but not the manufacturer of the software**, because it would
> not have fulfilled the conditions of placing a product on the market.
> — Recital 15

Read that twice if you build on open source, because it is the line that makes
this whole kit worth doing:

**The liability for a defect in the non-commercial open-source component you
shipped lands on you, not on the upstream maintainer.**

That is the honest, unglamorous reason a component inventory matters. The
unpaid volunteer who wrote the library you depend on is carved out. You, who put
it in a commercial product, are not. And if that component is past end of life,
nobody upstream is going to ship you a security fix. That is precisely the fact
`pld-watch` was built to surface, and precisely why File 03 is the heart of this
kit.

---

## Question 5 — Could anyone actually claim against you?

Being in scope is not the same as being exposed. A claim needs recoverable
damage. The directive covers **only** these (Article 6(1)):

- **(a)** death or personal injury, including medically recognised damage to
  psychological health;
- **(b)** damage to, or destruction of, any property, **except**: (i) the
  defective product itself; (ii) a product damaged by a defective component the
  manufacturer integrated or that was within its control; (iii) **property used
  exclusively for professional purposes**;
- **(c)** **destruction or corruption of data that are not used for professional
  purposes**.

Recoverable to **natural persons** only (Article 5(1)). And note what is
**excluded** — Recital 24: "Types of damage other than those provided for in
this Directive, such as **pure economic loss, privacy infringements or
discrimination**, should not by themselves trigger liability under this
Directive."

**So, bluntly:** a pure B2B SaaS tool used exclusively by businesses on
business-owned equipment, whose realistic failure mode is downtime or financial
loss, has materially less PLD exposure than the internet is telling you. Downtime
is pure economic loss. Business property is excluded. A data breach is a GDPR
matter, and Recital 20 expressly distinguishes destruction/corruption of data
from data leaks and data protection infringements.

Where software exposure is real:

- Software that can cause **physical harm** — medical, industrial, automotive,
  robotics, building control, anything driving hardware.
- Software handling **consumers' personal (non-professional) data** where a
  defect could **destroy or corrupt** it — consumer backup, photo storage, note
  apps, password managers, consumer cloud sync.
- **Consumer** devices and apps generally, where the user is a natural person and
  the property is theirs.
- Components inside any of the above, including AI components.

Note the mixed-use rule: property used for both private and professional purposes
**is** covered (Recital 25), only *exclusively* professional property is out. But
for **data** the rule is stricter — data used for professional purposes, "even if
not exclusively so", is excluded (Recital 22). Those two rules differ. That is
deliberate, and it matters for a device or app used for both work and home.

---

## Your scope card

Fill this in, date it, and keep it with the evidence file from File 03.

```
PRODUCT SCOPE CARD                      Date: ____________
Product / service: ______________________________________
Owner: _________________________________________________

Q0  First placed on EU market / put into service: __________
    On or after 9 Dec 2026?                      [ ] Y [ ] N
    Substantially modified since?                [ ] Y [ ] N [ ] Unsure
    If continuously deployed SaaS, flagged for legal?  [ ] Y

Q1  Is it software / a related service / a digital
    manufacturing file?                          [ ] Y [ ] N
    Which:  [ ] standalone software  [ ] SaaS  [ ] firmware
            [ ] AI system  [ ] component/SDK/API
            [ ] related service to someone else's product

Q2  Our role(s):
    [ ] Manufacturer (Art. 4(10)(a) - we develop it)
    [ ] Manufacturer by name/mark (Art. 4(10)(b))
    [ ] Component manufacturer (Art. 8(1)(b))
    [ ] Importer (Art. 4(12))
    [ ] Authorised representative (Art. 4(11))
    [ ] Fulfilment service provider (Art. 4(13))
    [ ] Distributor (Art. 4(14))
    [ ] Substantial modifier (Art. 8(2))
    If micro/small enterprise supplying software components:
    Art. 12(2) recourse waiver raised with legal?     [ ] Y [ ] N

Q3  Supplied on the EU market in the course of a commercial
    activity (incl. free tiers)?                 [ ] Y [ ] N

Q4  Any part supplied as FOSS outside commercial activity?
    [ ] N/A  [ ] Yes - describe: ___________________________
    FOSS components we ship inside our commercial product:
    (liability for these is ours - Recital 15)
    Count from pld-watch / SBOM: ____________

Q5  Realistic damage types if our product failed badly:
    [ ] Death or personal injury (incl. psychological)
    [ ] Damage to non-professional property
    [ ] Destruction/corruption of non-professional data
    [ ] None of the above - only downtime / financial loss
        (= pure economic loss, not covered: Recital 24)

PROVISIONAL VIEW: [ ] plausibly in scope
                  [ ] plausibly out of scope
                  [ ] cannot tell without advice

Questions for our lawyer (list every [VERIFY] that applied):
1. ______________________________________________________
2. ______________________________________________________
3. ______________________________________________________

Completed by: ______________  Reviewed by: ______________
```

---

## When to stop and get a lawyer

Stop and take advice — do not reason your way past these:

1. Your software could contribute to **physical injury**. That is the highest-
   exposure branch and it is not a self-assessment matter.
2. You build on **third-party foundation models** and adapt them. See the
   substantial-modification `[VERIFY]` above.
3. You are **non-EU with EU users and no EU entity**.
4. Your commercial model is **open-core, dual-licensed, or a sponsored open
   source project**.
5. You are a **small software component vendor** and want the Article 12(2)
   recourse waiver in your contracts.
6. You are about to **publish a support policy** making public commitments about
   security updates. Everything in File 04 needs legal review before it goes out.
7. Any answer above was "cannot tell".

---

*Toledo Technologies LLC. Not legal advice. Sources: Directive (EU) 2024/2853,
https://eur-lex.europa.eu/eli/dir/2024/2853/oj ; consolidated text
https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:02024L2853-20241118 ;
Corrigendum 2026/90364
https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202690364*
