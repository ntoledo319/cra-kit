# 05 — Board brief

**EU Product Liability Directive (EU) 2024/2853 — what a board or insurer needs
to know.**

Prepared by: `[NAME, ROLE]` · Date: `[YYYY-MM-DD]` · For: `[BOARD / INSURER]`

---

> **Not legal advice.** This brief summarises a legal instrument for a business
> audience. It is not legal advice, not a compliance determination, and not a
> legal opinion on the company's exposure. It was prepared from the primary text
> on EUR-Lex by the engineering function, not by counsel. Where the position is
> genuinely unsettled it says so. Take advice from a qualified lawyer before
> acting on it.

---

## 1. The change, in five lines

- Directive (EU) 2024/2853 replaces the 1985 product liability directive. It
  applies to products placed on the EU market or put into service **from
  9 December 2026**. Products placed before then stay under the old regime.
  (Arts. 2(1), 21, 22(1); Art. 2(1) as corrected by Corrigendum 2026/90364.)
- **Software, SaaS and AI systems are now expressly "products".** (Art. 4(1);
  Recital 13.)
- Liability is **no-fault**, as it was in 1985. A claimant proves defect, damage
  and causation — not negligence. (Art. 10(1).)
- **The defence that "the defect arose after we shipped" is switched off** where
  the defectiveness is due to software, updates, **a lack of updates necessary to
  maintain safety**, or a substantial modification, and the product is within our
  control. We are treated as retaining control simply by **having the ability**
  to supply updates. (Arts. 11(2), 4(5)(b).)
- There are **new procedural mechanisms**: a court can order us to disclose
  evidence, and failing to disclose **presumes the product defective**.
  (Arts. 9, 10(2)(a).)

## 2. What it is not — read this before reacting

This is the part most external commentary gets wrong, and a board should hear it
first.

- **It is not an emergency.** The directive has been in force since December 2024
  and applies from December 2026. This is planned work, not incident response.
- **It is not a certification or registration regime.** There is no badge, no
  notified body, no audit, no regulator that approves us and no filing to make.
  Nobody can be "PLD certified". Any vendor selling that is selling something
  that does not exist.
- **It does not require us to patch anything.** In terms: "This Directive does
  not impose any obligation to provide updates or upgrades for a product."
  (Recital 51.) It attaches a liability consequence to a *defect consisting in*
  a missing safety-necessary update, which is a different thing. (Other EU law
  may impose update duties on us; that is a separate question, outside this
  brief.)
- **It is not a fines regime.** There are no administrative penalties here. The
  exposure is civil claims for compensation by injured natural persons.
- **It does not create a B2B damages route.** Only **natural persons** can claim
  (Art. 5(1)).
- **Shipping a fix is not an admission.** A product is not defective merely
  because a better product or an update came later (Art. 7(3); Recital 35).

## 3. Our exposure, honestly assessed

Only these damage types are recoverable (Art. 6(1)):

| Recoverable | Not recoverable |
|---|---|
| Death or personal injury, incl. medically recognised psychological harm | The defective product itself |
| Damage to property (no minimum threshold) | Property used **exclusively** for professional purposes |
| Destruction or corruption of **non-professional** data | Data used for professional purposes, **even if not exclusively** (Recital 22) |
| | Pure economic loss, privacy infringements, discrimination (Recital 24) |

**What that means for us specifically:** `[COMPLETE THIS HONESTLY — the most
important paragraph in the brief. Examples of a truthful answer:]`

> *If pure B2B SaaS:* "Our product is used exclusively by business customers on
> business-owned equipment. Our realistic failure modes are downtime and
> financial loss, which are pure economic loss and not recoverable under this
> directive (Recital 24). Our assessed PLD exposure is low. Our material
> regulatory exposure remains GDPR and contractual."
>
> *If consumer data:* "We hold personal, non-professional data for consumers. A
> defect causing destruction or corruption of that data is squarely within
> Art. 6(1)(c). Our exposure is real but bounded by the fact that loss is not
> automatic where data can be restored at no cost (Recital 20), which makes our
> backup and restore path directly relevant."
>
> *If software touching hardware:* "Our software controls [X]. A defect could
> contribute to physical injury. This is the highest-exposure category and we
> have taken external legal advice."

**Financial framing:** there are no liability caps. Article 15 prohibits
limiting or excluding liability towards the injured person by contract or by
national law, and the old option for a national ceiling is gone. **Our standard
limitation-of-liability clause does not apply to a PLD claim.**

**Time exposure.** Ten years from placing a product on the market (Art. 17(1));
25 years for latent personal injury (Art. 17(2)); a fresh 10 years if a product
is substantially modified (Art. 17(1)(b)). A product shipped on 9 December 2026
carries a claim window to **December 2036**, and potentially to **December 2051**
for latent injury. That drives a records retention decision, not a product
decision.

## 4. What it implies for engineering

Modest, and mostly things a well-run team does anyway. The value is that they
are now also evidence.

| Work | Effort | Status |
|---|---|---|
| Component inventory per released version (SBOM) | `[X days]` | `[ ]` |
| End-of-life tracking for components we ship | `[X days]` | `[ ]` |
| Public security update policy with stated support windows | `[X days]` + legal review | `[ ]` |
| End-of-support notice practice | `[X days]` | `[ ]` |
| Written records where we decide not to patch | ongoing, ~15 min each | `[ ]` |
| Retention of the above aligned to the liability periods | `[X days]` | `[ ]` |

Our initial baseline: `[N]` components past upstream end-of-life across `[M]`
products, from a scan dated `[YYYY-MM-DD]`. `[Of those, N are reachable in
shipped artefacts.]`

`[Note the method and its limits: "Scanned with pld-watch against the public
endoflife.date catalogue. This covers declared runtimes and frameworks; it is not
a vulnerability scan and does not cover transitive dependencies. N components
returned 'unknown' and are being determined manually."]`

**Estimated cost:** `[X engineering days]` for the initial pass, then roughly
`[Y days per quarter]` to maintain. `[Plus legal review of the published policy,
estimated £/€ Z.]`

## 5. Why this is worth doing now rather than later

Three reasons, none of them alarmist:

1. **Records cannot be backdated.** A dated component inventory and EOL scan
   attached to each release is trivial to produce today and impossible to
   recreate in 2029. Article 9 lets a court order us to disclose evidence, and
   Recital 42 confirms that can include documents we have to compile from
   scratch. Compiling from records that exist is a different exercise from
   reconstructing intent from memory.
2. **Failing to produce evidence has a defined consequence.** Article 10(2)(a):
   failure to disclose relevant evidence when ordered means defectiveness is
   presumed. That is the one procedural risk squarely within our control.
3. **Customers are already asking.** `[True? If enterprise procurement or
   insurers have raised this, say so here with specifics. If not, delete this
   point rather than inventing demand.]`

## 6. Decisions we are asking the board for

`[EDIT TO WHAT YOU ACTUALLY NEED. Suggested:]`

1. **Approve** `[X]` engineering days this quarter for the component inventory
   and EOL baseline.
2. **Approve** legal review of a public security update support policy before
   publication, estimated `[cost]`.
3. **Note** that we will publish stated support windows, which are public
   commitments we must then meet.
4. **Note** the records retention implication: release-linked technical records
   kept for 10+ years, which is longer than our current default.
5. `[If exposure is in the personal injury category:]` **Approve** external legal
   advice on scope and on insurance adequacy.

## 7. Insurance

`[FOR AN INSURER AUDIENCE, OR A BOARD DISCUSSION WITH A BROKER. Questions worth
putting to the broker — we are not stating the answers, because coverage is
policy-specific:]`

- Does our current product liability or tech E&O policy respond to a claim under
  national law transposing Directive (EU) 2024/2853?
- Does it cover **software as a product**, as opposed to professional services?
- Does it respond to **destruction or corruption of a consumer's data**
  (Art. 6(1)(c)) as property-type damage?
- Does the policy period model work against a **10-year** (or 25-year) expiry
  period, and what happens to claims after we stop renewing?
- Does it cover **defence and disclosure costs** in an Article 9 disclosure
  process?
- Are there exclusions for known-unpatched components or for end-of-life
  software?

`[VERIFY: all of the above with our broker. We are not in a position to state
what any policy covers, and this brief does not.]`

The Commission is required to report on the availability of product liability
insurance in its first evaluation, due by 9 December 2030 (Art. 20). Market
practice for software cover is therefore likely to move over the next few years.

## 8. Open questions we cannot answer internally

Stated plainly, because a brief that hides its uncertainty is not useful.

1. **Does a continuously deployed SaaS product get re-placed on the market with
   each release?** If yes, a long-lived service progressively comes under the new
   regime rather than staying under the 1985 one. The directive does not address
   this. It is the most commercially significant open question for us.
   `[If not a SaaS business, delete.]`
2. **Does adapting a third-party AI model amount to a "substantial
   modification"?** If so, the adapter becomes a manufacturer of the modified
   product (Art. 8(2)). Recital 40 brings continuous learning of an AI system
   into the concept but does not address deployer-side adaptation such as
   fine-tuning or prompt-layer configuration. `[If we build on third-party
   models, this is material to us.]`
3. **Where does "software" end and "information" begin?** Recital 13 excludes
   information and "the mere source code of software" from the product concept,
   but the operative text does not define the boundary.
4. **How will national transposition differ?** Standard of proof, disclosure
   procedure, non-material damages and any Article 18 derogation from the
   development risk defence are set nationally. We have not reviewed the
   transposition law of `[MEMBER STATES]`.
5. **What will "necessary to maintain safety" mean in practice?** This is the
   phrase in Article 11(2)(c) that decides how far the narrowed defence reaches.
   It will be settled by case law, not by text. Article 19 requires Member States
   to publish final appellate judgments and the Commission to maintain a public
   database of them; early judgments are worth watching.

**Our position on all five:** we are not guessing. Where an answer is needed for
a decision, we will take advice on that specific question rather than adopt a
general posture.

## 9. Bottom line

The directive is a real and permanent change to the liability position for
software sold into the EU, and the update/control point is genuinely new. It is
not an emergency, there is nothing to be certified against, and the work it
implies for us is modest and mostly overlaps with ordinary engineering hygiene.

The one thing that is time-sensitive is **the record**, because records cannot be
created retrospectively. That is what we are asking to start now.

---

**Appendix — primary sources**

- Directive (EU) 2024/2853, full text:
  https://eur-lex.europa.eu/eli/dir/2024/2853/oj
- Consolidated text incorporating the corrigendum:
  https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:02024L2853-20241118
- Corrigendum 2026/90364 of 7 May 2026 (amends Art. 2(1)):
  https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202690364
- Council Directive 85/374/EEC (repealed from 9 December 2026):
  https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:31985L0374

**Key provisions cited in this brief**

| Provision | Subject |
|---|---|
| Art. 2(1) | Applies to products placed on market / put into service after 8 Dec 2026 (as corrected) |
| Art. 2(2) | FOSS outside commercial activity excluded |
| Art. 4(1) | "Product" includes software |
| Art. 4(5)(b) | Control = ability to supply updates |
| Art. 4(18) | Substantial modification |
| Art. 5(1) | Natural persons only |
| Art. 6(1) | Recoverable damage, incl. non-professional data |
| Art. 7(2) | Defectiveness factors |
| Art. 8 | Liable economic operators |
| Art. 9 | Disclosure of evidence |
| Art. 10 | Burden of proof and presumptions |
| Art. 11(1) | Defences |
| Art. 11(2) | Narrowing of the later-defect defence |
| Art. 12(2) | Recourse waiver for micro/small software component makers |
| Art. 15 | No contractual limitation of liability |
| Arts. 16, 17 | Limitation (3 yrs) and expiry (10 / 25 yrs) |
| Art. 19 | Judgment publication and Commission database |
| Art. 21, 22 | Repeal of 85/374/EEC and transposition, 9 Dec 2026 |

---

*Toledo Technologies LLC. Not legal advice.*
