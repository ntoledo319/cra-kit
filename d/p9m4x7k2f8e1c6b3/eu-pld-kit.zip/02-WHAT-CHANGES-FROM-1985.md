# 02 — What changes from 1985

**Directive 85/374/EEC vs Directive (EU) 2024/2853, for engineering and product
leaders.**

---

> **Not legal advice.** This is a plain-English comparison of two legal texts,
> written by engineers for engineers. It is not legal advice, not a compliance
> determination, and not a substitute for reading the directive or taking advice.
> Both directives are linked at the end. Where we could not verify something we
> say so with a `[VERIFY: ...]` marker instead of guessing.

---

## The one-paragraph version

The 1985 directive already imposed **no-fault (strict) liability**: if your
product was defective and it hurt someone, you paid, whether or not you were
careless. That has not changed and was never the news. What changed in 2024 is
**what counts as a product** (software is now named in the text), **how long
your responsibility runs** (control now follows the update channel, not the
shipping date), **how hard it is for a claimant to prove their case** (new
disclosure duty and new presumptions), and **what you can be made to pay for**
(data loss is in, the €500 property threshold is gone).

For a software team, the change with teeth is this: **you can no longer rely on
"the defect appeared after we shipped it" for a defect that consists in the
absence of a security update you could have supplied.**

---

## Side by side

| | **85/374/EEC (1985)** | **(EU) 2024/2853 (2024)** |
|---|---|---|
| **Is software a product?** | Not mentioned. "all movables ... includes electricity" (Art. 2). Whether software qualified was argued for 30 years | Yes, expressly. "includes electricity, digital manufacturing files, raw materials and **software**" (Art. 4(1)); SaaS and AI covered regardless of delivery model (Recital 13) |
| **Services** | Out of scope | Services as such still out, **but** a "related service" without which the product loses a function is a **component** and comes in (Art. 4(3), 4(4), Recital 17) |
| **Who is liable** | Producer, component producer, own-brander, importer into the Community; supplier as fallback (Art. 3) | Manufacturer, component manufacturer, **importer, authorised representative, fulfilment service provider**; distributor and certain online platforms as fallback; **substantial modifier treated as manufacturer** (Art. 8) |
| **When does responsibility end?** | At "putting into circulation". Defence if the defect "came into being afterwards" (Art. 7(b)) | Same defence (Art. 11(1)(c)) — **but disapplied** for related services, software and updates, **lack of safety-necessary updates**, and substantial modification, where within the manufacturer's control (Art. 11(2)) |
| **Defectiveness test** | Safety a person is entitled to expect, considering presentation, expected use, time of circulation — **three factors** (Art. 6) | Same core test, **nine listed factors** including learning ability, interconnection effects, **safety-relevant cybersecurity requirements**, recalls, and the moment the product left the manufacturer's control (Art. 7(2)) |
| **Burden of proof** | Claimant proves damage, defect, causation. Full stop (Art. 4) | Same baseline (Art. 10(1)) **plus four routes to a presumption** (Art. 10(2)-(4)) |
| **Disclosure of evidence** | Nothing | Court can order the **defendant** to disclose relevant evidence, including documents created ex novo (Art. 9, Recital 42). Non-disclosure **presumes defectiveness** (Art. 10(2)(a)) |
| **Recoverable damage** | Death, personal injury; property damage for private-use items, **with a €500 (500 ECU) lower threshold** (Art. 9) | Death, personal injury **including medically recognised psychological harm**; property damage **with no lower threshold**; **destruction or corruption of non-professional data** (Art. 6(1)) |
| **Financial ceiling** | Member State could cap total liability for identical items at not less than 70 million ECU (Art. 16) | **No such option.** Liability must not be limited or excluded by contract or by national law (Art. 15, Recital 56) |
| **Limitation period** | 3 years from awareness of damage, defect, producer identity (Art. 10) | 3 years, same trigger (Art. 16) |
| **Expiry period** | 10 years from putting into circulation (Art. 11) | 10 years from placing on market / putting into service; **25 years for latent personal injury**; **restarts on substantial modification** (Art. 17, Art. 17(1)(b)) |
| **Harmonisation** | Minimum-ish, with options for Member States | **Maximum harmonisation** — no more stringent or less stringent national provisions (Art. 3) |
| **FOSS** | Nothing | Express carve-out for FOSS developed or supplied **outside the course of a commercial activity** (Art. 2(2), Recitals 14-15) |
| **Transparency** | None | Member States publish final appellate judgments; Commission maintains a public database (Art. 19) |

---

## The five changes that matter to an engineering team

### 1. Software is a product, and the delivery model does not save you

The old fight was whether software was a "movable". That fight is over.
Article 4(1) names software. Recital 13 covers "operating systems, firmware,
computer programs, applications or AI systems", and says the answer does not
change whether the software is "stored on a device, accessed through a
communication network or cloud technologies, or supplied through a
software-as-a-service model."

**What it does not cover:** "Information is not ... to be considered a product",
so "the content of digital files, such as media files or e-books or the mere
source code of software" is out (Recital 13). The line between information and
software is not defined in the operative text.

**Engineering translation:** the architecture diagram does not change your
exposure. Shipping a binary, running a cloud service, and embedding firmware all
land in the same place.

### 2. The update channel is now a control channel — and control is the hinge

This is the structural change. Under 85/374/EEC, "putting into circulation" was
effectively a finish line. The 2024 directive replaces the finish line with a
question: **do you still have control?**

> "'manufacturer's control' means that: ... (b) the manufacturer of a product
> **has the ability to supply software updates or upgrades, themselves or via a
> third party**."
> — Article 4(5)(b)

Note what that says. Not *does supply*. Not *promised to supply*. **Has the
ability to supply.** Recital 19 restates it: once placed on the market, a
product "should be considered to remain within the manufacturer's control where
the manufacturer retains the ability to supply software updates or upgrades
itself or via a third party."

Control also covers components and updates that you **authorise or consent to**
from a third party (Art. 4(5)(a)(i)). Recital 18 draws the boundary usefully:
you are **not** taken to have consented "merely by providing for the technical
possibility of integration or inter-connection or by recommending certain brands
or by not prohibiting potential related services or components." So a plugin API
alone is not consent; presenting a third-party component as part of your
product is.

Control then does two jobs:

- It is a **factor in defectiveness** — Article 7(2)(e) directs the court to the
  moment the product was placed on the market "or, where the manufacturer
  retains control over the product after that moment, the moment in time when
  the product left the control of the manufacturer."
- It **switches off the later-defect defence** — Article 11(2), below.

### 3. The "later defect" defence, narrowed

Old law, Article 7(b) of 85/374/EEC: the producer is not liable if it proves
"that ... it is probable that the defect which caused the damage did not exist
at the time when the product was put into circulation by him or that this defect
came into being afterwards."

New law, Article 11(1)(c) of 2024/2853, substantially the same wording. Then:

> "**By way of derogation from paragraph 1, point (c)**, an economic operator
> shall not be exempted from liability where the defectiveness of a product is
> due to any of the following, **provided that it is within the manufacturer's
> control**:
> (a) a related service;
> (b) software, including software updates or upgrades;
> (c) **a lack of software updates or upgrades necessary to maintain safety**;
> (d) a substantial modification of the product."
> — Article 11(2)

Point (c) is the one that should be on your wall. Combined with Article 4(5)(b),
the chain runs:

```
You retain the ability to ship an update
   -> the product is within your control (Art. 4(5)(b))
   -> and the defect consists in the lack of an update
      necessary to maintain safety
   -> then "it happened after we shipped" is not available
      to you (Art. 11(2)(c))
```

**Now the limits, because this is where commentary overreaches.**

> "Such liability **should not apply where the supply or installation of such
> software is beyond the manufacturer's control**, for example where the owner
> of the product does not install an update or upgrade supplied for the purpose
> of ensuring or maintaining the level of safety of the product. **This
> Directive does not impose any obligation to provide updates or upgrades for a
> product.**"
> — Recital 51 (final two sentences)

Three honest points follow:

1. **There is no patching mandate in this directive.** Anyone telling you the
   PLD requires you to patch is overselling. (Other EU law may impose update
   obligations on you — the Cyber Resilience Act is the obvious candidate — but
   that is a different instrument with its own scope and dates, and it is
   outside this kit.)
2. **The trigger is a defect, not a missing patch.** Article 11(2)(c) bites
   where the *defectiveness* consists in the lack of updates *necessary to
   maintain safety*. An unpatched component that does not make the product less
   safe than the public at large is entitled to expect is not, by itself, a
   defect.
3. **If the user does not install what you supplied, that is expressly outside
   your control** (Recital 51). And Article 13(2) allows liability to be reduced
   or disallowed where the injured person's own fault contributed — Recital 55
   gives the example of an injured person who "negligently failed to install
   updates or upgrades provided by the economic operator".

So the defensible engineering position is not "patch everything forever". It is:
**be able to ship a security update for what you ship; actually ship them where
they are needed for safety; tell people clearly when you stop; and write down
what you decided and why.** That is exactly what File 03 builds.

One more asymmetry worth knowing, from Article 13(1): where damage is caused
**both** by your product's defectiveness **and** by a third party's act or
omission, your liability is **not** reduced. Recital 55 names the case
explicitly — "a third party exploiting a cybersecurity vulnerability of a
product". *Someone attacked us* is not a defence.

### 4. Disclosure and presumptions — the procedural squeeze

Under the old directive the claimant proved everything and had no route into
your internal records. Two new mechanisms change the dynamics.

**Disclosure (Article 9).** Where a claimant "has presented facts and evidence
sufficient to support the plausibility of the claim", the court requires the
defendant to disclose relevant evidence at its disposal. Guardrails: disclosure
is limited to what is "necessary and proportionate" (Art. 9(3)); courts weigh
confidentiality and **trade secrets** (Art. 9(4)) and can order specific
measures to protect them during and after proceedings (Art. 9(5)). It cuts both
ways — a defendant can seek disclosure from the claimant (Art. 9(2)).

Two details engineers should notice:

- Recital 42: disclosable evidence "includes documents that have to be **created
  ex novo by the defendant by compiling or classifying the available
  evidence**." You may be made to *assemble* a record, not merely hand over
  files that already exist.
- Article 9(6): the court can require evidence to be presented "in an easily
  accessible and easily understandable manner" where proportionate.

**Presumptions (Article 10).** Defectiveness is presumed where:

- **(2)(a)** the defendant **fails to disclose** relevant evidence under
  Art. 9(1) — the sanction for stonewalling is losing the point;
- **(2)(b)** the claimant shows the product does not comply with **mandatory
  product safety requirements** in Union or national law intended to protect
  against that risk;
- **(2)(c)** the claimant shows the damage was caused by an **obvious
  malfunction** in reasonably foreseeable use.

Causation is presumed where the product is established as defective and the
damage is "of a kind typically consistent with the defect in question"
(Art. 10(3)).

And the complexity valve (Art. 10(4)): the court **shall** presume defectiveness
or causation or both where, despite disclosure, the claimant faces **excessive
difficulties** proving them "in particular due to technical or scientific
complexity", **and** shows it is **likely** that the product is defective or
that causation exists. Recital 48 names machine learning and "a link that, in
order to be proven, would require the claimant to explain the inner workings of
an AI system" as examples, and says the claimant need not prove the difficulty,
only argue it.

All presumptions are **rebuttable** (Art. 10(5)). The defendant can contest
every element, including whether excessive difficulty exists.

**Engineering translation:** the quality of your records is now part of your
defence in a way it was not before. A team that can produce a clear, dated,
contemporaneous account of what it shipped, what it knew and what it decided is
in a materially different position from a team reconstructing it under a court
order two years later. That is not a legal opinion; it is a practical
observation about evidence. But it is the reason this kit exists.

### 5. Money and time — what you can be made to pay, and for how long

**The €500 property threshold is gone.** Article 9(b) of 85/374/EEC set a 500
ECU lower threshold for property damage. There is no equivalent in Article 6 of
the new directive. Small property claims are now in.

**Data loss is in.** Article 6(1)(c): "destruction or corruption of data that
are not used for professional purposes." Recital 20 explains — deleted digital
files, "including the cost of recovering or restoring those data".

The limits on that are important and often dropped in summaries:

- **Only non-professional data.** And the exclusion is wider than for property:
  data used for professional purposes "**even if not exclusively so**" is out
  (Recital 22). Mixed-use *property* is covered; mixed-use *data* is not.
- **No automatic loss.** "Destruction or corruption of data does not
  automatically result in a material loss if the victim is able to retrieve the
  data at no cost, such as where a back-up of the data exists or the data can be
  downloaded again" (Recital 20). A working restore path is a genuine mitigator.
- **Not a breach regime.** "Destruction or corruption of data is distinct from
  data leaks or breaches of data protection rules" (Recital 20). GDPR handles
  that; this does not.

**Psychological harm is expressly in** — "medically recognised damage to
psychological health" (Art. 6(1)(a)), meaning medically recognised and certified
harm affecting general health and possibly requiring treatment (Recital 21).

**Still out:** the defective product itself; property used exclusively for
professional purposes; and per Recital 24, pure economic loss, privacy
infringements and discrimination do not by themselves trigger liability here.

**No caps, no contracting out.** Article 15 forbids limiting or excluding
liability towards the injured person by contract **or by national law**. The old
Article 16 national ceiling option is gone. Your EULA's limitation of liability
clause does not touch a PLD claim.

**Time.** Limitation: 3 years from when the injured person knew or should have
known of damage, defectiveness and the liable operator's identity (Art. 16) —
unchanged in substance. Expiry: **10 years** from placing on the market or
putting into service (Art. 17(1)); **25 years** where personal injury was latent
and the claimant could not sue within 10 (Art. 17(2)); and for a **substantially
modified** product the 10 years runs afresh from when the modified product was
made available (Art. 17(1)(b)).

So a product placed on the market on 9 December 2026 carries a claim window
running to **9 December 2036**, and up to **9 December 2051** for latent personal
injury. Recital 58 confirms the sensible corollary: ordinary updates or upgrades
that do **not** amount to a substantial modification do **not** restart the
clock.

**Records implication:** whatever you keep as evidence of update supportability
needs a retention period measured in **years, not sprints**. See File 03.

---

## What did NOT change

Worth saying plainly, because the change is oversold in places:

- **Strict liability is not new.** 1985 was already no-fault. Recital 2 of the
  new directive repeats the 1985 rationale nearly word for word.
- **The claimant still bears the burden.** Article 10(1) keeps damage, defect
  and causation on the claimant. The presumptions are conditional and rebuttable,
  not a reversal. Recital 48 says so in terms — the aim is to maintain fair
  apportionment "while avoiding a reversal of the burden of proof".
- **Only natural persons can claim** (Art. 5(1)). This is not a business-to-
  business damages regime.
- **A better product later does not prove the earlier one was defective**
  (Art. 7(3)) — and expressly, that includes shipping updates or upgrades.
  Recital 35 confirms: "the supply of updates or upgrades for a product should
  not in itself lead to the conclusion that a previous version of the product is
  defective." **Patching is not an admission.** If anyone in your organisation
  argues against shipping a fix because it looks like an admission, this is the
  citation that answers them.
- **The development risk defence survives** (Art. 11(1)(e)) — no liability if
  the objective state of scientific and technical knowledge, at the time of
  placing on the market **or during the period the product was within the
  manufacturer's control**, was not such that the defectiveness could be
  discovered. Note the extension to the control period: for software you keep
  updating, the knowledge yardstick moves with you. Member States may derogate
  from this defence for specific product categories under Article 18.
  `[VERIFY: whether any Member State relevant to you has maintained or
  introduced an Art. 18 derogation from the development risk defence. Art. 18(1)
  required notification of maintained measures to the Commission by 9 December
  2026. Check the national transposition law in each Member State you sell into.]`
- **Compliance with legal requirements** remains a defence where compliance is
  what caused the defectiveness (Art. 11(1)(d)).
- **Component manufacturers keep their defence** where defectiveness is
  attributable to the design of the product they went into, or the integrator's
  instructions (Art. 11(1)(f)).

---

## What this means for your roadmap

Nothing here requires a compliance programme. It suggests five habits, all of
which are ordinary good engineering that now also happens to be evidence:

1. **Know what you ship.** A component inventory you can produce on demand.
2. **Know what can no longer be patched.** EOL tracking. This is the `pld-watch`
   question.
3. **Be able to ship a security update** for everything you support — and know
   which things you cannot.
4. **Say publicly what you support and until when.** A stated support window is
   how a reasonable expectation gets set, and Article 7(2)(a) puts the
   presentation of the product, including instructions for use and maintenance,
   into the defectiveness assessment.
5. **Write down decisions not to patch**, at the time, with reasons.

File 03 turns those five into a concrete afternoon of work.

---

*Toledo Technologies LLC. Not legal advice.*

*Sources: Directive (EU) 2024/2853 — https://eur-lex.europa.eu/eli/dir/2024/2853/oj ;
consolidated text incorporating Corrigendum 2026/90364 —
https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:02024L2853-20241118 ;
Council Directive 85/374/EEC —
https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:31985L0374*
