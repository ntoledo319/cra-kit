EU PRODUCT LIABILITY DIRECTIVE KIT
Directive (EU) 2024/2853 for software teams
Toledo Technologies LLC

WHAT THIS IS
------------
Six documents that help a software team work out whether the new EU Product
Liability Directive applies to them, what changed from the 1985 regime, and how
to keep a defensible record that they can and do supply security updates.

  00-START-HERE.md                     read this first
  01-AM-I-IN-SCOPE.md                  decision tree, incl. the FOSS carve-out
  02-WHAT-CHANGES-FROM-1985.md         before/after for engineering leaders
  03-UPDATE-SUPPORTABILITY-EVIDENCE.md the practical core
  04-SUPPORT-POLICY-TEMPLATES.md       copy-paste templates
  05-BOARD-BRIEF.md                    two pages for a board or an insurer

WHAT THIS IS NOT
----------------
This is not legal advice. It is not a certification, not a compliance
determination, and not an opinion on your specific product. Whether a product
is defective is decided by a court on the facts. Every document says so.

Where a legal question genuinely needs a lawyer, this kit says so rather than
guessing. There are 25 explicit [VERIFY: ...] markers throughout, each naming
what to check and where. That is deliberate. A confident wrong answer about
liability would be worse than no answer.

ON THE DATE
-----------
Article 2(1) as published in the Official Journal read "after 9 December 2026".
Corrigendum 2026/90364 (OJ L, 2026/90364, 7.5.2026) corrected this to
"after 8 December 2026":
  http://data.europa.eu/eli/dir/2024/2853/corrigendum/2026-05-07/oj

Articles 20, 21 and 22(1) still say 9 December 2026 -- those govern
transposition and the repeal of 85/374/EEC, not scope. Most published
commentary still says 9 December. Both dates appear in this kit, with the
sentence each one governs.

THE FREE TOOL
-------------
pld-watch finds runtimes and frameworks in a project that are past their
upstream end-of-life date, using the public endoflife.date catalogue:
  https://github.com/ntoledo319/pld-watch

It is MIT licensed, has no dependencies, and is genuinely free. It is one
input to the evidence practice in document 03 -- not proof of anything on its
own. A scanner cannot tell you whether a product is defective.

LICENCE
-------
See LICENCE.txt. Single-organisation licence unless you bought the
consultancy tier.

SUPPORT
-------
dev@toledotechnologies.com
