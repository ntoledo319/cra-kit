# 04 — Support policy templates

**Four copy-paste templates: a public security-update support policy, an
end-of-support notice, a component end-of-life register, and an internal record
for a decision not to patch.**

---

> **Not legal advice.** These are drafting starting points written by engineers,
> not lawyers. **Every template in this file must be reviewed by a qualified
> lawyer before you publish it or rely on it.** A published support commitment
> can create contractual and consumer-law obligations that have nothing to do
> with Directive (EU) 2024/2853, and those vary by Member State. Nothing here
> limits or excludes liability — Article 15 of the directive does not permit
> that — and nothing here is a certification or a compliance determination.

---

## How to use these

Fields to fill are marked `[LIKE THIS]`. Guidance notes are in `>` blockquotes
and **must be deleted before publication**. Every template ends with a review
block; fill it in, because an unreviewed, undated policy is weak evidence and an
unreviewed public commitment is a commercial risk.

Order of work: Template C (register) first, because it tells you what you can
honestly promise. Then Template A (policy). B and D as events require.

---

## Template A — Public security update support policy

> **Publish this on a stable, linkable URL.** Link it from your docs, your
> pricing page and your release notes. Keep every prior version in git — a
> policy you can prove the state of on a given date is worth considerably more
> than one you cannot.
>
> **Legal review is mandatory before publication.** This document makes public
> commitments.

```markdown
# Security Update Policy — [PRODUCT NAME]

Last reviewed: [YYYY-MM-DD]
Next scheduled review: [YYYY-MM-DD]
Version: [1.0]

## Scope

This policy covers:

- [PRODUCT NAME], versions [X.Y] and later
- [COMPONENT / SDK / AGENT NAME], versions [X.Y] and later

This policy does not cover:

- versions earlier than [X.Y], which are end-of-support (see the register at
  [URL])
- [BETA / PREVIEW / EXPERIMENTAL FEATURES], which are supplied without a
  security update commitment
- [THIRD-PARTY INTEGRATIONS / PLUGINS NOT BUILT BY US]
- [SELF-HOSTED DEPLOYMENTS MODIFIED BY THE CUSTOMER]

> Guidance, delete before publishing: be specific about modified deployments.
> If a customer substantially modifies your product and supplies it onward, they
> may be treated as a manufacturer of the modified product (Directive (EU)
> 2024/2853, Art. 8(2)). That is their position to manage, but your policy
> should be clear about what you are and are not maintaining.

## What we mean by a security update

A security update is a change we release to address a vulnerability that could
affect the security or safety of the product.

We assess reported and discovered vulnerabilities using [CVSS v3.1 / CVSS v4.0 /
OUR STATED SEVERITY SCHEME] and aim to release fixes on these timelines from
the point at which we confirm the issue:

| Severity | Target time to fix |
|---|---|
| Critical | [e.g. 7 days] |
| High | [e.g. 30 days] |
| Medium | [e.g. 90 days] |
| Low | [next scheduled release] |

These are targets, not guarantees. Where we cannot meet a target we will
[STATE WHAT YOU DO — e.g. publish an advisory describing the issue and any
available mitigation].

> Guidance, delete before publishing: publish targets you actually hit. A missed
> published target is a documented gap between what you said and what you did.
> If you do not measure your current times to fix, measure for a quarter before
> you publish a number.

## Support window

| Version | Released | Security updates until | Status |
|---|---|---|---|
| [3.x] | [YYYY-MM-DD] | [YYYY-MM-DD] | Supported |
| [2.x] | [YYYY-MM-DD] | [YYYY-MM-DD] | Security updates only |
| [1.x] | [YYYY-MM-DD] | [YYYY-MM-DD] | End of support |

Our general rule: we provide security updates for [a major version for N months
after the release of its successor / the current and one previous major version
/ N years from a version's release date].

[FOR SAAS:] This service is operated as a single continuously updated version.
Security updates are applied by us to the running service. We do not maintain
older versions. Where a change requires action from you, we will tell you
[HOW AND HOW FAR IN ADVANCE].

> Guidance, delete before publishing: pick ONE rule and make sure the table
> matches it. A rule that contradicts your own table is the first thing anybody
> reviewing this will notice.

## End-of-support notice

We will announce the end of security updates for a version at least
[N months — commonly 6 or 12] in advance, via:

- [our release notes at URL]
- [email to account administrators]
- [an in-product notice]
- [the end-of-life register at URL]

## After end of support

After the date listed above, we do not issue security updates for that version.
Continuing to run an unsupported version means known vulnerabilities in it will
not be fixed by us. We recommend upgrading to a supported version before the
end-of-support date.

## Third-party components

[PRODUCT NAME] includes third-party and open-source components. Where an
upstream project releases a security fix for a component we ship, we assess it
and, where it affects our product, include it in a release on the timelines
above.

Where a component we ship has reached its own upstream end of life and no
upstream fix is available, we [STATE WHAT YOU ACTUALLY DO — e.g. plan a
migration to a supported component, or maintain our own patched build, or
document the position in the register at URL].

> Guidance, delete before publishing: only state what you actually do. "We
> maintain our own patched build" is a serious, ongoing commitment. Do not write
> it unless someone owns it.

## Component inventory

[We publish a software bill of materials (SBOM) for each release at URL.]
[An SBOM for a given release is available to customers on request at EMAIL.]

## Reporting a security issue

Report vulnerabilities to [security@EXAMPLE.COM] [or via our advisory process at
URL]. We aim to acknowledge within [N business days].
[Our PGP key / security.txt is at URL.]

## Changes to this policy

We may update this policy. Material changes affecting an existing support window
will be announced through the channels listed above. Previous versions are
available at [URL / in our public repository].

---

This policy describes our operational practice for security updates. It is not a
warranty and does not limit or exclude any rights you have under applicable law.
```

**Review block — complete before publishing:**

```
Template A review
Drafted by: ______________________  Date: ____________
Support window verified achievable against:
  [ ] longest current enterprise contract commitment
  [ ] upstream EOL of our own runtime/platform
  [ ] our actual historical maintenance cadence
Severity timelines verified against measured data:  [ ] Y  [ ] N
Legal review by: __________________  Date: ____________
Approved for publication by: ______  Date: ____________
Published at URL: _______________________________________
```

---

## Template B — End-of-support notice

> Send this at least the notice period stated in your policy. **Archive a dated
> copy** — a git commit of the notice, the sent email with headers, the release
> tag of the in-product banner. A page that can change silently is weak evidence
> of what you told people and when.

```markdown
# End of security updates for [PRODUCT NAME] [VERSION]

Published: [YYYY-MM-DD]

## What is happening

Security updates for [PRODUCT NAME] [VERSION] end on **[YYYY-MM-DD]**.

## What that means

After [YYYY-MM-DD] we will not release security updates for [VERSION]. If a
vulnerability is found in [VERSION] after that date, we will not fix it in
[VERSION].

[The version will continue to run / will stop functioning on DATE / will no
longer connect to our service from DATE.]

> Guidance, delete before publishing: state plainly whether the software keeps
> working. Users conflate "end of support" with "stops working". Ambiguity here
> is the single most common cause of an unsafe deployment continuing in the
> field.

## What you should do

Upgrade to [VERSION] or later before [YYYY-MM-DD].

- Upgrade guide: [URL]
- Breaking changes: [URL]
- [Migration tooling: URL]

If you cannot upgrade by that date, contact [EMAIL] before [YYYY-MM-DD] so we
can discuss your options.

## Why we are doing this

[STATE THE REAL REASON — e.g. "Version 2.x runs on Node.js 16, which reached its
upstream end of life on 2023-09-11 and no longer receives security updates from
the Node.js project. We cannot supply security updates for the underlying
runtime."]

> Guidance, delete before publishing: give the real reason, with the real
> upstream date. It is more persuasive to users, and it is a more useful record.

## Risk of continuing to run [VERSION]

Running [VERSION] after [YYYY-MM-DD] means any vulnerability discovered in it
will not be patched by us. [STATE ANY SPECIFIC KNOWN RISK.] We do not recommend
running [VERSION] after that date.

## Questions

[EMAIL] · [SUPPORT URL]
```

**Archive record — keep with the notice:**

```
Template B despatch record
Version ending support: __________  End date: ____________
Notice published:    [ ] release notes  URL: ______________  date: ________
                     [ ] email to admins  recipients: ______  date: ________
                     [ ] in-product notice  release tag: ____  date: ________
                     [ ] EOL register updated                  date: ________
Notice period given: ______ months (policy requires ______)
Customers unreachable / no contact channel: ______________________
  Channels attempted for those: __________________________________
Immutable copy archived at: _____________________________________
Recorded by: ______________  Date: ____________
```

---

## Template C — Component end-of-life register

> Internal. One row per component that is past, or approaching, upstream end of
> life. `pld-watch --json` populates the first six columns; the rest is human
> judgement that no tool can supply.
>
> Review quarterly. Keep every historical version — the trend over time is
> itself the record.

```markdown
# Component End-of-Life Register — [PRODUCT NAME]

Owner: [TEAM / NAME]
Last reviewed: [YYYY-MM-DD]      Next review: [YYYY-MM-DD]
Inputs: pld-watch scan [YYYY-MM-DD] · SBOM [BUILD ID] · [SCA TOOL] [DATE]
        · manual review [YYYY-MM-DD]

Coverage note: this register covers [WHAT — e.g. declared runtimes and
frameworks, direct dependencies, base image packages]. It does NOT currently
cover [WHAT — e.g. transitive dependencies beyond depth 1, vendored code
in /third_party]. Known gaps are listed at the end.

| # | Component | Version | Source | Upstream EOL | Status | Reachable in product? | Decision | Target date | Owner | Decision record |
|---|---|---|---|---|---|---|---|---|---|---|
| 1 | Node.js | 16.20 | .nvmrc | 2023-09-11 | EOL | Yes - runtime | Upgrade to 22 LTS | 2026-11-30 | platform | - |
| 2 | next | 12.3 | package.json | 2022-11-21 | EOL | Yes - web tier | Upgrade to 15 | 2027-01-31 | web | - |
| 3 | libfoo | 1.2.0 | vendored | unknown (archived) | Unknown | No - build-time only | Accept | review 2027-03 | build | DNU-2026-004 |
| 4 | [COMPONENT] | [VER] | [FILE] | [DATE] | [EOL/soon/unknown] | [Y/N + why] | [Upgrade/Mitigate/Accept] | [DATE] | [TEAM] | [DNU-ID or -] |

## Status values

- **EOL** — past upstream end-of-life date. No upstream security fix is available.
- **Soon** — upstream EOL within 180 days.
- **Unknown** — could not be matched to a catalogue entry. **Treat as not
  checked, not as supported.** Every Unknown needs a manual determination.

## Decision values

- **Upgrade** — migrating off it. Needs a target date and a named owner.
- **Mitigate** — staying on it with a compensating control. Name the control.
- **Accept** — staying on it as-is. **Requires a decision record (Template D).**

## Reachability

State how you determined it, not just the answer. "No - build-time only, not in
the shipped artefact" is a record. "No" alone is not.

## Known gaps in this register

- [e.g. Transitive npm dependencies are not individually EOL-tracked.]
- [e.g. Base image OS packages are tracked only at image level, not per package.]
- [e.g. Component X's upstream publishes no EOL dates.]

> Guidance, delete before circulating: keep this gaps section honest and
> current. A register that silently overstates its coverage is worse than one
> that states its limits.

## Change log

| Date | Change | By |
|---|---|---|
| [YYYY-MM-DD] | [Added rows 3-4 from pld-watch scan] | [NAME] |
```

---

## Template D — Internal record: decision not to update

> Internal, retained. One per decision. Write it at the time of the decision,
> not afterwards.
>
> **Read this first:** discuss with your lawyer, before you accumulate these,
> whether records of this kind should be created under legal privilege in your
> jurisdiction, and how. Privilege is a matter of national law and varies widely
> across Member States. See the `[VERIFY]` note in File 03.

```markdown
# Decision not to update — [DNU-YYYY-NNN]

Date of decision: [YYYY-MM-DD]
Product / version affected: [PRODUCT] [VERSIONS]
Component: [NAME] [EXACT VERSION]
Decided by: [NAME, ROLE]
Reviewed by: [NAME, ROLE]
Next review date: [YYYY-MM-DD]

## 1. What the component is

[What it is, what it does in our product, how it got here — direct dependency,
transitive, vendored, part of a base image.]

## 2. What the issue is

[ ] Component is past upstream end of life — EOL date [YYYY-MM-DD], source
    [endoflife.date / vendor page URL]
[ ] Known vulnerability — [CVE-XXXX-NNNNN], CVSS [SCORE], [LINK]
[ ] Upstream is unmaintained / archived — [EVIDENCE, URL, DATE CHECKED]
[ ] Other: [DESCRIBE]

[Plain description of the risk if it were exploited.]

## 3. Is it reachable in our product?

Reachable: [ ] Yes  [ ] No  [ ] Partially  [ ] Could not determine

How we determined this:
[e.g. "Call graph analysis shows the affected parser is only invoked by the
CLI import path, which is not present in the shipped server artefact.
Verified by NAME on DATE against build BUILD-ID."]

> Guidance: "could not determine" is an acceptable and honest answer. It should
> normally push the decision toward Mitigate or Upgrade rather than Accept.

## 4. What updating would involve

[Concretely: what has to change, estimated effort, what would break, why it is
not trivial. If no upstream fix exists, say so — that is the whole answer to
this section.]

## 5. Why we are not updating

[ ] No upstream fix exists and none is expected
[ ] Not reachable in our product (see 3)
[ ] The upgrade carries a higher assessed risk than the issue
[ ] Blocked by [DEPENDENCY / CUSTOMER / CONTRACT / PLATFORM CONSTRAINT]
[ ] Engineering capacity — scheduled for [WHEN]
[ ] Other: [DESCRIBE]

[Reasoning in plain terms.]

> Guidance: write the real reason. "Engineering capacity, scheduled for Q2" is a
> normal business fact and a perfectly respectable entry. A record that
> minimises a risk you actually understood is far worse than no record at all.
> Do not speculate in this document about legal consequences or liability —
> state facts and engineering reasoning only.

## 6. What we are doing instead

[ ] Compensating control: [DESCRIBE — WAF rule, network isolation, input
    validation, feature disabled, config hardening]
[ ] Monitoring: [WHAT WE WATCH AND WHERE IT ALERTS]
[ ] Documented for customers: [WHERE]
[ ] Nothing — accepted as-is

[Detail. Name the specific control, not the category.]

## 7. What would change this decision

[e.g. "An upstream fix being released"; "the component becoming reachable from
the network tier"; "a public exploit appearing"; "the planned v4 refactor
removing this dependency".]

## 8. Evidence attached

- [ ] pld-watch scan JSON: [FILENAME / ARTEFACT ID], generated [DATE]
- [ ] SBOM for affected release: [BUILD ID]
- [ ] Vendor / upstream EOL page: [URL], checked [DATE]
- [ ] Vulnerability advisory: [URL]
- [ ] Reachability analysis: [LINK / TICKET]
- [ ] Ticket: [ID]

## 9. Review

| Date | Reviewer | Outcome |
|---|---|---|
| [YYYY-MM-DD] | [NAME] | [Decision stands / changed to X / escalated] |

Retention: keep for at least 10 years from the date the affected version was
placed on the market (Directive (EU) 2024/2853, Art. 17(1)), and see File 03 on
the 25-year latent personal injury case.
```

---

## Bonus — Supplier identification record (distributors and resellers)

> Only relevant if you distribute or resell other people's software into the EU.
> Under Article 8(3), a distributor becomes liable where an injured person asks
> it to identify an EU-established economic operator (or its own supplier) and it
> **fails to do so within one month**. This register is how you answer inside a
> month without a fire drill.

```markdown
# Supplier identification register

Last reviewed: [YYYY-MM-DD]

| Product we distribute | Manufacturer (legal name) | Established in EU? | EU-established operator (importer / auth. rep.) | Their registered address | Contact | Our supplier (if not the manufacturer) | Verified |
|---|---|---|---|---|---|---|---|
| [PRODUCT] | [LEGAL ENTITY] | [Y/N] | [ENTITY NAME] | [ADDRESS] | [EMAIL] | [ENTITY] | [DATE] |

Escalation: a request under Art. 8(3) must be answered within one month.
Route to: [NAME / ROLE], backup [NAME / ROLE].

Verify entries [annually / on contract renewal]. An out-of-date register does
not help you inside a one-month window.
```

---

## Before any of this goes out

```
Pre-publication checklist
[ ] All [PLACEHOLDERS] filled
[ ] All "> Guidance" blockquotes deleted from public documents
[ ] Support window verified achievable, not aspirational
[ ] Severity timelines match measured reality
[ ] Version table matches the stated support rule
[ ] URLs resolve
[ ] Reviewed by a qualified lawyer in [JURISDICTION]   date: ________
[ ] Owner assigned for the next review                 date: ________
[ ] Archived immutably (git commit / signed artefact)
```

---

*Toledo Technologies LLC. Not legal advice. These templates must be reviewed by
a qualified lawyer before publication or reliance. Source: Directive (EU)
2024/2853 — https://eur-lex.europa.eu/eli/dir/2024/2853/oj*
