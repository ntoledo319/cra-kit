# 00 — Start here

**EU Product Liability Directive (EU) 2024/2853 — Update Supportability Kit**

Companion to the free `pld-watch` tool — https://github.com/ntoledo319/pld-watch

Kit version 1.0. Written against the directive text as published in the Official
Journal on 18 November 2024 and as corrected by Corrigendum 2026/90364 of
7 May 2026. Last checked against EUR-Lex: 14 September 2026.

---

> **Not legal advice.** This kit is engineering and governance material written
> from the primary text of Directive (EU) 2024/2853. It is not legal advice, it
> is not a certification, and it is not a compliance determination. Nothing here
> tells you whether you are in scope, whether your product is defective, or
> whether you are liable. Those are decided by a court on the facts, under the
> national law that transposes the directive. Take advice from a qualified
> lawyer in the relevant Member State before relying on anything in this kit.

---

## What this kit is

Six documents that help a software team do one specific, bounded piece of work:

**Build and keep a defensible record that you can, and do, supply security
updates for the software you ship — and that when you decide not to, you decide
it deliberately and write it down.**

That is not the whole of the directive. It is the part that changed most for
software teams, the part that is squarely inside engineering's control, and the
part that is cheap to do now and expensive to reconstruct later.

## Why that particular piece of work

Under the new directive, a manufacturer can normally escape liability by proving
the defect did not exist when the product was placed on the market, or came into
being afterwards (Article 11(1)(c)). That defence is switched off in four
situations where the thing is within the manufacturer's control — and one of
them is:

> "a lack of software updates or upgrades necessary to maintain safety"
> — Article 11(2)(c)

And a product is treated as remaining within your control simply because you
**have the ability** to supply software updates, yourself or via a third party
(Article 4(5)(b)).

So the old instinct — *we shipped it clean, whatever happened later is not on
us* — no longer works the same way for software you can still update.

**Read this next, because it is the honest other half:** the directive says in
terms that it "does not impose any obligation to provide updates or upgrades for
a product" (Recital 51). There is no patching mandate here. What there is, is a
liability consequence attached to a *defect that consists in* the absence of a
safety-necessary update, where you had control. Those are different things, and
a kit that blurs them would be selling you a fear that the text does not
support.

## Who this is for

- Engineering leaders and CTOs at companies shipping software, SaaS, firmware or
  AI systems that reach users in the EU.
- Technical founders who need to answer an investor, insurer or enterprise
  customer question about PLD readiness.
- Product and platform teams who own release, support and deprecation policy.

It assumes you can read a `package.json`, run a CLI, and write a policy page. It
does not assume any legal background.

## Who this is NOT for

- Anyone looking for a compliance certificate, a badge, or a statement that they
  are "PLD compliant". No such thing exists. The directive creates no
  certification scheme, no notified bodies, no registration, and no regulator
  that approves you. There is nothing to be certified against.
- Anyone who needs a scope determination. Whether *your* product is in scope is
  a legal question about your facts. File 01 helps you frame it. It cannot
  answer it.
- Medical device, automotive, aviation or other regulated-sector teams looking
  for sector guidance. Those sectors carry their own safety law, and the
  interaction is beyond this kit.

## What is NOT in this kit, deliberately

- **Member State transposition detail.** The directive had to be transposed into
  national law by 9 December 2026 (Article 22(1)). Transposition varies, and
  some things — standard of proof, disclosure procedure, non-material damages,
  whether a state dropped the development-risk defence under Article 18 — are
  set nationally. We do not guess at any of it. Where it matters, you will see a
  `[VERIFY: ...]` marker.
- **Any prediction of outcomes.** No claim here that doing this work makes you
  safe, wins a case, or reduces a premium.
- **Contract drafting.** Supplier terms, indemnities and the Article 12(2)
  recourse waiver are lawyer work.

## How to use this in an afternoon

Roughly three to four hours for one product, with one engineer and one person
who can make policy decisions.

| Step | Time | File | Output |
|---|---|---|---|
| 1. Work out whether the directive plausibly reaches you | 30 min | `01-AM-I-IN-SCOPE.md` | A filled-in scope card and a written list of the questions you need a lawyer for |
| 2. Brief yourself on what actually changed | 30 min | `02-WHAT-CHANGES-FROM-1985.md` | Enough context to explain it to your team without overstating it |
| 3. Run `pld-watch scan --json` and start the evidence file | 60 min | `03-UPDATE-SUPPORTABILITY-EVIDENCE.md` | A component inventory with EOL status, dated and stored |
| 4. Draft the support policy and the EOL register | 60 min | `04-SUPPORT-POLICY-TEMPLATES.md` | Draft policy, draft register, ready to go to legal review |
| 5. Write the board note | 20 min | `05-BOARD-BRIEF.md` | A two-page brief for a board, investor or insurer |

If you only have one hour: do step 3. A dated, honest component inventory is the
single artefact that is hardest to recreate after the fact and easiest to build
today.

## What the free `pld-watch` tool does — stated honestly

`pld-watch` answers one narrow question:

> Of the runtimes and frameworks this project *declares*, which ones are past
> their upstream end-of-life date?

It reads `.nvmrc`, `.python-version`, `go.mod`, `package.json` (the `engines`
block plus a built-in map of known frameworks), `requirements.txt` /
`requirements-dev.txt`, and `FROM` lines in a `Dockerfile`. It checks each
version it finds against the public **endoflife.date** catalogue and prints the
ones that are past EOL, near EOL, supported, or unknown. `--json` gives you the
same result in a machine-readable form for CI. Exit code `1` means at least one
component is past EOL, `0` means none are, `2` means it found nothing to check.

That matters because an end-of-life component cannot receive an upstream
security update at all. If a safety-relevant vulnerability lands in it, there is
no patch to ship. That is a fact worth knowing deliberately rather than
discovering during an incident.

### What `pld-watch` does not do, and cannot do

- It does **not** tell you whether you are in scope of the directive.
- It does **not** tell you whether your product is defective. Defectiveness is
  decided by a court on all the circumstances (Article 7). No scanner decides it.
- It does **not** tell you whether you are liable.
- It does **not** check for known vulnerabilities. It is not an SCA or CVE
  scanner. A supported version can still be vulnerable; an EOL version may have
  no known exploit. Different question entirely.
- It does **not** assess reachability or exploitability. An EOL library that is
  never loaded at runtime is a different risk from one in your auth path, and
  `pld-watch` cannot tell them apart.
- It does **not** read your own source code, compiled binaries, container image
  layers, lockfile transitive dependencies, or anything outside the files listed
  above. Transitive dependency trees are a real gap.
- It only knows the frameworks in its internal map, so it will silently miss
  things it does not recognise. Components it cannot match come back as
  `"status": "unknown"` — treat that as *not checked*, not as *fine*.
- Its data comes from endoflife.date, a community-maintained public catalogue.
  It is useful and widely used. It is not an authoritative legal or vendor
  source, and it can be wrong or out of date. For anything load-bearing, confirm
  against the upstream vendor's own lifecycle page.

**In this kit, `pld-watch` output is treated as one dated input to a record you
maintain — never as a conclusion.** File 03 shows exactly how to file it.

## Primary sources used

Every legal statement in this kit cites one of these. If a statement has no
citation, treat it as our engineering opinion, not as law.

- **Directive (EU) 2024/2853** — full text, EUR-Lex:
  https://eur-lex.europa.eu/eli/dir/2024/2853/oj
- **Consolidated text** (incorporates the corrigendum), EUR-Lex:
  https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:02024L2853-20241118
- **Corrigendum 2026/90364** of 7 May 2026 (amends Article 2(1)), EUR-Lex:
  https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=OJ:L_202690364
- **Council Directive 85/374/EEC** (the repealed 1985 directive), EUR-Lex:
  https://eur-lex.europa.eu/legal-content/EN/TXT/HTML/?uri=CELEX:31985L0374

Citations in this kit are to **Article** numbers (binding operative text) and
**Recital** numbers (numbered paragraphs in the preamble). Recitals are not
themselves binding rules, but courts use them to interpret the articles, and for
software teams they contain most of the worked examples. Where we rely on a
recital we say so.

## A note on the date, because it moved

You will see both **8 December 2026** and **9 December 2026** in circulation.
Both are correct, for different sentences. File 01 explains it precisely. The
practical answer for planning is unchanged: **products placed on the EU market
from 9 December 2026 onward fall under the new directive.**

## Files in this kit

| File | What it gives you |
|---|---|
| `00-START-HERE.md` | This file. Orientation and limits. |
| `01-AM-I-IN-SCOPE.md` | A decision tree to frame whether the directive plausibly reaches you. |
| `02-WHAT-CHANGES-FROM-1985.md` | Old directive vs new, for engineering and product leaders. |
| `03-UPDATE-SUPPORTABILITY-EVIDENCE.md` | The practical core: how to build the record. |
| `04-SUPPORT-POLICY-TEMPLATES.md` | Four copy-paste templates. |
| `05-BOARD-BRIEF.md` | Two-page brief for a board or insurer. |

## How to keep this current

The text of the directive is stable. What will change is national transposition
and, from 2027 onward, case law. Two things are worth a calendar reminder:

- **National transposition law** for each Member State you sell into. Set a
  review for the first quarter after you start selling there.
- **The Commission judgment database.** Article 19 requires Member States to
  publish final appellate and highest-instance judgments under this directive,
  and requires the Commission to set up and maintain a publicly available
  database of them. Early judgments are where the practical meaning of
  "necessary to maintain safety" will be settled.
  `[VERIFY: the live URL of the Commission's Article 19 judgment database. As of
  14 September 2026 we could not confirm that it is published and reachable.
  Check the European Commission's product liability pages on europa.eu.]`

---

*Toledo Technologies LLC. Provided as-is, without warranty. Not legal advice.*
