# 03 — Update supportability evidence

**How to build and keep a defensible record that you can, and do, supply
security updates for what you ship.**

---

> **Not legal advice.** This file describes an engineering and record-keeping
> practice. It is not legal advice, not a certification, and not a compliance
> determination. Following it does not make you compliant, does not make your
> product safe, and does not determine whether you are liable. It is designed to
> make a record that exists, is dated, and is honest — nothing more, and nothing
> less. Have your legal adviser review anything you publish, and review your
> retention periods against the liability periods before you set them.

---

## What this is for, in one paragraph

Under Article 11(2)(c), you cannot escape liability by saying the defect arose
after you shipped, where the defectiveness is due to **"a lack of software
updates or upgrades necessary to maintain safety"** and the product is within
your control. Under Article 4(5)(b), the product is within your control simply
because you **have the ability** to supply updates. So the useful engineering
question is not "are we compliant" — there is nothing to comply with. It is:

> **For everything we ship: can we supply a security update for it? Do we? And
> when we decided not to, did we decide it, or did it just happen?**

A record that answers those three questions is worth building. Not because it
wins a case — nobody can promise you that — but because the alternative is
reconstructing it from Slack two years later, possibly under an Article 9
disclosure order.

## Why the record, specifically

Three provisions make contemporaneous records matter more than they used to:

- **Article 9** — a court can order you to disclose relevant evidence, and per
  Recital 42 that includes "documents that have to be created **ex novo** by the
  defendant by compiling or classifying the available evidence." You may be
  ordered to *assemble* the picture. Assembling it now is cheaper.
- **Article 10(2)(a)** — if you fail to disclose when ordered, **defectiveness
  is presumed**. Being unable to produce records is not a neutral position.
- **Article 7(2)** — the defectiveness assessment weighs "all circumstances",
  including presentation and "instructions for its assembly, installation, use
  and **maintenance**" (7(2)(a)), "relevant product safety requirements,
  including **safety-relevant cybersecurity requirements**" (7(2)(f)), and the
  moment the product left your control (7(2)(e)). Your stated support position
  is part of the factual matrix.

**What a record cannot do.** It cannot make a defective product non-defective.
It cannot prove you were not negligent — negligence is not the test; liability
is no-fault. It cannot substitute for actually shipping the update. Be clear-eyed
about this: you are building a factual record, not a shield.

---

## The five artefacts

| # | Artefact | Answers | Effort to start | Where it lives |
|---|---|---|---|---|
| 1 | **Component inventory** | What is actually in what we ship? | 1-2 h | Repo, versioned |
| 2 | **EOL register** | What can no longer receive an upstream security fix? | 1 h | Repo, versioned |
| 3 | **Update policy with support windows** | What do we tell people we support, and until when? | 2-3 h + legal | Public page |
| 4 | **End-of-support notices** | Did we tell people when we stopped? | 30 min each | Public + archived |
| 5 | **Decision-not-to-update records** | Where we did not patch, why? | 15 min each | Internal, retained |

Templates for 3, 4, 5 and a register format for 2 are in `04-SUPPORT-POLICY-TEMPLATES.md`.

Start at 1 and 2. They are the ones only you can build, and the ones that decay
fastest if you leave them.

---

## Artefact 1 — Component inventory

### What good looks like

For each released, supported version of each product, a list of the components
it contains, with: name, version, where it came from, licence, whether it is
upstream-supported, and who on your side owns it.

If you already produce an **SBOM** (CycloneDX or SPDX) in CI, you are most of
the way there. An SBOM is the right primitive — it is machine-readable, it is
generated rather than typed, and it can be attached to a release artefact so it
is genuinely contemporaneous.

`[VERIFY: whether SBOM generation is mandatory for you under other EU law —
notably the Cyber Resilience Act, Regulation (EU) 2024/2847 — and on what
timeline. Directive (EU) 2024/2853 itself imposes no SBOM requirement. We
deliberately do not state CRA obligations or dates in this kit because CRA scope
and timing are outside what we verified here. Check the CRA text on EUR-Lex and
take advice.]`

### Minimum viable version

If you cannot produce an SBOM today, do not let that stop you. A dated CSV per
released version beats nothing, and beats an SBOM you keep meaning to set up.

```
component,version,source,type,licence,upstream_supported,eol_date,owner,notes
node,16.20.0,.nvmrc,runtime,MIT,no,2023-09-11,platform-team,pinned for native addon compat
next,12.3.1,package.json,framework,MIT,no,2022-11-21,web-team,upgrade planned Q1
openssl,3.0.13,Dockerfile base,library,Apache-2.0,yes,,platform-team,
libfoo,1.2.0,vendored source,library,BSD-3,unknown,,integrations,vendored 2023, upstream archived
```

### Rules that make this hold up

1. **Per released version, not per repo HEAD.** The question a claim asks is
   "what was in the thing the customer had", not "what is on main today".
2. **Generate it at build time and attach it to the release.** A generated,
   timestamped artefact is contemporaneous evidence. A spreadsheet someone typed
   last week is not.
3. **Record vendored and copied code.** Vendored dependencies, forked libraries
   and copy-pasted snippets do not appear in any manifest and are exactly where
   unmaintained code hides.
4. **Record what you could not determine.** An explicit `unknown` is honest and
   useful. A silent gap looks, later, like a record that was curated.
5. **Keep it for the liability period.** See the retention section below.

### The gap you must not paper over

A manifest-derived inventory covers **declared direct dependencies**. It does not
by itself cover the **transitive dependency tree**, OS packages in your base
image, binaries you ship, or code you vendored years ago. If your inventory is
manifest-derived, write that limitation *into the inventory*. A record that
overstates its own coverage is worse than one that states its limits, because
somebody will eventually check.

---

## Artefact 2 — EOL register, and where `pld-watch` fits

### The narrow question the tool answers

`pld-watch scan` reads the runtimes and frameworks a project **declares** and
checks each version against the public **endoflife.date** catalogue. Files it
reads: `.nvmrc`, `.python-version`, `go.mod`, `package.json` (`engines` plus a
built-in map of known frameworks), `requirements.txt` / `requirements-dev.txt`,
and `FROM` lines in a `Dockerfile`.

That is one checkable fact: **is this declared version past its upstream EOL
date?** It matters because past EOL means *no upstream security fix is coming*.
If a safety-relevant vulnerability appears in it, you cannot ship a patch for it
without first migrating off it. That is a real constraint on your ability to
maintain safety, and Article 4(5)(b) frames control in exactly those terms — the
ability to supply updates.

### Running it

```bash
curl -fsSL https://raw.githubusercontent.com/ntoledo319/pld-watch/main/pld_watch.py -o pld-watch
chmod +x pld-watch

./pld-watch scan                    # human-readable
./pld-watch scan --json             # machine-readable, for CI and for the record
./pld-watch scan /path/to/project
./pld-watch clock                   # days until the directive applies
```

Exit codes: `0` nothing past EOL · `1` at least one component past EOL ·
`2` nothing detectable to check.

Note `2` carefully. **"Nothing detectable" is not "nothing wrong".** It means the
tool found no files it understands. Treat exit code `2` as *unscanned*.

### The `--json` output, and what each field is worth

A real run against a small project with a pinned old Node and an old Next.js:

```json
{
  "tool": "pld-watch",
  "version": "1.0.0",
  "scanned": "/tmp/pldtest",
  "pld_applies": "2026-12-09",
  "generated_utc": "2026-09-14T20:08:29+00:00",
  "components": [
    {
      "kind": "runtime",
      "name": "Node.js",
      "slug": "nodejs",
      "version": "16.20",
      "source": ".nvmrc",
      "status": "eol",
      "eol_date": "2023-09-11",
      "latest": "26"
    },
    {
      "kind": "framework",
      "name": "next",
      "slug": "nextjs",
      "version": "12.3",
      "source": "package.json",
      "status": "eol",
      "eol_date": "2022-11-21",
      "latest": "16"
    }
  ],
  "eol_count": 2,
  "disclaimer": "Engineering tooling, not legal advice."
}
```

Field by field, and what it is actually evidence of:

| Field | Meaning | What it is evidence of |
|---|---|---|
| `generated_utc` | When the scan ran | **The most useful field for your record.** It dates the check |
| `scanned` | Path scanned | What was, and was not, in the scan |
| `components[].source` | The file the version came from | Traceability — you can re-derive the finding |
| `components[].status` | `eol`, `soon`, `supported`, `unknown` | See below. `unknown` is not `supported` |
| `components[].eol_date` | Upstream EOL date from endoflife.date | The underlying fact, checkable against the vendor |
| `components[].latest` | Latest non-EOL release known | Where a migration would go |
| `days_to_eol` | Present on non-EOL matches | Lead time for planning |
| `eol_count` | Count of `eol` entries | A trend line if you keep scans over time |

`status` values, precisely as the tool computes them: `eol` if the matched
release is flagged end-of-life upstream or its EOL date has passed; `soon` if EOL
is within 180 days; `supported` if EOL is further out or none is published;
`unknown` if the component or version could not be matched at all.

**`unknown` means not checked.** It is the single most misread field. Record
`unknown` entries in your register as open items, not as clean ones.

### How to file it — the practice

Run it in CI on every release build and **store the JSON as a release artefact**,
next to the SBOM. That gives you, per version shipped, a dated machine-readable
statement of what was past EOL at the moment of shipping. That is the artefact
that is impossible to recreate later.

```yaml
# Example CI step. Adapt to your platform.
# Deliberately does not fail the build: an EOL finding is
# information to be triaged, not an automatic release blocker.
- name: pld-watch EOL scan
  run: |
    curl -fsSL https://raw.githubusercontent.com/ntoledo319/pld-watch/main/pld_watch.py -o pld-watch
    chmod +x pld-watch
    ./pld-watch scan --json > "pld-watch-${GITHUB_SHA}.json" || true
    cat "pld-watch-${GITHUB_SHA}.json"
- name: Archive scan
  uses: actions/upload-artifact@v4
  with:
    name: pld-watch-scan
    path: pld-watch-*.json
    retention-days: 90     # then move to long-term storage; see retention below
```

A deliberate choice worth explaining: **do not fail the build on exit code 1.**
An EOL component is a fact to be triaged and recorded, not a defect. Gating
releases on it trains people to suppress the signal, and a suppressed signal is
worse than no signal — including as evidence.

### What a scan proves, and what it does not

Be precise about this, especially in anything you show a board, a customer or an
insurer.

**A `pld-watch` scan is evidence that:** on a stated date, a stated set of
declared components was checked against a public EOL catalogue, and these were
past EOL.

**A `pld-watch` scan is NOT evidence that:**

- your product is safe, or not defective — Article 7 decides defectiveness on
  all the circumstances, and no scanner applies that test;
- you are, or are not, in scope;
- you have no vulnerabilities — **it is not a CVE or SCA scanner**, it does not
  look at known vulnerabilities at all;
- your dependency tree is clean — it reads declared direct versions, not the
  transitive graph, not lockfiles, not OS packages, not container image layers,
  not your own source;
- an EOL component is reachable or exploitable in your system. An EOL parser
  never invoked at runtime and an EOL TLS library in your auth path both appear
  as one line of output. They are not the same risk and the tool cannot tell them
  apart. **That judgement is yours and it belongs in your register.**

**And on the data source:** endoflife.date is a community-maintained public
catalogue. It is widely used and generally good. It is not authoritative, not a
vendor source, and not a legal source. For any component where the EOL status is
load-bearing in a decision you record, confirm against the vendor's own
lifecycle page and cite that in your register.

### Use `pld-watch` as one input among several

A defensible EOL register draws on more than one tool. `pld-watch` answers
"past upstream EOL". You will also want, at minimum:

- an **SCA / vulnerability scanner** for known CVEs (different question);
- **SBOM generation** for the full component graph including transitives;
- **base image lifecycle** tracking for your containers;
- **vendor lifecycle pages** for commercial dependencies.

Nothing in this kit suggests `pld-watch` replaces any of those. It covers one
narrow fact that the others often do not surface plainly: *this can no longer be
patched at all.*

### The register itself

The JSON is an input. The register is the human layer where judgement is recorded
— reachability, decision, owner, date. The tool cannot produce those. Format and
a filled example are in File 04.

---

## Artefact 3 — Update policy with stated support windows

### Why a stated window helps you

Article 7(1) frames defectiveness as the safety "a person is entitled to
expect". Article 7(2)(a) puts the product's presentation — including
"instructions for its assembly, installation, use and **maintenance**" — into
that assessment. A clear, public, honest statement of what you support and for
how long is part of how a reasonable expectation is formed.

Two cautions, stated plainly:

1. **A short support window is not a liability shield.** Article 15 prohibits
   limiting or excluding liability towards the injured person by contract or by
   national law. A support policy is not a contractual liability cap and will not
   function as one. Do not let anyone sell it to you as one.
2. **An overstated window is worse than none.** If you publish "security updates
   for 5 years" and do not deliver them, you have created a documented gap
   between what you said and what you did. Publish only what you will actually
   do. `[VERIFY: whether a published support commitment creates separate
   contractual or consumer-law obligations in your target Member States. It very
   plausibly does, independently of the PLD. Legal review before publishing.]`

### What a usable policy states

- Which products and versions it covers.
- The support window — expressed as a date or as a rule that resolves to a date.
- What "security update" means for you, and what is out of scope.
- How you announce end of support, and how much notice.
- Where the EOL dates are published.
- How someone reports a security issue to you.
- When you last reviewed it.

Full template in File 04.

### Choosing a window honestly

Pick the number you will actually hit, then publish that. Some anchors:

- **Your longest enterprise contract.** Support cannot end before a contract you
  have signed commits you.
- **The upstream EOL of your own runtime.** You cannot credibly offer security
  updates past the point where your platform stops receiving them — unless you
  are prepared to backport yourself, which is a real cost you should decide on
  deliberately.
- **Your actual upgrade cadence.** If you have never maintained a branch for more
  than 18 months, publishing a 5-year window is fiction.

`[VERIFY: whether any sector-specific EU or national law imposes a minimum
support period on your product — for example medical devices under Regulation
(EU) 2017/745, or other sectoral safety law. The PLD imposes none (Recital 51),
but other instruments may, and Article 7(2)(f) feeds "relevant product safety
requirements, including safety-relevant cybersecurity requirements" back into
the defectiveness assessment.]`

---

## Artefact 4 — End-of-support communication

The moment your ability to supply updates ends is the moment your factual
position changes. Two things follow.

**Tell people, before it happens, in a form you can prove you sent.** Recital 51
puts installation by the owner outside your control; that argument is
considerably easier to make when you can show what you told them and when.

**Archive the notice.** A published page that changes silently is weak evidence.
Keep a dated, immutable copy — a git commit of the notice, the sent email with
headers, the in-product banner's release tag.

Minimum contents: what is ending, exact date, what stops, what to move to, the
risk of staying, who to contact. Template in File 04.

For products you cannot reach — shipped software, air-gapped installs,
abandoned-account SaaS tenants — record what channels you attempted and when.
The record of a reasonable attempt is the artefact.

---

## Artefact 5 — Recording a decision NOT to update

This is the artefact almost nobody keeps, and the one that most changes how a
file reads two years later.

Not every unpatched component should be patched. Sometimes the fix is not
reachable, sometimes the upgrade is riskier than the bug, sometimes there is no
fix. Those can be entirely sound engineering decisions. **The problem is never
the decision; it is that the decision was never recorded, so afterwards it
cannot be distinguished from neglect.**

### When to write one

- A component is past EOL and you are staying on it.
- A known vulnerability exists and you are not applying the fix.
- You are ending support for a version earlier than your normal window.
- You are shipping with a dependency you know is unmaintained.

### What it must contain

1. What the component is, and its exact version.
2. What the risk is, in plain terms.
3. **Whether it is reachable in your product, and how you determined that.**
4. Why you are not updating — the real reason, including "no upstream fix
   exists" and "the migration cost exceeds the assessed risk".
5. What you are doing instead — mitigation, compensating control, monitoring.
6. What would change the decision, and when you will look again.
7. Who decided, who reviewed, and the date.

### Write it as if it will be read by someone hostile, later

Because it might be. Two rules that follow from that:

- **Do not editorialise and do not speculate about legal consequences.** State
  facts and engineering reasoning. Speculating in writing about whether something
  makes you liable helps nobody.
- **Do not write it dishonestly.** A record that minimises a risk you actually
  understood is far worse than no record. If the honest reason is "we did not
  have the engineering capacity this quarter", write that. It is a normal
  business fact.

`[VERIFY: whether internal risk records of this kind attract legal professional
privilege in your jurisdiction, and whether they should be routed through counsel
to do so. Article 9(4) requires courts to consider legitimate interests
including confidentiality, and Recital 42 names legal professional privilege and
trade secrets — but privilege is a matter of national law and varies widely
across Member States. Ask your lawyer how to structure these records **before**
you accumulate two years of them.]`

That `[VERIFY]` is the most commercially significant one in this file. It is
worth one conversation with counsel before you start.

Template in File 04.

---

## Retention: how long to keep all of this

Set retention against the liability periods, not against your default log
retention.

| Period | Length | Source |
|---|---|---|
| Limitation | 3 years from claimant's awareness of damage, defectiveness and liable operator | Art. 16(1) |
| Expiry | **10 years** from placing on market / putting into service | Art. 17(1) |
| Expiry, latent personal injury | **25 years** | Art. 17(2) |
| Substantially modified product | New 10 years from when the modified product was made available | Art. 17(1)(b) |

A product placed on the EU market on 9 December 2026 can be the subject of a
claim until **9 December 2036**, and in a latent personal injury case until
**9 December 2051**.

**Practical guidance, offered as engineering judgement rather than legal advice:**

- Keep release-linked evidence — inventory, EOL scan, support policy as it stood,
  end-of-support notices — for at least **10 years from the date that version was
  placed on the market**.
- Where your product could contribute to personal injury, discuss the **25-year**
  case with your lawyer before setting a retention period. Twenty-five years is
  longer than most storage formats and most companies. Plan for format migration.
- Keep the evidence **immutable and dated**. Signed release artefacts, git tags,
  write-once storage. A record that could have been edited later is weaker than
  one that could not.
- **Reconcile this with data protection retention rules.** These artefacts should
  contain no personal data beyond decision-maker names; keep it that way, and
  check your retention schedule against your privacy policy. Long retention of
  technical records is not a licence to retain personal data.

`[VERIFY: your own retention obligations and limits under national law and your
data protection policies. Retention periods are a legal question. The periods
above are what the directive states; what you must and may keep is not.]`

---

## The afternoon: a concrete sequence

For one product, about three hours.

**0:00 — Baseline scan (15 min)**
```bash
./pld-watch scan --json > evidence/$(date +%Y-%m-%d)-pld-watch.json
cat evidence/*.json | head -40
```
Commit it. Even if the result is ugly. **Especially** if the result is ugly —
a first honest baseline is the point.

**0:15 — Fill the gaps the tool cannot see (45 min)**
List, by hand: vendored code, base image OS packages, binaries you ship, native
modules, commercial dependencies, anything in `unknown`. Add them to the
inventory with `source: manual`.

**1:00 — Triage each EOL finding (45 min)**
For each, decide one of: **upgrade** (with a target date and an owner),
**mitigate** (with the control named), or **accept** (which requires a
decision-not-to-update record). Nothing stays untriaged.

**1:45 — Draft the support policy (45 min)**
Template in File 04. Choose a window you will actually hit. Mark it DRAFT and
send it to legal review. Do not publish today.

**2:30 — Write the register and any accept-decisions (30 min)**
Templates in File 04.

**3:00 — Set the recurring work**
- `pld-watch` in CI on every release build, JSON archived.
- Quarterly review of the EOL register.
- Annual review of the support policy.
- A calendar entry to re-check national transposition law for each Member State
  you sell into.

---

## What "good" looks like after six months

Not a binder. Four things:

1. Every release has an attached, dated component inventory and EOL scan.
2. Every EOL component is either scheduled, mitigated, or has a written accept
   decision with a review date.
3. Your public support policy states a window you are actually meeting, and was
   reviewed by a lawyer before publication.
4. Every end-of-support event has a dated, archived notice.

If an Article 9 disclosure order landed, you would be compiling from records
that already exist rather than reconstructing intent from memory. That is the
entire objective. It is not a guarantee of anything, and anyone selling it as
one is overselling.

---

*Toledo Technologies LLC. Not legal advice. Sources: Directive (EU) 2024/2853 —
https://eur-lex.europa.eu/eli/dir/2024/2853/oj ; `pld-watch` —
https://github.com/ntoledo319/pld-watch ; endoflife.date — https://endoflife.date*
